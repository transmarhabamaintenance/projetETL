package com.etl.batch;

import com.etl.EtlException;
import com.etl.extract.ExcelExtractor;
import com.etl.load.ExcelLoader;
import com.etl.load.OutputProfile;
import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;
import com.etl.model.EtlProgress;
import com.etl.model.ValidationError;
import com.etl.service.BatchReportWriter;
import com.etl.transform.ChauffeurTransformer;
import com.etl.validation.ChauffeurValidator;
import com.etl.validation.DuplicatePolicy;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Traite tous les classeurs .xlsx d'un dossier et les accumule dans un classeur de sortie
 * unique.
 *
 * <p>Une seule feuille est produite : l'en-tete du gabarit manager n'est ecrit qu'une fois,
 * puis les lignes de chaque fichier viennent s'ajouter a la suite de celles du fichier
 * precedent. Chaque fichier conserve sa propre date et sa propre heure de traitement, ce qui
 * permet de lire l'historique des releves dans l'ordre du dossier sans revenir a la source.</p>
 *
 * <p>Un classeur illisible est signale puis ecarte : il n'interrompt pas les fichiers
 * suivants. Tout classeur du dossier qui n'est pas une entree exploitable apparait dans le
 * rapport avec le motif de son exclusion, afin qu'aucune donnee ne disparaisse en silence.</p>
 */
public class BatchService {

    /**
     * Nombre d'erreurs conservees par fichier dans le rapport. Le compteur reste exact au
     * dela de cette limite, seul le detail est tronque pour proteger la memoire.
     */
    private static final int MAX_REPORTED_ERRORS_PER_FILE = 200;

    /**
     * Classeurs produits par l'application, identifies par le suffixe du gabarit. Ils ne sont
     * jamais reintegres comme sources, meme presents dans le dossier d'entree.
     */
    private static final Pattern GENERATED_OUTPUT = Pattern.compile(
            "(?i)_(?:rapport_manager|clean|VIVO|TOTAL)(?:_\\d+)?\\.xlsx$"
    );

    private final ExcelExtractor extractor;
    private final ChauffeurTransformer transformer;
    private final ChauffeurValidator validator;
    private final ExcelLoader loader;
    private final BatchReportWriter reportWriter;

    public BatchService() {
        this(new ExcelExtractor(), new ChauffeurTransformer(), new ChauffeurValidator(),
                new ExcelLoader(), new BatchReportWriter());
    }

    public BatchService(ExcelExtractor extractor, ChauffeurTransformer transformer,
                        ChauffeurValidator validator, ExcelLoader loader,
                        BatchReportWriter reportWriter) {
        this.extractor = Objects.requireNonNull(extractor, "L'extracteur est obligatoire");
        this.transformer = Objects.requireNonNull(transformer, "Le transformateur est obligatoire");
        this.validator = Objects.requireNonNull(validator, "Le validateur est obligatoire");
        this.loader = Objects.requireNonNull(loader, "Le chargeur est obligatoire");
        this.reportWriter = Objects.requireNonNull(reportWriter, "Le générateur de rapport est obligatoire");
    }

    public BatchResult execute(Path inputDirectory, Path output) throws IOException {
        return execute(inputDirectory, output, DuplicatePolicy.KEEP_ALL, progress -> { });
    }

    public BatchResult execute(Path inputDirectory, Path output,
                               Consumer<EtlProgress> progressListener) throws IOException {
        return execute(inputDirectory, output, DuplicatePolicy.KEEP_ALL, progressListener);
    }

    /**
     * Fusionne tous les classeurs du dossier dans le gabarit manager. La politique de
     * doublons vaut {@link DuplicatePolicy#KEEP_ALL} par defaut : un lot accumule des releves
     * successifs d'une meme flotte, qui doivent tous etre conserves.
     */
    public BatchResult execute(Path inputDirectory, Path output, DuplicatePolicy duplicatePolicy,
                               Consumer<EtlProgress> progressListener) throws IOException {
        return execute(inputDirectory, output, duplicatePolicy, progressListener,
                OutputProfile.RAPPORT_MANAGER, false);
    }

    /** Traite un lot avec le format sélectionné et permet de conserver le classeur existant. */
    public BatchResult execute(Path inputDirectory, Path output, DuplicatePolicy duplicatePolicy,
                               Consumer<EtlProgress> progressListener, OutputProfile profile,
                               boolean append) throws IOException {
        Objects.requireNonNull(inputDirectory, "Le dossier source est obligatoire");
        Objects.requireNonNull(output, "Le fichier de sortie est obligatoire");
        Consumer<EtlProgress> listener = progressListener == null ? progress -> { } : progressListener;

        Path normalizedDirectory = validateInputDirectory(inputDirectory);
        Path normalizedOutput = output.toAbsolutePath().normalize();
        Path reportPath = buildReportPath(normalizedOutput);

        List<Candidate> candidates = listCandidates(normalizedDirectory, normalizedOutput);
        List<Path> sources = candidates.stream()
                .filter(Candidate::processable)
                .map(Candidate::path)
                .toList();
        if (sources.isEmpty()) {
            throw new EtlException(
                    "Le dossier ne contient aucun classeur .xlsx à traiter : " + normalizedDirectory
            );
        }

        DuplicatePolicy effectivePolicy = duplicatePolicy == null
                ? DuplicatePolicy.KEEP_ALL : duplicatePolicy;
        Set<String> knownDrivers = effectivePolicy == DuplicatePolicy.KEEP_ALL ? null : new HashSet<>();

        long start = System.nanoTime();
        int totalFiles = sources.size();
        List<BatchFileResult> results = new ArrayList<>(candidates.size());

        listener.accept(new EtlProgress(
                EtlProgress.Stage.EXTRACTION, 0, totalFiles, 0.0,
                "Fusion de " + totalFiles + " classeur(s) dans un seul classeur de sortie..."
        ));

        OutputProfile effectiveProfile = OutputProfile.orDefault(profile);
        if (append || effectiveProfile == OutputProfile.TOTAL) {
            for (int index = 0; index < totalFiles; index++) {
                listener.accept(new EtlProgress(EtlProgress.Stage.EXTRACTION, index, totalFiles,
                        index / (double) totalFiles, "Ajout du fichier " + (index + 1) + " sur " + totalFiles));
                results.add(processFileAppend(sources.get(index), normalizedOutput, effectiveProfile,
                        knownDrivers));
            }
            if (appendedRows(results) == 0) throw new EtlException(noValidRowMessage(results));
        } else {
            try (ExcelLoader.StreamingWriter writer = loader.openStream(
                    sources.get(0), normalizedOutput, effectiveProfile)) {
                for (int index = 0; index < totalFiles; index++) {
                    results.add(processFile(writer, sources.get(index), index, totalFiles,
                            knownDrivers, listener));
                }
                if (appendedRows(results) == 0) throw new EtlException(noValidRowMessage(results));
                listener.accept(new EtlProgress(
                        EtlProgress.Stage.LOADING, totalFiles, totalFiles, 0.94,
                        "Finalisation du classeur de sortie..."
                ));
                writer.commit();
            }
        }

        candidates.stream()
                .filter(candidate -> !candidate.processable())
                .forEach(candidate -> results.add(new BatchFileResult(
                        candidate.path(), BatchFileResult.Status.SKIPPED, 0, 0, 0, 0, 0,
                        List.of(), candidate.skipReason())));

        listener.accept(new EtlProgress(
                EtlProgress.Stage.REPORTING, 0, 1, 0.96,
                "Génération du rapport..."
        ));

        BatchResult result = new BatchResult(
                normalizedDirectory, normalizedOutput, reportPath, results, elapsedMillis(start)
        );
        reportWriter.write(result);
        listener.accept(new EtlProgress(
                EtlProgress.Stage.COMPLETED, totalFiles, totalFiles, 1.0,
                "Lot terminé : " + result.appendedRows() + " ligne(s) ajoutée(s)."
        ));
        return result;
    }

    private BatchFileResult processFileAppend(Path source, Path output, OutputProfile profile,
                                              Set<String> knownDrivers) {
        FileCounters counters = new FileCounters();
        try {
            List<ChauffeurRecord> extracted = extractor.extract(source);
            List<ChauffeurRecord> valid = new ArrayList<>();
            for (ChauffeurRecord record : extracted) {
                counters.extracted++;
                Chauffeur transformed = transformer.transform(record.chauffeur());
                counters.transformed++;
                List<ValidationError> errors = validator.validateRow(
                        record.rowIndex(), transformed, record.extractionErrors());
                if (!errors.isEmpty()) {
                    counters.addErrors(errors);
                    continue;
                }
                if (knownDrivers != null && validator.hasCompleteIdentity(transformed)
                        && !knownDrivers.add(validator.duplicateKey(transformed))) {
                    counters.duplicates++;
                    continue;
                }
                valid.add(new ChauffeurRecord(record.rowIndex(), transformed,
                        record.extractionErrors(), record.extraColumns()));
            }
            if (!valid.isEmpty()) {
                loader.load(source, output, valid, List.of(), profile, true);
                counters.appended = valid.size();
            }
            return counters.toResult(source, BatchFileResult.Status.MERGED, "");
        } catch (IOException exception) {
            return counters.toResult(source, BatchFileResult.Status.FAILED, exception.getMessage());
        }
    }

    /**
     * Traite un fichier et ajoute ses lignes a la suite de celles deja ecrites. Les erreurs
     * propres a la source sont signalees et n'interrompent pas le lot ; une panne d'ecriture
     * sur la destination, elle, remonte car le classeur de sortie serait incomplet.
     */
    private BatchFileResult processFile(ExcelLoader.StreamingWriter writer, Path source, int index,
                                        int totalFiles, Set<String> knownDrivers,
                                        Consumer<EtlProgress> listener) throws IOException {
        FileCounters counters = new FileCounters();
        double fileStart = index / (double) totalFiles;
        double fileEnd = (index + 1) / (double) totalFiles;
        try {
            writer.startFile(LocalDateTime.now());
            extractor.stream(source, null,
                    new ProgressBridge(listener, source, index, totalFiles, fileStart, fileEnd, writer),
                    (rowIndex, chauffeur, extractionErrors, extraColumns) -> {
                        counters.extracted++;
                        Chauffeur transformed = transformer.transform(chauffeur);
                        counters.transformed++;

                        List<ValidationError> rowErrors =
                                validator.validateRow(rowIndex, transformed, extractionErrors);
                        if (!rowErrors.isEmpty()) {
                            counters.addErrors(rowErrors);
                            return;
                        }
                        if (knownDrivers != null
                                && validator.hasCompleteIdentity(transformed)
                                && !knownDrivers.add(validator.duplicateKey(transformed))) {
                            counters.duplicates++;
                            return;
                        }
                        try {
                            writer.append(transformed, extraColumns);
                            counters.appended++;
                        } catch (IOException exception) {
                            throw new UncheckedIOException(exception);
                        }
                    });
            return counters.toResult(source, BatchFileResult.Status.MERGED, "");
        } catch (EtlException exception) {
            return counters.toResult(source, BatchFileResult.Status.FAILED, exception.getMessage());
        }
    }

    /**
     * Relaie l'avancement de lecture d'un fichier vers la progression globale du lot.
     */
    private static final class ProgressBridge implements ExcelExtractor.StreamListener {

        private final Consumer<EtlProgress> listener;
        private final Path source;
        private final int index;
        private final int totalFiles;
        private final double fileStart;
        private final double fileEnd;
        private final ExcelLoader.StreamingWriter writer;

        ProgressBridge(Consumer<EtlProgress> listener, Path source, int index, int totalFiles,
                       double fileStart, double fileEnd, ExcelLoader.StreamingWriter writer) {
            this.listener = listener;
            this.source = source;
            this.index = index;
            this.totalFiles = totalFiles;
            this.fileStart = fileStart;
            this.fileEnd = fileEnd;
            this.writer = writer;
        }

        @Override
        public void onHeader(List<String> presentFields, List<String> extraLabels) {
            writer.onHeader(presentFields, extraLabels);
        }

        @Override
        public void onProgress(long dataRows, long bytesRead, long bytesTotal) {
            double withinFile = bytesTotal <= 0 ? 1.0
                    : Math.max(0.0, Math.min(1.0, bytesRead / (double) bytesTotal));
            listener.accept(new EtlProgress(
                    EtlProgress.Stage.EXTRACTION,
                    (int) Math.min(Integer.MAX_VALUE, dataRows),
                    (int) Math.min(Integer.MAX_VALUE, Math.max(dataRows, 1L)),
                    fileStart + (fileEnd - fileStart) * withinFile,
                    "[" + (index + 1) + "/" + totalFiles + "] " + source.getFileName()
                            + " : " + dataRows + " ligne(s) lue(s)."
            ));
        }
    }

    /**
     * Classeurs .xlsx du dossier, tries par nom afin que l'ordre du classeur de sortie soit
     * reproductible d'une execution a l'autre.
     */
    private List<Candidate> listCandidates(Path directory, Path output) throws IOException {
        List<Candidate> candidates = new ArrayList<>();
        try (DirectoryStream<Path> entries = Files.newDirectoryStream(directory)) {
            for (Path entry : entries) {
                String fileName = entry.getFileName().toString();
                if (!Files.isRegularFile(entry)
                        || !fileName.toLowerCase(Locale.FRANCE).endsWith(".xlsx")) {
                    continue;
                }
                Path normalized = entry.toAbsolutePath().normalize();
                candidates.add(new Candidate(normalized, skipReason(normalized, output, fileName)));
            }
        }
        candidates.sort(Comparator.comparing(candidate -> candidate.path().getFileName().toString(),
                String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(candidates);
    }

    /**
     * Motif d'exclusion d'un classeur du dossier, ou {@code null} s'il doit etre traite.
     */
    private String skipReason(Path candidate, Path output, String fileName) {
        if (candidate.equals(output)) {
            return "Fichier de sortie de l'exécution en cours : il ne peut pas être sa propre source.";
        }
        if (fileName.startsWith("~$") || fileName.startsWith(".")) {
            return "Fichier temporaire ou masqué, sans donnée de télémétrie exploitable.";
        }
        if (GENERATED_OUTPUT.matcher(fileName).find()) {
            return "Classeur produit par l'application : il ne peut pas être réintégré comme source.";
        }
        return null;
    }

    private Path validateInputDirectory(Path inputDirectory) throws EtlException {
        Path normalized = inputDirectory.toAbsolutePath().normalize();
        if (!Files.exists(normalized)) {
            throw new EtlException("Le dossier source n'existe pas : " + normalized);
        }
        if (!Files.isDirectory(normalized)) {
            throw new EtlException("Le chemin source ne désigne pas un dossier : " + normalized);
        }
        if (!Files.isReadable(normalized)) {
            throw new EtlException("Le dossier source n'est pas lisible. Vérifiez les permissions.");
        }
        return normalized;
    }

    private Path buildReportPath(Path output) {
        String fileName = output.getFileName().toString();
        int extensionIndex = fileName.toLowerCase(Locale.FRANCE).lastIndexOf(".xlsx");
        String baseName = extensionIndex > 0 ? fileName.substring(0, extensionIndex) : fileName;
        return output.resolveSibling(baseName + "_rapport.txt");
    }

    private int appendedRows(List<BatchFileResult> results) {
        int total = 0;
        for (BatchFileResult result : results) {
            total += result.appendedRows();
        }
        return total;
    }

    private String noValidRowMessage(List<BatchFileResult> results) {
        StringBuilder message = new StringBuilder(
                "Aucune ligne valide n'a pu être ajoutée au classeur de sortie.");
        for (BatchFileResult result : results) {
            if (result.isFailed()) {
                message.append('\n').append(result.fileName()).append(" : ").append(result.message());
            }
        }
        return message.toString();
    }

    private long elapsedMillis(long startNanos) {
        return TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNanos);
    }

    /**
     * Classeur du dossier et motif de son eventuelle exclusion.
     */
    private record Candidate(Path path, String skipReason) {

        boolean processable() {
            return skipReason == null;
        }
    }

    /**
     * Compteurs d'un fichier du lot. Les compteurs restent exacts au-dela du plafond de
     * detail, seule la liste des erreurs destinees au rapport est tronquee.
     */
    private static final class FileCounters {

        private int extracted;
        private int transformed;
        private int appended;
        private int duplicates;
        private int errorCount;
        private final List<ValidationError> errors = new ArrayList<>();

        void addErrors(List<ValidationError> rowErrors) {
            errorCount += rowErrors.size();
            if (errors.size() < MAX_REPORTED_ERRORS_PER_FILE) {
                errors.addAll(rowErrors);
            }
        }

        BatchFileResult toResult(Path source, BatchFileResult.Status status, String message) {
            return new BatchFileResult(source, status, extracted, transformed, appended,
                    duplicates, errorCount, errors, message);
        }
    }
}
