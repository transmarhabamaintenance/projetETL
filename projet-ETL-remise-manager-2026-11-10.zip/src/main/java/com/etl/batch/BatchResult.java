package com.etl.batch;

import java.nio.file.Path;
import java.util.List;
import java.util.Objects;

/**
 * Resultat d'une execution par lot : tous les classeurs d'un dossier fusionnes dans un
 * classeur de sortie unique, sur une seule feuille.
 *
 * @param inputDirectory dossier source contenant les classeurs a traiter
 * @param outputPath     classeur fusionne produit
 * @param reportPath     rapport texte ecrit a cote du classeur fusionne
 * @param files          un resultat par fichier candidat, dans l'ordre de traitement
 * @param durationMillis duree totale du lot
 */
public record BatchResult(
        Path inputDirectory,
        Path outputPath,
        Path reportPath,
        List<BatchFileResult> files,
        long durationMillis
) {

    public BatchResult {
        inputDirectory = Objects.requireNonNull(inputDirectory, "Le dossier d'entrée est obligatoire")
                .toAbsolutePath().normalize();
        outputPath = Objects.requireNonNull(outputPath, "Le fichier de sortie est obligatoire")
                .toAbsolutePath().normalize();
        reportPath = Objects.requireNonNull(reportPath, "Le chemin du rapport est obligatoire")
                .toAbsolutePath().normalize();
        files = List.copyOf(Objects.requireNonNullElse(files, List.of()));
        if (durationMillis < 0) {
            throw new IllegalArgumentException("La durée ne peut pas être négative");
        }
    }

    public int filesFound() {
        return files.size();
    }

    public int mergedFiles() {
        return count(BatchFileResult.Status.MERGED);
    }

    public int skippedFiles() {
        return count(BatchFileResult.Status.SKIPPED);
    }

    public int failedFiles() {
        return count(BatchFileResult.Status.FAILED);
    }

    public int appendedRows() {
        return sum(BatchFileResult::appendedRows);
    }

    public int duplicates() {
        return sum(BatchFileResult::duplicates);
    }

    public int errors() {
        return sum(BatchFileResult::errors);
    }

    private int count(BatchFileResult.Status status) {
        int total = 0;
        for (BatchFileResult file : files) {
            if (file.status() == status) {
                total++;
            }
        }
        return total;
    }

    private int sum(java.util.function.ToIntFunction<BatchFileResult> extractor) {
        int total = 0;
        for (BatchFileResult file : files) {
            total += extractor.applyAsInt(file);
        }
        return total;
    }
}
