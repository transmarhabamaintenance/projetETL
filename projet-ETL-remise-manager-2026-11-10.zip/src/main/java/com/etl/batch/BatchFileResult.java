package com.etl.batch;

import com.etl.model.ValidationError;

import java.nio.file.Path;
import java.util.List;
import java.util.Objects;

/**
 * Resultat de la fusion d'un seul classeur d'entree dans le classeur de sortie unique.
 *
 * <p>Un fichier en echec n'interrompt pas le lot : il est signale et les fichiers suivants
 * sont traites normalement.</p>
 *
 * @param source          classeur d'origine, jamais modifie
 * @param status          issue obtenue pour ce fichier
 * @param extractedRows   lignes lues dans la feuille source
 * @param transformedRows lignes nettoyees et normalisees
 * @param appendedRows    lignes effectivement ajoutees au classeur de sortie
 * @param duplicates      occurrences exclues au titre de doublon
 * @param errors          erreurs de validation relevees
 * @param validationErrors detail des erreurs, plafonne pour proteger la memoire
 * @param message         motif de l'echec, vide lorsque le fichier a ete fusionne
 */
public record BatchFileResult(
        Path source,
        Status status,
        int extractedRows,
        int transformedRows,
        int appendedRows,
        int duplicates,
        int errors,
        List<ValidationError> validationErrors,
        String message
) {

    /**
     * Issue du traitement d'un fichier du lot.
     */
    public enum Status {

        /** Les lignes du fichier ont ete ajoutees a la suite de celles des fichiers precedents. */
        MERGED,

        /** Le fichier a ete ecarte avant tout traitement, sans interrompre le lot. */
        SKIPPED,

        /** Le fichier n'a pas pu etre traite ; les fichiers suivants restent traites. */
        FAILED
    }

    public BatchFileResult {
        source = Objects.requireNonNull(source, "Le fichier source est obligatoire")
                .toAbsolutePath().normalize();
        status = Objects.requireNonNull(status, "Le statut du fichier est obligatoire");
        if (extractedRows < 0 || transformedRows < 0 || appendedRows < 0
                || duplicates < 0 || errors < 0) {
            throw new IllegalArgumentException("Les statistiques ne peuvent pas être négatives");
        }
        validationErrors = List.copyOf(Objects.requireNonNullElse(validationErrors, List.of()));
        message = Objects.requireNonNullElse(message, "");
    }

    public boolean isMerged() {
        return status == Status.MERGED;
    }

    public boolean isFailed() {
        return status == Status.FAILED;
    }

    /**
     * Nom du fichier seul, plus lisible dans un rapport que le chemin complet.
     */
    public String fileName() {
        Path fileName = source.getFileName();
        return fileName == null ? source.toString() : fileName.toString();
    }
}
