package com.etl.transform;

import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Nettoie et normalise les données sans modifier les objets source.
 */
public class ChauffeurTransformer {

    private static final Pattern FORMATTING_CHARACTERS = Pattern.compile("[\\p{Cc}\\p{Cf}]");
    private static final Pattern EXTRA_WHITESPACE = Pattern.compile("\\s+");
    private static final Pattern SPEED_UNIT = Pattern.compile("(?i)\\s*(?:km\\s*/?h|kmh|kph)\\s*$");
    private static final Set<String> UNKNOWN_VALUES = Set.of(
            "unknown", "inconnu", "inconnue", "non renseigne", "non renseigné", "n/a", "nd", "null"
    );

    public Chauffeur transform(Chauffeur source) {
        if (source == null) {
            throw new IllegalArgumentException("Le chauffeur à transformer ne peut pas être null");
        }

        String chauffeurNom = titleCase(clean(source.getChauffeurNom()));
        if (chauffeurNom.isEmpty()) {
            chauffeurNom = extractDriverFromDescription(source.getDescription());
        }

        return new Chauffeur(
                uppercase(clean(source.getStatutMobile())),
                titleCase(clean(source.getDescription())),
                clean(source.getInscription()),
                uppercase(clean(source.getNumeroFlotte())),
                uppercase(clean(source.getSite())),
                chauffeurNom,
                titleCase(clean(source.getEmplacement())),
                titleCase(clean(source.getDernierEvenement())),
                clean(source.getValeurDernierEvenement()),
                normalizeSpeed(source.getVitesse())
        );
    }

    public List<ChauffeurRecord> transformAll(List<ChauffeurRecord> records) {
        if (records == null) {
            throw new IllegalArgumentException("La liste des enregistrements ne peut pas être null");
        }
        return records.stream()
                .map(record -> new ChauffeurRecord(
                        record.rowIndex(),
                        transform(record.chauffeur()),
                        record.extractionErrors()
                ))
                .toList();
    }

    public String clean(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }

        String normalized = Normalizer.normalize(value, Normalizer.Form.NFC)
                .replace('\u00A0', ' ');
        normalized = FORMATTING_CHARACTERS.matcher(normalized).replaceAll(" ");
        normalized = EXTRA_WHITESPACE.matcher(normalized.trim()).replaceAll(" ");

        return UNKNOWN_VALUES.contains(normalized.toLowerCase(Locale.FRANCE)) ? "" : normalized;
    }

    public String titleCase(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }

        StringBuilder result = new StringBuilder(value.length());
        boolean startOfWord = true;
        for (int codePoint : value.codePoints().toArray()) {
            if (Character.isLetter(codePoint)) {
                int converted = startOfWord
                        ? Character.toUpperCase(codePoint)
                        : Character.toLowerCase(codePoint);
                result.appendCodePoint(converted);
                startOfWord = false;
            } else {
                result.appendCodePoint(codePoint);
                startOfWord = true;
            }
        }
        return result.toString();
    }

    private String uppercase(String value) {
        return value.toUpperCase(Locale.FRANCE);
    }

    private String normalizeSpeed(String value) {
        String cleaned = clean(value);
        if (cleaned.isEmpty()) {
            return "";
        }
        return SPEED_UNIT.matcher(cleaned).replaceFirst("").trim().replace(',', '.');
    }

    private String extractDriverFromDescription(String description) {
        if (description == null || description.isBlank()) {
            return "";
        }
        int separator = description.lastIndexOf('/');
        if (separator < 0 || separator == description.length() - 1) {
            return "";
        }
        String candidate = clean(description.substring(separator + 1));
        if (candidate.isEmpty()) {
            return "";
        }
        boolean hasLetter = candidate.codePoints().anyMatch(Character::isLetter);
        boolean onlyDigits = candidate.codePoints().allMatch(Character::isDigit);
        if (!hasLetter || onlyDigits) {
            return "";
        }
        return titleCase(candidate);
    }
}
