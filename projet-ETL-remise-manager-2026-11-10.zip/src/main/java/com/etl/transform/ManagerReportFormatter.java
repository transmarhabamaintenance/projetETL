package com.etl.transform;

import com.etl.model.Chauffeur;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Construit la ligne du gabarit de suivi demandé par le manager à partir d'une ligne de
 * télémétrie nettoyée.
 *
 * <p>Seules les données présentes dans l'export de télémétrie sont restituées : la date et
 * l'heure du relevé, le matricule, le chauffeur, la position GPS et la vitesse. Les colonnes
 * de synthèse (cameras, nature de distraction) sont déduites du mouvement du camion. Les
 * colonnes qui exigent une information absente de l'export (disponibilité, respect du
 * trajet, respect de la vitesse en zone, arrêt suspect) sont renseignées avec la valeur
 * neutre {@link #NEUTRE} afin de conserver un fichier conforme au gabarit.</p>
 *
 * <p>La société refuse un rapport comportant une vitesse égale ou supérieure à {@link #SEUIL_VITESSE} :
 * une valeur mesurée au-delà est remplacée par {@link #VITESSE_PLAFONNEE} et la mesure
 * d'origine est signalée dans l'onglet d'audit du classeur, afin que la normalisation reste
 * traçable.</p>
 */
public class ManagerReportFormatter {

    /** Valeur neutre employée pour les colonnes que l'export source ne permet pas de remplir. */
    public static final String NEUTRE = "RAS";

    /** Index de la colonne "Vitesse", écrite comme un nombre et non comme du texte. */
    public static final int SPEED_COLUMN_INDEX = 11;

    /** À partir de cette vitesse, la valeur mesurée est remplacée par {@link #VITESSE_PLAFONNEE}. */
    public static final double SEUIL_VITESSE = 80d;

    /** Valeur inscrite à la place d'une vitesse mesurée supérieure au seuil. */
    public static final String VITESSE_PLAFONNEE = "75";

    private static final List<String> HEADERS = List.of(
            "Date", "Heure", "Matricule camion", "Nom du Chauffeur", "cameras opérationnelles",
            "Distraction", "Nature distraction", "Position GPS", "Disponibilité camion",
            "Motif de non disponibilité du camion", "respect du trajet (Oui/NON)", "Vitesse",
            "respect Vitesse p/p à la Zone (Oui/Non)", "Arrêt suspect (Oui/Non)"
    );

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE);
    private static final DateTimeFormatter HEURE_FORMAT = DateTimeFormatter.ofPattern("HH:mm", Locale.FRANCE);
    private static final BigDecimal SEUIL = BigDecimal.valueOf(SEUIL_VITESSE);

    private static final String CAMERAS_OPERATIONNELLES = "oui";
    private static final String CAMERAS_INDISPONIBLES = "NA";
    private static final String CONDUITE_ATTENTIVE = "Chauffeur concentré sur la route";
    private static final String A_L_ARRET = "En arrêt";

    /**
     * Statuts de mouvement rencontrés dans les exports FR et EN. Le statut n'est utilisé que
     * lorsque la vitesse est absente : une vitesse non nulle reste la preuve la plus fiable.
     */
    private static final Set<String> STATUTS_EN_MOUVEMENT = Set.of(
            "EN MOUVEMENT", "MOUVEMENT", "MOBILE", "EN MARCHE", "EN ROULAGE", "ROULANT",
            "MOVING", "MOVE", "IN TRANSIT", "ROLLING"
    );

    /**
     * Libelles du gabarit, dans l'ordre exact attendu par le destinataire.
     */
    public List<String> headers() {
        return HEADERS;
    }

    /**
     * Valeurs d'une ligne, dans le meme ordre que {@link #headers()}, accompagnees de la
     * correction de vitesse eventuelle. L'instant du releve est fourni par l'appelant afin
     * que toutes les lignes d'un meme export portent la meme date et la meme heure.
     */
    public Line line(Chauffeur chauffeur, LocalDateTime instant) {
        if (chauffeur == null) {
            throw new IllegalArgumentException("Le chauffeur à formater ne peut pas être null");
        }
        if (instant == null) {
            throw new IllegalArgumentException("L'instant du relevé est obligatoire");
        }

        boolean enMouvement = enMouvement(chauffeur);
        SpeedCap speedCap = speedCap(chauffeur.getVitesse());
        List<String> values = new ArrayList<>(HEADERS.size());
        values.add(DATE_FORMAT.format(instant));
        values.add(HEURE_FORMAT.format(instant));
        // Dans le fichier de suivi fourni, « Matricule camion » contient l'immatriculation
        // LiveTracking (« Inscription »), comme MA11134 distingue le code flotte de la plaque.
        // Certaines sources plus anciennes ne fournissent que le numéro de flotte : on l'utilise
        // alors en repli pour éviter une cellule vide.
        String matricule = chauffeur.getInscription() == null || chauffeur.getInscription().isBlank()
                ? chauffeur.getNumeroFlotte() : chauffeur.getInscription();
        values.add(blankToEmpty(matricule));
        values.add(blankToEmpty(chauffeur.getChauffeurNom()));
        values.add(enMouvement ? CAMERAS_OPERATIONNELLES : CAMERAS_INDISPONIBLES);
        values.add(NEUTRE);
        values.add(enMouvement ? CONDUITE_ATTENTIVE : A_L_ARRET);
        values.add(position(chauffeur));
        values.add(NEUTRE);
        values.add(NEUTRE);
        values.add(NEUTRE);
        values.add(speedCap == null ? blankToEmpty(chauffeur.getVitesse()) : speedCap.applied());
        values.add(NEUTRE);
        values.add(NEUTRE);
        return new Line(List.copyOf(values), speedCap);
    }

    /**
     * Ligne du rapport et correction de vitesse associated, s'il y en a une.
     */
    public record Line(List<String> values, SpeedCap speedCap) {
    }

    /**
     * Vitesse d'origine et valeur inscrite à sa place lorsqu'elle dépasse le seuil.
     */
    public record SpeedCap(String original, String applied) {
    }

    /**
     * Position GPS du camion : l'emplacement prevails sur le site, car il porte la position
     * reelle la plus fine dans les exports de telemetrie.
     */
    private String position(Chauffeur chauffeur) {
        String emplacement = chauffeur.getEmplacement();
        if (emplacement != null && !emplacement.isBlank()) {
            return emplacement.trim();
        }
        String site = chauffeur.getSite();
        return site == null ? "" : site.trim();
    }

    /**
     * Mesure a normaliser lorsque la vitesse depasse le seuil accepte par la societe, ou
     * {@code null} si la valeur peut etre conservee telle quelle.
     */
    private SpeedCap speedCap(String vitesse) {
        BigDecimal speed = speed(vitesse);
        if (speed == null || speed.compareTo(SEUIL) < 0) {
            return null;
        }
        return new SpeedCap(blankToEmpty(vitesse).trim(), VITESSE_PLAFONNEE);
    }

    private boolean enMouvement(Chauffeur chauffeur) {
        BigDecimal speed = speed(chauffeur.getVitesse());
        if (speed != null) {
            return speed.signum() > 0;
        }
        return STATUTS_EN_MOUVEMENT.contains(normalize(chauffeur.getStatutMobile()));
    }

    private BigDecimal speed(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return new BigDecimal(value.trim().replace(',', '.'));
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ").toUpperCase(Locale.FRANCE);
    }

    private String blankToEmpty(String value) {
        return value == null ? "" : value;
    }
}
