package com.etl.extract;

import com.etl.EtlException;
import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;
import com.etl.model.ExtraColumn;
import com.etl.model.ValidationError;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaError;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellReference;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.SharedStrings;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Lit la première feuille d'un classeur .xlsx et conserve le numéro de ligne Excel.
 */
public class ExcelExtractor {

    private static final int MAX_HEADER_SCAN_ROWS = 25;
    /** Une seule colonne metier reconnue suffit pour identifier la ligne d'en-tete. */
    private static final int MINIMUM_RECOGNIZED_HEADERS = 1;
    private static final String HEADER_UNRECOGNIZED_MESSAGE =
            "L'en-tête Excel n'a pas été reconnu. Aucune colonne métier n'a été identifiée "
                    + "dans les 25 premières lignes.";
    private static final int PROGRESS_INTERVAL = 5_000;
    public static final long STREAMING_THRESHOLD_BYTES = 20L * 1024 * 1024;

    private static final String[] FIELDS = {
            "statutMobile", "description", "inscription", "numeroFlotte", "site",
            "chauffeurNom", "emplacement", "dernierEvenement", "valeurDernierEvenement", "vitesse"
    };
    private static final Pattern HEADER_SEPARATOR = Pattern.compile("[^\\p{L}\\p{N}]+");
    private static final Pattern EXCEL_ERROR = Pattern.compile(
            "#(DIV/0!|VALUE!|REF!|NAME\\?|NUM!|N/A|NULL!|NUMERR!|SPILL!|CALC!|FIELD!|BLOCKED!|CONNECT!|UNKNOWN!)"
    );
    // En-têtes horaires normalisés ("9:00" -> "9 00", "9h00" -> "9h00").
    private static final Pattern HOUR_HEADER = Pattern.compile("^\\d{1,2}(?:\\s\\d{2}|h\\d{2})$");

    private static final Map<String, List<String>> HEADER_ALIASES = createHeaderAliases();

    public List<ChauffeurRecord> extract(Path source) throws IOException {
        return extract(source, null);
    }

    public List<ChauffeurRecord> extract(Path source, String sheetName) throws IOException {
        Path normalizedSource = validateSource(source);

        if (Files.size(normalizedSource) > STREAMING_THRESHOLD_BYTES) {
            return extractStreaming(normalizedSource, sheetName);
        }

        try (InputStream inputStream = Files.newInputStream(normalizedSource);
             Workbook workbook = WorkbookFactory.create(inputStream)) {

            if (workbook.getNumberOfSheets() == 0) {
                throw new EtlException("Le classeur ne contient aucune feuille.");
            }
            if (!(workbook instanceof XSSFWorkbook)) {
                throw new EtlException("Le fichier sélectionné n'est pas un classeur .xlsx valide.");
            }

            Sheet sheet = resolveSheet(workbook, sheetName);
            HeaderDetection header = detectHeader(sheet);
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            DataFormatter formatter = new DataFormatter(Locale.FRANCE, true);
            List<ChauffeurRecord> records = new ArrayList<>();

            for (int rowIndex = header.rowIndex() + 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null || isCompletelyEmpty(row)) {
                    continue;
                }

                String[] values = new String[10];
                List<ValidationError> extractionErrors = new ArrayList<>();
                String[] fields = FIELDS;
                for (int fieldIndex = 0; fieldIndex < fields.length; fieldIndex++) {
                    CellReading reading;
                    if ("site".equals(fields[fieldIndex])
                            && !header.columns().containsKey("site")
                            && !header.hourColumns().isEmpty()) {
                        reading = readFirstHourCell(row, header.hourColumns(), formatter, evaluator);
                    } else {
                        reading = readCell(
                                row, header.columns().get(fields[fieldIndex]), formatter, evaluator
                        );
                    }
                    values[fieldIndex] = reading.value();
                    if (reading.error() != null) {
                        extractionErrors.add(new ValidationError(
                                rowIndex + 1,
                                fields[fieldIndex],
                                reading.value(),
                                reading.error()
                        ));
                    }
                }

                Chauffeur chauffeur = new Chauffeur(
                        values[0], values[1], values[2], values[3], values[4],
                        values[5], values[6], values[7], values[8], values[9]
                );
                records.add(new ChauffeurRecord(rowIndex + 1, chauffeur, extractionErrors,
                        extraValues(row, header, evaluator)));
            }

            if (records.isEmpty()) {
                throw new EtlException("Le fichier ne contient aucune ligne de données exploitable.");
            }
            return List.copyOf(records);
        } catch (EtlException exception) {
            throw exception;
        } catch (IOException exception) {
            throw new EtlException(
                    "Impossible de lire le fichier. Vérifiez qu'il n'est pas verrouillé et que vous disposez des droits d'accès.",
                    exception
            );
        } catch (RuntimeException exception) {
            throw new EtlException(
                    "Le fichier est illisible, corrompu ou son format .xlsx est invalide.",
                    exception
            );
        }
    }

    private List<ChauffeurRecord> extractStreaming(Path source, String sheetName) throws IOException {
        List<ChauffeurRecord> records = new ArrayList<>();
        StreamSummary summary = stream(source, sheetName, null,
                (rowIndex, chauffeur, extractionErrors, extraColumns) ->
                        records.add(new ChauffeurRecord(rowIndex, chauffeur, extractionErrors, extraColumns))
        );
        if (summary.dataRows() == 0) {
            throw new EtlException("Le fichier ne contient aucune ligne de données exploitable.");
        }
        return List.copyOf(records);
    }

    /**
     * Lit la feuille selectionnee ligne par ligne et pousse chaque record vers le consommateur
     * sans jamais conserver la totalite des donnees en memoire.
     */
    public StreamSummary stream(Path source, String sheetName, StreamListener listener,
                                RowConsumer consumer) throws IOException {
        Path normalizedSource = validateSource(source);
        if (consumer == null) {
            throw new IllegalArgumentException("Le consommateur de lignes est obligatoire");
        }

        try (OPCPackage packageFile = OPCPackage.open(normalizedSource.toFile(), PackageAccess.READ)) {
            XSSFReader reader = new XSSFReader(packageFile);
            reader.setUseReadOnlySharedStringsTable(true);
            SharedStrings sharedStrings = reader.getSharedStringsTable();
            StylesTable styles = reader.getStylesTable();

            XSSFReader.SheetIterator sheets = reader.getSheetIterator();
            InputStream selected = null;
            long totalBytes = 0L;
            while (sheets.hasNext()) {
                InputStream stream = sheets.next();
                if (isSelectedSheet(sheetName, sheets.getSheetName())) {
                    selected = stream;
                    totalBytes = sheets.getSheetPart().getSize();
                    break;
                }
                stream.close();
            }
            if (selected == null) {
                throw new EtlException("Feuille introuvable dans le classeur : " + sheetName);
            }

            try (InputStream sheet = selected) {
                DataFormatter formatter = new DataFormatter(Locale.FRANCE, true);
                CountingInputStream counting = new CountingInputStream(sheet);
                StreamingRowPump pump = new StreamingRowPump(consumer, listener, counting, totalBytes);
                XSSFSheetXMLHandler handler = new XSSFSheetXMLHandler(
                        styles, sharedStrings, pump, formatter, false
                );
                XMLReader parser = XMLReaderFactory.createXMLReader();
                parser.setContentHandler(handler);
                parser.parse(new InputSource(counting));
                pump.flushBufferedRows();

                if (listener != null) {
                    listener.onProgress(pump.dataRows(), counting.count(), Math.max(totalBytes, 1L));
                }
                if (pump.dataRows() == 0) {
                    throw new EtlException("Le fichier ne contient aucune ligne de données exploitable.");
                }
                return new StreamSummary(pump.dataRows());
            }
        } catch (EtlException exception) {
            throw exception;
        } catch (HeaderDetectionException exception) {
            throw new EtlException(exception.getMessage());
        } catch (UncheckedIOException exception) {
            throw asIoException(exception.getCause());
        } catch (IOException exception) {
            throw new EtlException(
                    "Impossible de lire le fichier. Vérifiez qu'il n'est pas verrouillé et que vous disposez des droits d'accès.",
                    exception
            );
        } catch (Exception exception) {
            throw new EtlException(
                    "Le fichier est illisible, corrompu ou son format .xlsx est invalide.",
                    exception
            );
        }
    }

    private IOException asIoException(Throwable throwable) {
        if (throwable instanceof IOException ioException) {
            return ioException;
        }
        return new IOException(throwable == null ? "Erreur d'ecriture inconnue" : throwable.getMessage(),
                throwable);
    }

    private final class StreamingRowPump implements XSSFSheetXMLHandler.SheetContentsHandler {

        private final RowConsumer consumer;
        private final StreamListener listener;
        private final CountingInputStream counting;
        private final long totalBytes;
        private final Map<Integer, String> currentValues = new LinkedHashMap<>();
        private final List<Integer> bufferedRowIndexes = new ArrayList<>();
        private final List<Map<Integer, String>> bufferedRows = new ArrayList<>();
        private Map<String, Integer> columns;
        private List<Integer> siteHourColumns = List.of();
        private List<Column> extraColumns = List.of();
        private int headerRowIndex = -1;
        private int dataRows;

        StreamingRowPump(RowConsumer consumer, StreamListener listener,
                         CountingInputStream counting, long totalBytes) {
            this.consumer = consumer;
            this.listener = listener;
            this.counting = counting;
            this.totalBytes = totalBytes;
        }

        @Override
        public void startRow(int rowNum) {
            currentValues.clear();
        }

        @Override
        public void cell(String cellReference, String formattedValue, XSSFComment comment) {
            currentValues.put(columnIndexOf(cellReference), formattedValue == null ? "" : formattedValue);
        }

        @Override
        public void endRow(int rowNum) {
            if (columns == null && rowNum < MAX_HEADER_SCAN_ROWS) {
                bufferedRowIndexes.add(rowNum);
                bufferedRows.add(new LinkedHashMap<>(currentValues));
                if (rowNum == MAX_HEADER_SCAN_ROWS - 1) {
                    resolveHeader();
                }
                return;
            }
            if (columns == null) {
                resolveHeader();
            }
            emit(rowNum, currentValues);
            if (listener != null && dataRows >= PROGRESS_INTERVAL
                    && dataRows % PROGRESS_INTERVAL == 0) {
                listener.onProgress(dataRows, counting.count(), totalBytes);
            }
        }

        /**
         * Emet les lignes mises en attente pendant la detection de l'en-tete. Sans cet
         * appel, un fichier comptant moins de lignes que la fenetre d'analyse perdrait ses
         * donnees.
         */
        void flushBufferedRows() {
            if (columns == null) {
                resolveHeader();
            }
            for (int index = 0; index < bufferedRows.size(); index++) {
                int rowIndex = bufferedRowIndexes.get(index);
                if (rowIndex > headerRowIndex) {
                    emit(rowIndex, bufferedRows.get(index));
                }
            }
            bufferedRows.clear();
            bufferedRowIndexes.clear();
        }

        private void resolveHeader() {
            Map<String, Integer> best = null;
            Map<Integer, String> bestLabels = Map.of();
            List<Integer> bestHourColumns = List.of();
            int bestRowIndex = -1;
            for (int index = 0; index < bufferedRows.size(); index++) {
                Map<Integer, String> row = bufferedRows.get(index);
                Map<String, Integer> candidate = new LinkedHashMap<>();
                for (Map.Entry<Integer, String> cell : row.entrySet()) {
                    applyHeaderAlias(cell.getValue(), cell.getKey(), candidate);
                }
                applyLayoutFallbacks(candidate);
                if (best == null || candidate.size() > best.size()) {
                    best = candidate;
                    bestLabels = row;
                    bestHourColumns = hourColumnsOf(row);
                    bestRowIndex = bufferedRowIndexes.get(index);
                }
            }
            boolean siteFromHours = best != null && !best.containsKey("site") && !bestHourColumns.isEmpty();
            int recognized = (best == null ? 0 : best.size()) + (siteFromHours ? 1 : 0);
            if (best == null || recognized < MINIMUM_RECOGNIZED_HEADERS) {
                throw new HeaderDetectionException(HEADER_UNRECOGNIZED_MESSAGE);
            }
            columns = best;
            if (siteFromHours) {
                siteHourColumns = bestHourColumns;
            }
            extraColumns = extraColumnsOf(bestLabels, best, siteFromHours);
            if (listener != null) {
                listener.onHeader(presentFields(best, siteFromHours), extraLabels(extraColumns));
            }
            headerRowIndex = bestRowIndex;
            for (int index = 0; index < bufferedRows.size(); index++) {
                int rowIndex = bufferedRowIndexes.get(index);
                if (rowIndex > headerRowIndex) {
                    emit(rowIndex, bufferedRows.get(index));
                }
            }
            bufferedRows.clear();
            bufferedRowIndexes.clear();
        }

        private List<Integer> hourColumnsOf(Map<Integer, String> row) {
            List<Integer> hourColumns = new ArrayList<>();
            for (Map.Entry<Integer, String> cell : row.entrySet()) {
                if (HOUR_HEADER.matcher(normalizeHeader(cell.getValue())).matches()) {
                    hourColumns.add(cell.getKey());
                }
            }
            Collections.sort(hourColumns);
            return List.copyOf(hourColumns);
        }

        /**
         * Colonnes de la source qui ne correspondent a aucun champ metier : elles sont
         * conservees telles quelles pour que rien ne soit perdu.
         */
        private List<Column> extraColumnsOf(Map<Integer, String> labels, Map<String, Integer> columns,
                                            boolean siteFromHours) {
            Set<Integer> used = new HashSet<>(columns.values());
            if (siteFromHours) {
                used.addAll(siteHourColumns);
            }
            List<Column> extras = new ArrayList<>();
            List<Integer> indexes = new ArrayList<>(labels.keySet());
            Collections.sort(indexes);
            for (Integer columnIndex : indexes) {
                if (!used.contains(columnIndex)) {
                    extras.add(new Column(columnIndex, labels.get(columnIndex)));
                }
            }
            return List.copyOf(extras);
        }

        private record Column(int index, String label) {
        }

        private List<String> extraLabels(List<Column> columns) {
            List<String> labels = new ArrayList<>(columns.size());
            for (Column column : columns) {
                labels.add(column.label());
            }
            return List.copyOf(labels);
        }

        private void emit(int rowIndex, Map<Integer, String> values) {
            boolean hasValue = false;
            for (String value : values.values()) {
                if (value != null && !value.isBlank()) {
                    hasValue = true;
                    break;
                }
            }
            if (!hasValue) {
                return;
            }

            String[] extracted = new String[FIELDS.length];
            List<ValidationError> errors = new ArrayList<>();
            for (int index = 0; index < FIELDS.length; index++) {
                Integer columnIndex = columns.get(FIELDS[index]);
                String value;
                if (columnIndex == null && "site".equals(FIELDS[index]) && !siteHourColumns.isEmpty()) {
                    value = firstHourValue(values);
                } else {
                    value = columnIndex == null ? null : values.get(columnIndex);
                }
                if (value == null) {
                    value = "";
                }
                if (EXCEL_ERROR.matcher(value).matches()) {
                    errors.add(new ValidationError(
                            rowIndex + 1, FIELDS[index], value, "La cellule contient une erreur Excel."
                    ));
                }
                extracted[index] = value;
            }

            dataRows++;
            consumer.accept(rowIndex + 1, new Chauffeur(
                    extracted[0], extracted[1], extracted[2], extracted[3], extracted[4],
                    extracted[5], extracted[6], extracted[7], extracted[8], extracted[9]
            ), errors, extraValues(values));
        }

        private List<ExtraColumn> extraValues(Map<Integer, String> values) {
            if (extraColumns.isEmpty()) {
                return List.of();
            }
            List<ExtraColumn> extras = new ArrayList<>(extraColumns.size());
            for (Column column : extraColumns) {
                String value = values.get(column.index());
                extras.add(new ExtraColumn(column.label(), value == null ? "" : value));
            }
            return extras;
        }

        private String firstHourValue(Map<Integer, String> values) {
            for (Integer hourColumn : siteHourColumns) {
                String value = values.get(hourColumn);
                if (value != null && !value.isBlank()) {
                    return value.trim();
                }
            }
            return "";
        }

        private int dataRows() {
            return dataRows;
        }
    }

    /**
     * Champs metier reellement reconnus dans la feuille source, dans l'ordre canonique.
     * Seuls ces champs sont ecrits dans le classeur de sortie.
     */
    public List<String> presentFields(Path source, String sheetName) throws IOException {
        Path normalizedSource = validateSource(source);
        try (InputStream inputStream = Files.newInputStream(normalizedSource);
             Workbook workbook = WorkbookFactory.create(inputStream)) {
            if (workbook.getNumberOfSheets() == 0) {
                throw new EtlException("Le classeur ne contient aucune feuille.");
            }
            if (!(workbook instanceof XSSFWorkbook)) {
                throw new EtlException("Le fichier sélectionné n'est pas un classeur .xlsx valide.");
            }
            Sheet sheet = resolveSheet(workbook, sheetName);
            HeaderDetection header = detectHeader(sheet);
            boolean siteFromHours = !header.columns().containsKey("site")
                    && !header.hourColumns().isEmpty();
            return presentFields(header.columns(), siteFromHours);
        } catch (EtlException exception) {
            throw exception;
        } catch (IOException exception) {
            throw new EtlException(
                    "Impossible de lire le fichier. Vérifiez qu'il n'est pas verrouillé et que vous disposez des droits d'accès.",
                    exception
            );
        } catch (RuntimeException exception) {
            throw new EtlException(
                    "Le fichier est illisible, corrompu ou son format .xlsx est invalide.",
                    exception
            );
        }
    }

    private List<String> presentFields(Map<String, Integer> columns, boolean siteFromHours) {
        List<String> fields = new ArrayList<>();
        for (String field : FIELDS) {
            if (columns.containsKey(field) || ("site".equals(field) && siteFromHours)) {
                fields.add(field);
            }
        }
        return List.copyOf(fields);
    }

    public List<String> listSheetNames(Path source) throws IOException {
        Path normalized = validateSource(source);
        try (OPCPackage packageFile = OPCPackage.open(normalized.toFile(), PackageAccess.READ)) {
            XSSFReader reader = new XSSFReader(packageFile);
            List<String> names = new ArrayList<>();
            XSSFReader.SheetIterator sheets = reader.getSheetIterator();
            while (sheets.hasNext()) {
                try (InputStream sheet = sheets.next()) {
                    names.add(sheets.getSheetName());
                }
            }
            return List.copyOf(names);
        } catch (EtlException exception) {
            throw exception;
        } catch (Exception exception) {
            throw new EtlException("Impossible de lire les feuilles du classeur.", exception);
        }
    }

    private boolean isSelectedSheet(String requested, String candidate) {
        return requested == null || requested.isBlank() || requested.equals(candidate);
    }

    private Sheet resolveSheet(Workbook workbook, String sheetName) throws EtlException {
        if (sheetName == null || sheetName.isBlank()) {
            return workbook.getSheetAt(0);
        }
        Sheet sheet = workbook.getSheet(sheetName);
        if (sheet == null) {
            throw new EtlException("Feuille introuvable dans le classeur : " + sheetName);
        }
        return sheet;
    }

    private int columnIndexOf(String cellReference) {
        int index = 0;
        while (index < cellReference.length() && Character.isLetter(cellReference.charAt(index))) {
            index++;
        }
        return CellReference.convertColStringToIndex(cellReference.substring(0, index));
    }

    public List<Chauffeur> extractChauffeurs(Path source) throws IOException {
        return extract(source).stream()
                .map(ChauffeurRecord::chauffeur)
                .toList();
    }

    private Path validateSource(Path source) throws EtlException {
        if (source == null) {
            throw new EtlException("Aucun fichier source n'a été sélectionné.");
        }

        Path normalized = source.toAbsolutePath().normalize();
        String fileName = normalized.getFileName() == null ? "" : normalized.getFileName().toString();
        if (!fileName.toLowerCase(Locale.FRANCE).endsWith(".xlsx")) {
            throw new EtlException("Le fichier source doit être au format .xlsx.");
        }
        if (!Files.exists(normalized)) {
            throw new EtlException("Le fichier source n'existe pas : " + normalized);
        }
        if (!Files.isRegularFile(normalized)) {
            throw new EtlException("Le chemin source ne désigne pas un fichier : " + normalized);
        }
        if (!Files.isReadable(normalized)) {
            throw new EtlException("Le fichier source n'est pas lisible. Vérifiez les permissions du fichier.");
        }
        try {
            if (Files.size(normalized) == 0L) {
                throw new EtlException("Le fichier source est vide.");
            }
        } catch (EtlException exception) {
            throw exception;
        } catch (IOException exception) {
            throw new EtlException("Impossible de vérifier le fichier source.", exception);
        }
        return normalized;
    }

    private HeaderDetection detectHeader(Sheet sheet) throws EtlException {
        HeaderDetection best = null;
        int lastCandidate = Math.min(sheet.getLastRowNum(), MAX_HEADER_SCAN_ROWS - 1);

        for (int rowIndex = 0; rowIndex <= lastCandidate; rowIndex++) {
            Row row = sheet.getRow(rowIndex);
            if (row == null) {
                continue;
            }

            Map<String, Integer> columns = mapHeaders(row);
            applyLayoutFallbacks(columns);
            List<Integer> hourColumns = hourColumnsOf(row);
            boolean siteFromHours = !columns.containsKey("site") && !hourColumns.isEmpty();
            List<HeaderColumn> extras = headerExtraColumns(row, columns, hourColumns, siteFromHours);
            int recognized = columns.size() + (siteFromHours ? 1 : 0);
            int bestRecognized = best == null ? 0
                    : best.columns().size()
                    + ((!best.columns().containsKey("site") && !best.hourColumns().isEmpty()) ? 1 : 0);
            if (best == null || recognized > bestRecognized) {
                best = new HeaderDetection(rowIndex, columns, hourColumns, extras);
            }
        }

        if (best == null) {
            throw new EtlException(HEADER_UNRECOGNIZED_MESSAGE);
        }
        boolean siteFromHours = !best.columns().containsKey("site") && !best.hourColumns().isEmpty();
        int recognized = best.columns().size() + (siteFromHours ? 1 : 0);
        if (recognized < MINIMUM_RECOGNIZED_HEADERS) {
            throw new EtlException(HEADER_UNRECOGNIZED_MESSAGE);
        }
        return best;
    }

    private List<HeaderColumn> headerExtraColumns(Row row, Map<String, Integer> columns,
                                                  List<Integer> hourColumns, boolean siteFromHours) {
        Set<Integer> used = new HashSet<>(columns.values());
        if (siteFromHours) {
            used.addAll(hourColumns);
        }
        DataFormatter formatter = new DataFormatter(Locale.FRANCE, true);
        short lastCell = row.getLastCellNum();
        if (lastCell < 0) {
            return List.of();
        }
        List<HeaderColumn> extras = new ArrayList<>();
        for (int columnIndex = 0; columnIndex < lastCell; columnIndex++) {
            if (used.contains(columnIndex)) {
                continue;
            }
            Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (cell == null) {
                continue;
            }
            String label = formatter.formatCellValue(cell).trim();
            if (!label.isEmpty()) {
                extras.add(new HeaderColumn(columnIndex, label));
            }
        }
        return List.copyOf(extras);
    }

    private List<Integer> hourColumnsOf(Row row) {
        List<Integer> hourColumns = new ArrayList<>();
        short lastCell = row.getLastCellNum();
        if (lastCell < 0) {
            return hourColumns;
        }
        DataFormatter formatter = new DataFormatter(Locale.FRANCE);
        for (int columnIndex = 0; columnIndex < lastCell; columnIndex++) {
            Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (cell == null) {
                continue;
            }
            if (HOUR_HEADER.matcher(normalizeHeader(formatter.formatCellValue(cell))).matches()) {
                hourColumns.add(columnIndex);
            }
        }
        return List.copyOf(hourColumns);
    }

    private Map<String, Integer> mapHeaders(Row row) {
        Map<String, Integer> columns = new LinkedHashMap<>();
        short lastCell = row.getLastCellNum();
        if (lastCell < 0) {
            return columns;
        }

        DataFormatter formatter = new DataFormatter(Locale.FRANCE);
        for (int columnIndex = 0; columnIndex < lastCell; columnIndex++) {
            Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (cell == null) {
                continue;
            }
            applyHeaderAlias(formatter.formatCellValue(cell), columnIndex, columns);
        }
        return columns;
    }

    private void applyHeaderAlias(String rawHeader, int columnIndex, Map<String, Integer> columns) {
        String header = normalizeHeader(rawHeader);
        if (header.isEmpty()) {
            return;
        }
        for (Map.Entry<String, List<String>> entry : HEADER_ALIASES.entrySet()) {
            if (!columns.containsKey(entry.getKey())
                    && entry.getValue().stream().anyMatch(header::equals)) {
                columns.put(entry.getKey(), columnIndex);
                return;
            }
        }
    }

    private void applyLayoutFallbacks(Map<String, Integer> columns) {
        // "Inscription" in LiveTracking is the vehicle registration/plate, not its fleet
        // number. Keep it separate so the manager report does not silently put a plate in
        // the "Matricule camion" column when the source has no fleet-number column.
        if (!columns.containsKey("site") && columns.containsKey("emplacement")) {
            columns.put("site", columns.get("emplacement"));
        }
    }

    private CellReading readCell(Row row, Integer columnIndex, DataFormatter formatter,
                                 FormulaEvaluator evaluator) {
        if (columnIndex == null || columnIndex < 0) {
            return new CellReading("", null);
        }

        Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return new CellReading("", null);
        }
        if (cell.getCellType() == CellType.ERROR) {
            String error = FormulaError.forInt(cell.getErrorCellValue()).getString();
            return new CellReading(error, "La cellule contient une erreur Excel.");
        }
        if (cell.getCellType() == CellType.FORMULA) {
            try {
                CellValue evaluated = evaluator.evaluate(cell);
                if (evaluated != null && evaluated.getCellType() == CellType.ERROR) {
                    String error = FormulaError.forInt(evaluated.getErrorValue()).getString();
                    return new CellReading(error, "La formule retourne une erreur Excel.");
                }
                return new CellReading(formatter.formatCellValue(cell, evaluator), null);
            } catch (RuntimeException exception) {
                return new CellReading("", "La formule n'a pas pu être évaluée.");
            }
        }
        return new CellReading(formatter.formatCellValue(cell), null);
    }

    private List<ExtraColumn> extraValues(Row row, HeaderDetection header, FormulaEvaluator evaluator) {
        if (header.extraColumns().isEmpty()) {
            return List.of();
        }
        DataFormatter formatter = new DataFormatter(Locale.FRANCE, true);
        List<ExtraColumn> extras = new ArrayList<>(header.extraColumns().size());
        for (HeaderColumn column : header.extraColumns()) {
            CellReading reading = readCell(row, column.index(), formatter, evaluator);
            extras.add(new ExtraColumn(column.label(), reading.value()));
        }
        return extras;
    }

    private CellReading readFirstHourCell(Row row, List<Integer> hourColumns, DataFormatter formatter,
                                          FormulaEvaluator evaluator) {
        for (Integer hourColumn : hourColumns) {
            CellReading reading = readCell(row, hourColumn, formatter, evaluator);
            if (reading.error() == null && reading.value() != null && !reading.value().isBlank()) {
                return new CellReading(reading.value().trim(), null);
            }
        }
        return new CellReading("", null);
    }

    private boolean isCompletelyEmpty(Row row) {
        short lastCell = row.getLastCellNum();
        if (lastCell < 0) {
            return true;
        }
        for (int columnIndex = 0; columnIndex < lastCell; columnIndex++) {
            Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (cell != null && cell.getCellType() != CellType.BLANK) {
                return false;
            }
        }
        return true;
    }

    private String normalizeHeader(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }
        String withoutAccents = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        return HEADER_SEPARATOR.matcher(withoutAccents.toLowerCase(Locale.FRANCE))
                .replaceAll(" ")
                .trim();
    }

    private static Map<String, List<String>> createHeaderAliases() {
        Map<String, List<String>> aliases = new LinkedHashMap<>();
        aliases.put("statutMobile", List.of(
                "statut mobile", "statut", "statutmobile", "statut mobile chauffeur", "mobile status",
                "statut du mouvement", "statut mouvement", "statut vehicule", "movement status"
        ));
        aliases.put("description", List.of(
                "description", "libelle", "label", "description du vehicule", "description vehicule",
                "vehicle description", "asset description", "asset name", "asset", "equipment description"
        ));
        aliases.put("inscription", List.of("inscription", "date inscription", "date heure", "timestamp",
                "registration", "registration date", "registration date time"));
        aliases.put("numeroFlotte", List.of(
                "numero flotte", "numeroflotte", "numero de flotte", "n de flotte", "no flotte",
                "n flotte", "fleet number", "numero vehicule", "matricule camion", "matricule",
                "code camion", "camion", "immatriculation", "tracteur", "n tracteur", "num tracteur",
                "numero tracteur", "n de tracteur", "fleet no", "vehicle number", "truck number"
        ));
        aliases.put("site", List.of("site", "nom site", "depot", "position gps", "destination"));
        aliases.put("chauffeurNom", List.of(
                "chauffeur", "chauffeur nom", "chauffeurnom", "nom chauffeur", "nom prenom", "prenom nom", "driver name",
                "nom du chauffeur", "nom du conducteur", "conducteur", "driver", "driver full name", "name of driver"
        ));
        aliases.put("emplacement", List.of("emplacement", "position", "localisation", "location",
                "current location", "gps location"));
        aliases.put("dernierEvenement", List.of(
                "dernier evenement", "lastevenement", "last event", "evenement",
                "dernier evenement actif", "last active event"
        ));
        aliases.put("valeurDernierEvenement", List.of(
                "valeur dernier evenement", "valeur du dernier evenement", "last event value", "valeurlastevenement",
                "valeur du dernier evenement actif", "last active event value"
        ));
        aliases.put("vitesse", List.of("vitesse", "vitesse kmh", "vitesse km h", "speed", "speed kmh", "speed km h"));
        return Collections.unmodifiableMap(aliases);
    }

    private static final class HeaderDetectionException extends RuntimeException {
        HeaderDetectionException(String message) {
            super(message);
        }
    }

    /**
     * Reçoit chaque ligne exploitable au fil de la lecture de la feuille.
     */
    @FunctionalInterface
    public interface RowConsumer {
        void accept(int rowIndex, Chauffeur chauffeur, List<ValidationError> extractionErrors,
                    List<ExtraColumn> extraColumns);
    }

    /**
     * Reçoit l'avancement de la lecture, base sur les octets reellement consommes,
     * ainsi que les champs metier effectivement presents dans la feuille source.
     */
    public interface StreamListener {

        void onHeader(List<String> presentFields, List<String> extraLabels);

        default void onProgress(long dataRows, long bytesRead, long totalBytes) {
            // Progression facultative.
        }
    }

    public record StreamSummary(int dataRows) {
    }

    private static final class CountingInputStream extends FilterInputStream {

        private long count;

        CountingInputStream(InputStream delegate) {
            super(delegate);
        }

        @Override
        public int read() throws IOException {
            int value = super.read();
            if (value >= 0) {
                count++;
            }
            return value;
        }

        @Override
        public int read(byte[] buffer, int offset, int length) throws IOException {
            int read = super.read(buffer, offset, length);
            if (read > 0) {
                count += read;
            }
            return read;
        }

        long count() {
            return count;
        }
    }

    private record CellReading(String value, String error) {
    }

    private record HeaderDetection(int rowIndex, Map<String, Integer> columns,
                                   List<Integer> hourColumns, List<HeaderColumn> extraColumns) {
    }

    private record HeaderColumn(int index, String label) {
    }
}
