package com.etl.heures.service;

import com.etl.heures.model.EtlProgress;

/**
 * Écouteur de progression du pipeline, appelé depuis le thread de traitement.
 */
@FunctionalInterface
public interface EtlProgressListener {

    void onProgress(EtlProgress progress);
}
