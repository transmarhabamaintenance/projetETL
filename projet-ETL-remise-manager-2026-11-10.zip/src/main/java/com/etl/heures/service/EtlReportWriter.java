package com.etl.heures.service;

import com.etl.heures.EtlException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Écrit le rapport texte en UTF-8 (création ou remplacement).
 */
public class EtlReportWriter {

    public void write(Path reportPath, String content) throws EtlException {
        write(reportPath, content, false);
    }

    public void write(Path reportPath, String content, boolean append) throws EtlException {
        try {
            if (reportPath.getParent() != null) {
                Files.createDirectories(reportPath.getParent());
            }
            String entry = "========================================\n"
                    + "Exécution : " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                    + "\n========================================\n" + content + "\n\n";
            Files.writeString(reportPath, entry, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, append ? StandardOpenOption.APPEND : StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (IOException e) {
            throw new EtlException("Écriture du rapport impossible : " + reportPath, e);
        }
    }
}
