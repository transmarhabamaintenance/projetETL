package com.etl.heures.service;

import com.etl.heures.EtlException;
import com.etl.heures.aggregate.AggregationResult;
import com.etl.heures.aggregate.TrajetAggregator;
import com.etl.heures.extract.ExcelExtractor;
import com.etl.heures.extract.ExtractionResult;
import com.etl.heures.extract.RawRow;
import com.etl.heures.extract.RawRowConsumer;
import com.etl.heures.extract.StreamListener;
import com.etl.heures.extract.TrajetField;
import com.etl.heures.load.ExcelLoader;
import com.etl.heures.model.EtlProgress;
import com.etl.heures.model.EtlResult;
import com.etl.heures.model.FleetFilter;
import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import com.etl.heures.model.ValidationError;
import com.etl.heures.transform.TrajetTransformer;
import com.etl.heures.validation.TrajetValidator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Pipeline complet sur un fichier : extraction (mémoire ou flux selon la taille),
 * transformation, validation, agrégation, chargement Excel puis rapport texte.
 */
public class EtlService {

    static final int MAX_REPORTED_DETAILS = 5000;
    private static final int PROGRESS_EVERY_ROWS = 250;

    private final ExcelExtractor extractor;
    private final TrajetTransformer transformer;
    private final TrajetValidator validator;
    private final ExcelLoader loader;
    private final EtlReportWriter reportWriter;

    public EtlService() {
        this(new ExcelExtractor(), new TrajetTransformer(), new TrajetValidator(), new ExcelLoader(), new EtlReportWriter());
    }

    public EtlService(ExcelExtractor extractor, TrajetTransformer transformer, TrajetValidator validator,
                      ExcelLoader loader, EtlReportWriter reportWriter) {
        this.extractor = extractor;
        this.transformer = transformer;
        this.validator = validator;
        this.loader = loader;
        this.reportWriter = reportWriter;
    }

    public EtlResult execute(Path source, Path output, EtlProgressListener listener) throws EtlException {
        return execute(source, output, null, FleetFilter.TOUTES, null, null, listener, null, false);
    }

    public EtlResult execute(Path source, Path output, String sheetName, FleetFilter flotte,
                             LocalDate from, LocalDate to, EtlProgressListener listener) throws EtlException {
        return execute(source, output, sheetName, flotte, from, to, listener, null, false);
    }

    public EtlResult execute(Path source, Path output, String sheetName, FleetFilter flotte,
                             LocalDate from, LocalDate to, EtlProgressListener listener,
                             Path customOutput, boolean append) throws EtlException {
        long start = System.currentTimeMillis();
        Objects.requireNonNull(source, "Le fichier source est obligatoire");
        Objects.requireNonNull(output, "Le fichier de sortie est obligatoire");
        if (source.toAbsolutePath().normalize().equals(output.toAbsolutePath().normalize())) {
            throw new EtlException("Le fichier de sortie doit être différent du fichier source");
        }
        ensureOutputDirectory(output);
        FleetFilter fleet = flotte == null ? FleetFilter.TOUTES : flotte;
        EtlProgressListener sink = progress -> {
            if (listener != null) {
                listener.onProgress(progress);
            }
        };

        TrajetAggregator aggregator = new TrajetAggregator(fleet, from, to);
        List<ValidationError> reportedErrors = new ArrayList<>();
        Counters counters = new Counters();

        sink.onProgress(new EtlProgress(EtlProgress.Stage.EXTRACTION, 0, 0, 0.02, "Lecture du fichier source"));
        if (extractor.requiresStreaming(source)) {
            extractStreaming(source, sheetName, sink, aggregator, reportedErrors, counters);
        } else {
            ExtractionResult extraction = extractor.extract(source, sheetName);
            for (RawRow row : extraction.getRows()) {
                processRow(row, sink, aggregator, reportedErrors, counters);
            }
        }

        sink.onProgress(new EtlProgress(EtlProgress.Stage.VALIDATION, (int) counters.transformed, 0, 0.70,
                counters.errors + " erreur(s) de validation"));
        AggregationResult aggregation = aggregator.result();
        List<Journee> journees = aggregation.getJournees();
        sink.onProgress(new EtlProgress(EtlProgress.Stage.AGGREGATION, (int) counters.transformed, 0, 0.70,
                journees.size() + " journée(s) après fusion de " + aggregator.getMergedDuplicates() + " doublon(s)"));
        if (journees.isEmpty()) {
            throw new EtlException("Aucune donnée à charger : vérifiez le fichier source, la feuille "
                    + "et les filtres (flotte, période).");
        }
        LocalDate effectiveFrom = from != null ? from : journees.get(0).getDate();
        LocalDate effectiveTo = to != null ? to : journees.get(journees.size() - 1).getDate();

        Path targetOutput = customOutput != null && !customOutput.toString().isBlank() ? customOutput : output;
        if (source.toAbsolutePath().normalize().equals(targetOutput.toAbsolutePath().normalize())) {
            throw new EtlException("Le fichier de sortie doit être différent du fichier source");
        }
        boolean appendHistory = append && Files.exists(targetOutput);
        sink.onProgress(new EtlProgress(EtlProgress.Stage.LOADING, (int) counters.transformed, 0, 0.80,
                "Écriture du classeur heures de travail (" + journees.size() + " journées)"));
        if (appendHistory) {
            loader.append(targetOutput, journees);
        } else {
            loader.write(targetOutput, journees);
        }

        Path reportPath = buildReportPath(targetOutput);
        EtlResult result = new EtlResult(counters.extracted, counters.transformed, aggregator.getFilteredOut(),
                aggregator.getMergedDuplicates(), counters.errors, journees.size(),
                source.toString(), targetOutput.toString(), reportPath.toString(),
                System.currentTimeMillis() - start, reportedErrors);

        sink.onProgress(new EtlProgress(EtlProgress.Stage.REPORTING, (int) counters.transformed, 0, 0.94,
                "Écriture du rapport texte"));
        reportWriter.write(reportPath, EtlReportFormatter.format(source, result, fleet, effectiveFrom, effectiveTo),
                appendHistory);
        sink.onProgress(new EtlProgress(EtlProgress.Stage.COMPLETED, (int) counters.transformed, 0, 1.0,
                "Traitement terminé : " + journees.size() + " journée(s) chargée(s)"));
        return result;
    }

    static Path buildReportPath(Path output) {
        String name = output.getFileName().toString();
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        return output.resolveSibling(base + "_rapport.txt");
    }

    static double asymptotic(int rows) {
        return 1.0 - 1.0 / (1.0 + rows / 20000.0);
    }

    private void extractStreaming(Path source, String sheetName, EtlProgressListener sink,
                                  TrajetAggregator aggregator, List<ValidationError> reportedErrors,
                                  Counters counters) throws EtlException {
        StreamListener streamListener = new StreamListener() {
            @Override
            public void onHeader(List<TrajetField> presentFields, List<String> extraLabels) {
                sink.onProgress(new EtlProgress(EtlProgress.Stage.EXTRACTION, 0, 0, 0.05,
                        "En-têtes reconnus : " + presentFields.size() + " colonne(s)"));
            }

            @Override
            public void onProgress(int dataRows) {
                sink.onProgress(new EtlProgress(EtlProgress.Stage.EXTRACTION, dataRows, 0,
                        0.02 + 0.13 * asymptotic(dataRows), dataRows + " ligne(s) lue(s)"));
            }
        };
        RawRowConsumer consumer = row ->
                processRow(row, sink, aggregator, reportedErrors, counters);
        extractor.stream(source, sheetName, streamListener, consumer);
    }

    private void processRow(RawRow row, EtlProgressListener sink, TrajetAggregator aggregator,
                            List<ValidationError> reportedErrors, Counters counters) {
        counters.extracted++;
        counters.transformed++;
        JourneeRecord record = transformer.transform(row);
        List<ValidationError> rowErrors = validator.validateRow(record);
        counters.errors += rowErrors.size();
        if (!rowErrors.isEmpty() && reportedErrors.size() < MAX_REPORTED_DETAILS) {
            reportedErrors.addAll(rowErrors.subList(0,
                    (int) Math.min(rowErrors.size(), MAX_REPORTED_DETAILS - reportedErrors.size())));
        }
        if (rowErrors.isEmpty()) {
            aggregator.add(record);
        }
        if (counters.transformed == 1 || counters.transformed % PROGRESS_EVERY_ROWS == 0) {
            sink.onProgress(new EtlProgress(EtlProgress.Stage.TRANSFORMATION, (int) counters.transformed, 0,
                    0.15 + 0.55 * asymptotic((int) counters.transformed),
                    counters.transformed + " ligne(s) traitée(s)"));
        }
    }

    private static void ensureOutputDirectory(Path output) throws EtlException {
        if (output.getParent() == null) {
            return;
        }
        try {
            Files.createDirectories(output.getParent());
        } catch (IOException e) {
            throw new EtlException("Dossier de sortie indisponible : " + output.getParent(), e);
        }
    }

    private static final class Counters {
        private long extracted;
        private long transformed;
        private long errors;
    }
}
