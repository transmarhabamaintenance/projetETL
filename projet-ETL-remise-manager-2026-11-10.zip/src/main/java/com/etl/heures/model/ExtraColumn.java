package com.etl.heures.model;

/**
 * Colonne de la feuille source qui ne correspond à aucun champ métier du modèle.
 * Elle est conservée dans les lignes lues mais n'est pas recopiée dans le
 * classeur de sortie, dont la mise en page est fixe (Daily Trip Report).
 */
public record ExtraColumn(String label, String value) {

    public ExtraColumn {
        label = label == null ? "" : label;
        value = value == null ? "" : value;
    }
}
