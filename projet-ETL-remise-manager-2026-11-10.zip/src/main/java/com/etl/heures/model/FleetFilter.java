package com.etl.heures.model;

import java.util.Locale;

/**
 * Filtre appliqué sur la flotte détectée dans le titre du Daily Trip Report.
 */
public enum FleetFilter {

    VIVO("vivo"),
    TOTAL("TOTAL"),
    TOUTES("Toutes flottes");

    private final String label;

    FleetFilter(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    public boolean matches(String flotte) {
        if (this == TOUTES) {
            return true;
        }
        if (flotte == null || flotte.isBlank()) {
            return false;
        }
        return name().equalsIgnoreCase(flotte.strip());
    }

    @Override
    public String toString() {
        return label;
    }

    public static FleetFilter fromLabel(String label) {
        for (FleetFilter filter : values()) {
            if (filter.name().equalsIgnoreCase(label) || filter.label.equalsIgnoreCase(label)) {
                return filter;
            }
        }
        return TOUTES;
    }

    static String normalized(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).strip();
    }
}
