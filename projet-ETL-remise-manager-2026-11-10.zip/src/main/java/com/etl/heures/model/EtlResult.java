package com.etl.heures.model;

import java.util.List;
import java.util.Objects;

/**
 * Bilan complet d'une exécution du pipeline ETL.
 */
public record EtlResult(
        long extractedRows,
        long transformedRows,
        long filteredRows,
        long mergedDuplicates,
        long errors,
        long loadedRows,
        String sourcePath,
        String outputPath,
        String reportPath,
        long durationMillis,
        List<ValidationError> validationErrors
) {

    public EtlResult {
        validationErrors = List.copyOf(Objects.requireNonNull(validationErrors, "La liste des erreurs est obligatoire"));
        sourcePath = sourcePath == null ? "" : sourcePath;
        outputPath = outputPath == null ? "" : outputPath;
        reportPath = reportPath == null ? "" : reportPath;
        if (durationMillis < 0) {
            throw new IllegalArgumentException("La durée ne peut pas être négative");
        }
    }

    public long duration() {
        return durationMillis;
    }

    public long getExtractedRows() {
        return extractedRows;
    }

    public long getTransformedRows() {
        return transformedRows;
    }

    public long getFilteredRows() {
        return filteredRows;
    }

    public long getMergedDuplicates() {
        return mergedDuplicates;
    }

    public long getErrors() {
        return errors;
    }

    public long getLoadedRows() {
        return loadedRows;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public String getReportPath() {
        return reportPath;
    }

    public long getDurationMillis() {
        return durationMillis;
    }

    public List<ValidationError> getValidationErrors() {
        return validationErrors;
    }
}
