package com.etl.heures.model;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Ligne transformée d'une journée de travail d'un véhicule (une ligne du fichier
 * « heures de travail »). Les durées sont cumulables : plusieurs lignes partageant
 * la même clé (date, flotte, véhicule, chauffeur) sont agrégées en une seule.
 */
public class Journee {

    private LocalDate date;
    private String flotte = "";
    private String vehicule = "";
    private String chauffeur = "";
    private LocalTime heureDebut;
    private LocalTime heureFin;
    private Duration tempsConduite = Duration.ZERO;
    private Duration tempsAttente = Duration.ZERO;
    private Duration duree = Duration.ZERO;
    private Duration dureeRalenti = Duration.ZERO;
    private Double distance;
    private Double vitesseMoy;
    private Double vitesseMax;

    public Journee() {
    }

    public Journee(Journee other) {
        this.date = other.date;
        this.flotte = other.flotte;
        this.vehicule = other.vehicule;
        this.chauffeur = other.chauffeur;
        this.heureDebut = other.heureDebut;
        this.heureFin = other.heureFin;
        this.tempsConduite = other.tempsConduite;
        this.tempsAttente = other.tempsAttente;
        this.duree = other.duree;
        this.dureeRalenti = other.dureeRalenti;
        this.distance = other.distance;
        this.vitesseMoy = other.vitesseMoy;
        this.vitesseMax = other.vitesseMax;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getFlotte() {
        return flotte;
    }

    public void setFlotte(String flotte) {
        this.flotte = flotte == null ? "" : flotte;
    }

    public String getVehicule() {
        return vehicule;
    }

    public void setVehicule(String vehicule) {
        this.vehicule = vehicule == null ? "" : vehicule;
    }

    public String getChauffeur() {
        return chauffeur;
    }

    public void setChauffeur(String chauffeur) {
        this.chauffeur = chauffeur == null ? "" : chauffeur;
    }

    public LocalTime getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(LocalTime heureDebut) {
        this.heureDebut = heureDebut;
    }

    public LocalTime getHeureFin() {
        return heureFin;
    }

    public void setHeureFin(LocalTime heureFin) {
        this.heureFin = heureFin;
    }

    public Duration getTempsConduite() {
        return tempsConduite == null ? Duration.ZERO : tempsConduite;
    }

    public void setTempsConduite(Duration tempsConduite) {
        this.tempsConduite = tempsConduite == null ? Duration.ZERO : tempsConduite;
    }

    public Duration getTempsAttente() {
        return tempsAttente == null ? Duration.ZERO : tempsAttente;
    }

    public void setTempsAttente(Duration tempsAttente) {
        this.tempsAttente = tempsAttente == null ? Duration.ZERO : tempsAttente;
    }

    public Duration getDuree() {
        return duree == null ? Duration.ZERO : duree;
    }

    public void setDuree(Duration duree) {
        this.duree = duree == null ? Duration.ZERO : duree;
    }

    public Duration getDureeRalenti() {
        return dureeRalenti == null ? Duration.ZERO : dureeRalenti;
    }

    public void setDureeRalenti(Duration dureeRalenti) {
        this.dureeRalenti = dureeRalenti == null ? Duration.ZERO : dureeRalenti;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Double getVitesseMoy() {
        return vitesseMoy;
    }

    public void setVitesseMoy(Double vitesseMoy) {
        this.vitesseMoy = vitesseMoy;
    }

    public Double getVitesseMax() {
        return vitesseMax;
    }

    public void setVitesseMax(Double vitesseMax) {
        this.vitesseMax = vitesseMax;
    }
}
