package com.etl.heures.model;

/**
 * État d'avancement du pipeline, publié à l'interface graphique.
 */
public record EtlProgress(Stage stage, int processedRows, int totalRows, double progress, String message) {

    public EtlProgress {
        progress = Math.max(0.0, Math.min(1.0, progress));
        message = message == null ? "" : message;
    }

    public Stage getStage() {
        return stage;
    }

    public int getProcessedRows() {
        return processedRows;
    }

    public int getTotalRows() {
        return totalRows;
    }

    public double getProgress() {
        return progress;
    }

    public String getMessage() {
        return message;
    }

    public enum Stage {
        EXTRACTION,
        TRANSFORMATION,
        VALIDATION,
        AGGREGATION,
        LOADING,
        REPORTING,
        COMPLETED
    }
}
