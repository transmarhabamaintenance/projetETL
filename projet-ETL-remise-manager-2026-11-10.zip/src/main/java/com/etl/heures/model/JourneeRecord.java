package com.etl.heures.model;

import java.util.List;
import java.util.Objects;

/**
 * Une ligne lue puis transformée, avec ses erreurs de lecture éventuelles
 * et les colonnes supplémentaires de la feuille source.
 */
public record JourneeRecord(int rowIndex, Journee journee, List<ValidationError> errors, List<ExtraColumn> extras) {

    public JourneeRecord {
        if (rowIndex < 1) {
            throw new IllegalArgumentException("Le numéro de ligne doit être supérieur ou égal à 1");
        }
        journee = Objects.requireNonNull(journee, "La journée est obligatoire");
        errors = List.copyOf(Objects.requireNonNull(errors, "La liste des erreurs est obligatoire"));
        extras = List.copyOf(Objects.requireNonNull(extras, "La liste des colonnes supplémentaires est obligatoire"));
    }

    public JourneeRecord(int rowIndex, Journee journee) {
        this(rowIndex, journee, List.of(), List.of());
    }

    public int getRowIndex() {
        return rowIndex;
    }

    public Journee getJournee() {
        return journee;
    }

    public List<ValidationError> getErrors() {
        return errors;
    }

    public List<ExtraColumn> getExtras() {
        return extras;
    }
}
