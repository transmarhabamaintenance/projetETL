package com.etl.heures.load;

import com.etl.heures.EtlException;
import com.etl.heures.model.Journee;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Écrit le classeur « heures de travail » : feuille DATA BASE (17 colonnes,
 * formules d'heures héritées du format d'origine) et feuille INDEX vide.
 * L'écriture est atomique (fichier temporaire puis déplacement).
 */
public class ExcelLoader {

    private static final String DATA_SHEET = "DATA BASE";
    private static final String INDEX_SHEET = "INDEX";
    private static final String DATE_FORMAT = "mm-dd-yy";
    private static final String TIME_FORMAT = "[$-F400]h:mm:ss\\ AM/PM";

    private static final String[] HEADERS = {
            "Date",
            "total / vivo",
            "Description du bien",
            "CHAUFFEUR",
            "Première heure de début du trajet",
            "Première heure de début du trajet",
            "Heure de fin du dernier trajet2",
            "Heure de fin du dernier trajet",
            "WT",
            "HRS DE TRAVAIL",
            "Durée de conduite (hh:mm:ss)",
            "Durée de conduite (hh:mm:ss)2",
            "Temps d'attente (hh:mm:ss)",
            "REPOS quotidien",
            "Raison",
            "emplacement de nuite",
            "emplacement de depart"
    };

    private static final int HEADER_BOLD_UNTIL = 12;

    private static final double[] COLUMN_WIDTHS = {
            23.85546875,   // A Date
            20.42578125,   // B total / vivo
            20.28515625,   // C Description du bien
            24.28515625,   // D CHAUFFEUR
            32.85546875,   // E début
            31.85546875,   // F début (formule)
            28.140625,     // G fin
            0,             // H fin (formule) : largeur par défaut
            23.7109375,    // I WT
            18.7109375,    // J HRS DE TRAVAIL
            20.28515625,   // K conduite
            0,             // L conduite (formule) : largeur par défaut
            0,             // M attente : largeur par défaut
            0,             // N REPOS : largeur par défaut
            20.28515625,   // O Raison
            0,             // P nuite : largeur par défaut
            20.42578125    // Q depart
    };

    public void write(Path output, List<Journee> journees) throws EtlException {
        writeOrAppend(output, journees, false);
    }

    public void append(Path output, List<Journee> journees) throws EtlException {
        writeOrAppend(output, journees, true);
    }

    public void writeOrAppend(Path output, List<Journee> journees, boolean append) throws EtlException {
        if (journees == null || journees.isEmpty()) {
            throw new EtlException("Aucune journée à écrire dans le classeur");
        }
        ensureOutputDirectory(output);
        try (XSSFWorkbook workbook = append && Files.isRegularFile(output)
                ? openWorkbook(output) : new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.getSheet(DATA_SHEET) == null
                    ? workbook.createSheet(DATA_SHEET) : workbook.getSheet(DATA_SHEET);
            if (workbook.getSheet(INDEX_SHEET) == null) workbook.createSheet(INDEX_SHEET);

            Font normal = font(workbook, false);
            Font bold = font(workbook, true);

            CellStyle textStyle = workbook.createCellStyle();
            textStyle.setFont(normal);
            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFont(bold);
            CellStyle dateStyle = workbook.createCellStyle();
            dateStyle.setFont(normal);
            dateStyle.setDataFormat(workbook.createDataFormat().getFormat(DATE_FORMAT));
            CellStyle timeStyle = workbook.createCellStyle();
            timeStyle.setFont(normal);
            timeStyle.setDataFormat(workbook.createDataFormat().getFormat(TIME_FORMAT));

            if (sheet.getPhysicalNumberOfRows() == 0) writeHeader(sheet, textStyle, headerStyle);

            int rowIndex = Math.max(1, sheet.getLastRowNum() + 1);
            for (Journee journee : journees) {
                writeDataRow(sheet, rowIndex++, journee, textStyle, dateStyle, timeStyle);
            }

            for (int i = 0; i < COLUMN_WIDTHS.length; i++) {
                if (COLUMN_WIDTHS[i] > 0) {
                    sheet.setColumnWidth(i, (int) Math.round(COLUMN_WIDTHS[i] * 256));
                }
            }

            writeAtomically(workbook, output);
        } catch (IOException e) {
            throw new EtlException("Écriture du fichier Excel impossible : " + output, e);
        }
    }

    private static XSSFWorkbook openWorkbook(Path path) throws IOException {
        try (InputStream input = Files.newInputStream(path)) {
            return new XSSFWorkbook(input);
        }
    }

    private static void writeHeader(XSSFSheet sheet, CellStyle plainStyle, CellStyle boldStyle) {
        XSSFRow row = sheet.createRow(0);
        for (int i = 0; i < HEADERS.length; i++) {
            XSSFCell cell = row.createCell(i);
            cell.setCellValue(HEADERS[i]);
            cell.setCellStyle(i <= HEADER_BOLD_UNTIL ? boldStyle : plainStyle);
        }
    }

    private static void writeDataRow(XSSFSheet sheet, int rowIndex, Journee journee,
                                     CellStyle textStyle, CellStyle dateStyle, CellStyle timeStyle) {
        int r = rowIndex + 1;
        XSSFRow row = sheet.createRow(rowIndex);

        XSSFCell dateCell = row.createCell(0);
        if (journee.getDate() != null) {
            dateCell.setCellValue(journee.getDate());
        }
        dateCell.setCellStyle(dateStyle);

        setText(row, 1, journee.getFlotte(), textStyle);
        setText(row, 2, journee.getVehicule(), textStyle);
        setText(row, 3, journee.getChauffeur(), textStyle);

        boolean debut = journee.getDate() != null && journee.getHeureDebut() != null;
        boolean fin = journee.getDate() != null && journee.getHeureFin() != null;
        if (debut) {
            XSSFCell cell = row.createCell(4);
            cell.setCellValue(LocalDateTime.of(journee.getDate(), journee.getHeureDebut()));
            cell.setCellStyle(timeStyle);
            setFormula(row, 5, "+E" + r + "-INT(E" + r + ")", timeStyle);
        }
        if (fin) {
            XSSFCell cell = row.createCell(6);
            cell.setCellValue(LocalDateTime.of(journee.getDate(), journee.getHeureFin()));
            cell.setCellStyle(timeStyle);
            setFormula(row, 7, "+G" + r + "-INT(G" + r + ")", timeStyle);
        }
        if (debut && fin) {
            setFormula(row, 8, "+G" + r + "-E" + r, timeStyle);
            setFormula(row, 9, "+I" + r + "-INT(I" + r + ")", timeStyle);
            XSSFCell repos = row.createCell(13);
            repos.setCellValue(0.5);
            repos.setCellStyle(timeStyle);
        }
        setText(row, 10, formatDuration(journee.getTempsConduite()), timeStyle);
        setFormula(row, 11, "+K" + r + "-INT(K" + r + ")", timeStyle);
        setText(row, 12, formatDuration(journee.getTempsAttente()), timeStyle);
    }

    private static void setText(XSSFRow row, int column, String value, CellStyle cellStyle) {
        XSSFCell cell = row.createCell(column);
        if (value != null && !value.isEmpty()) {
            cell.setCellValue(value);
        }
        cell.setCellStyle(cellStyle);
    }

    private static void setFormula(XSSFRow row, int column, String formula, CellStyle cellStyle) {
        XSSFCell cell = row.createCell(column);
        cell.setCellFormula(formula);
        cell.setCellStyle(cellStyle);
    }

    private static void writeAtomically(XSSFWorkbook workbook, Path output) throws IOException {
        Path temp = output.resolveSibling("etl-" + System.currentTimeMillis() + ".xlsx.tmp");
        try {
            try (OutputStream out = Files.newOutputStream(temp,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                workbook.write(out);
            }
            try {
                Files.move(temp, output, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, output, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temp);
        }
    }

    private static void ensureOutputDirectory(Path output) throws EtlException {
        if (output.getParent() == null) {
            return;
        }
        try {
            Files.createDirectories(output.getParent());
        } catch (IOException e) {
            throw new EtlException("Dossier de sortie indisponible : " + output.getParent(), e);
        }
    }

    private static Font font(XSSFWorkbook workbook, boolean bold) {
        Font value = workbook.createFont();
        value.setFontName("Arial");
        value.setFontHeightInPoints((short) 10);
        value.setBold(bold);
        return value;
    }

    static String formatDuration(Duration duration) {
        long total = duration == null ? 0 : duration.getSeconds();
        long hours = total / 3600;
        long minutes = (total % 3600) / 60;
        long seconds = total % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
