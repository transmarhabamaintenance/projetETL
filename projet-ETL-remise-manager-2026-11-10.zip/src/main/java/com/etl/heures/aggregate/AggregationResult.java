package com.etl.heures.aggregate;

import com.etl.heures.model.Journee;

import java.util.List;

/**
 * Résultat de l'agrégation : les journées fusionnées, triées, et le nombre
 * de lignes écartées par les filtres (flotte, période).
 */
public record AggregationResult(List<Journee> journees, long filteredOut) {

    public AggregationResult {
        journees = journees == null ? List.of() : List.copyOf(journees);
    }

    public List<Journee> getJournees() {
        return journees;
    }

    public long getFilteredOut() {
        return filteredOut;
    }
}
