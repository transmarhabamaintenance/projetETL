package com.etl.heures.aggregate;

import com.etl.heures.model.FleetFilter;
import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import com.etl.heures.transform.TrajetTransformer;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Regroupe les journées valides par clé (date, flotte, véhicule, chauffeur) :
 * plusieurs lignes du fichier source décrivant la même journée sont fusionnées
 * (somme des durées et distances, début au plus tôt, fin au plus tard,
 * vitesse maximale la plus haute, vitesse moyenne recalculée).
 */
public class TrajetAggregator {

    private static final Comparator<Journee> ORDER = Comparator
            .comparing(Journee::getDate, Comparator.nullsLast(Comparator.naturalOrder()))
            .thenComparing(journee -> journee.getVehicule().toLowerCase(Locale.ROOT))
            .thenComparing(journee -> journee.getChauffeur().toLowerCase(Locale.ROOT))
            .thenComparing(Journee::getHeureDebut, Comparator.nullsLast(Comparator.naturalOrder()));

    private final FleetFilter fleet;
    private final LocalDate from;
    private final LocalDate to;
    private final Map<String, Journee> byKey = new LinkedHashMap<>();
    private long filteredOut;
    private long mergedDuplicates;

    public TrajetAggregator(FleetFilter fleet, LocalDate from, LocalDate to) {
        this.fleet = fleet == null ? FleetFilter.TOUTES : fleet;
        this.from = from;
        this.to = to;
    }

    /**
     * Ajoute une ligne transformée. Renvoie false si la ligne est écartée
     * par le filtre de flotte ou hors période demandée.
     */
    public boolean add(JourneeRecord record) {
        Journee journee = record.journee();
        if (!fleet.matches(journee.getFlotte()) || outOfRange(journee.getDate())) {
            filteredOut++;
            return false;
        }
        String key = journeyKey(journee);
        Journee existing = byKey.get(key);
        if (existing == null) {
            byKey.put(key, new Journee(journee));
        } else {
            merge(existing, journee);
            mergedDuplicates++;
        }
        return true;
    }

    public AggregationResult result() {
        List<Journee> journees = new ArrayList<>(byKey.values());
        for (Journee journee : journees) {
            recomputeVitesseMoy(journee);
        }
        journees.sort(ORDER);
        return new AggregationResult(journees, filteredOut);
    }

    public long getFilteredOut() {
        return filteredOut;
    }

    public long getMergedDuplicates() {
        return mergedDuplicates;
    }

    private static String journeyKey(Journee journee) {
        return journee.getDate() + "|" + journee.getFlotte().toLowerCase(Locale.ROOT)
                + "|" + journee.getVehicule().toLowerCase(Locale.ROOT)
                + "|" + journee.getChauffeur().toLowerCase(Locale.ROOT);
    }

    private boolean outOfRange(LocalDate date) {
        if (date == null) {
            return false;
        }
        if (from != null && date.isBefore(from)) {
            return true;
        }
        return to != null && date.isAfter(to);
    }

    private void merge(Journee target, Journee other) {
        target.setTempsConduite(target.getTempsConduite().plus(other.getTempsConduite()));
        target.setTempsAttente(target.getTempsAttente().plus(other.getTempsAttente()));
        target.setDuree(target.getDuree().plus(other.getDuree()));
        target.setDureeRalenti(target.getDureeRalenti().plus(other.getDureeRalenti()));
        target.setHeureDebut(minTime(target.getHeureDebut(), other.getHeureDebut()));
        target.setHeureFin(maxTime(target.getHeureFin(), other.getHeureFin()));
        target.setDistance(sum(target.getDistance(), other.getDistance()));
        target.setVitesseMax(max(target.getVitesseMax(), other.getVitesseMax()));
        target.setVitesseMoy(null);
    }

    private static void recomputeVitesseMoy(Journee journee) {
        Double distance = journee.getDistance();
        if (distance == null) {
            return;
        }
        double hours = journee.getTempsConduite().getSeconds() / 3600.0;
        if (hours > 0) {
            journee.setVitesseMoy(TrajetTransformer.round5(distance / hours));
        } else if (journee.getVitesseMoy() == null) {
            // pas de conduite : aucune vitesse moyenne calculable
        }
    }

    private static LocalTime minTime(LocalTime a, LocalTime b) {
        if (a == null) {
            return b;
        }
        if (b == null) {
            return a;
        }
        return a.isBefore(b) ? a : b;
    }

    private static LocalTime maxTime(LocalTime a, LocalTime b) {
        if (a == null) {
            return b;
        }
        if (b == null) {
            return a;
        }
        return a.isAfter(b) ? a : b;
    }

    private static Double sum(Double a, Double b) {
        if (a == null) {
            return b;
        }
        if (b == null) {
            return a;
        }
        return a + b;
    }

    private static Double max(Double a, Double b) {
        if (a == null) {
            return b;
        }
        if (b == null) {
            return a;
        }
        return Math.max(a, b);
    }
}
