package com.etl.heures.batch;

import com.etl.heures.model.FleetFilter;
import com.etl.heures.model.ValidationError;

import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * Met en forme le rapport texte récapitulatif d'un traitement par lot.
 */
public final class BatchReportFormatter {

    static final int MAX_REPORTED_ERRORS_PER_FILE = 200;
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private BatchReportFormatter() {
    }

    public static String format(Path directory, BatchResult result, FleetFilter flotte, LocalDate from, LocalDate to) {
        StringBuilder out = new StringBuilder();
        out.append("=======================================\n");
        out.append("  RAPPORT ETL BATCH - HEURES DE TRAVAIL\n");
        out.append("=======================================\n\n");
        out.append("Dossier source        : ").append(directory).append('\n');
        out.append("Flotte                : ").append(flotte == null ? "Toutes flottes" : flotte.label()).append('\n');
        out.append("Période               : De ").append(from == null ? "-" : DAY.format(from))
                .append(" à ").append(to == null ? "-" : DAY.format(to)).append('\n');
        out.append('\n');

        long merged = 0;
        long skipped = 0;
        long failed = 0;
        for (BatchFileResult file : result.getFiles()) {
            switch (file.getStatus()) {
                case MERGED -> merged++;
                case SKIPPED -> skipped++;
                case FAILED -> failed++;
            }
        }
        out.append("Fichiers détectés     : ").append(result.getFiles().size()).append('\n');
        out.append("  - traités           : ").append(merged).append('\n');
        out.append("  - ignorés           : ").append(skipped).append('\n');
        out.append("  - en échec          : ").append(failed).append('\n');
        out.append('\n');
        out.append("--- FICHIERS ---\n");
        for (BatchFileResult file : result.getFiles()) {
            switch (file.getStatus()) {
                case MERGED -> out.append("[FUSIONNÉ] ").append(file.getFileName()).append(" : ")
                        .append(file.getExtractedRows()).append(" ligne(s) intégrée(s), ")
                        .append(file.getMergedDuplicates()).append(" doublon(s) fusionné(s)\n");
                case SKIPPED -> out.append("[IGNORÉ]   ").append(file.getFileName()).append(" : ")
                        .append(file.getMessage()).append('\n');
                case FAILED -> out.append("[ÉCHEC]    ").append(file.getFileName()).append(" : ")
                        .append(file.getMessage()).append('\n');
            }
        }

        out.append('\n');
        out.append("--- STATISTIQUES GLOBALES ---\n");
        out.append("Lignes extraites      : ").append(number(result.getExtractedRows())).append('\n');
        out.append("Lignes filtrées       : ").append(number(result.getFilteredRows())).append('\n');
        out.append("Doublons fusionnés    : ").append(number(result.getMergedDuplicates())).append('\n');
        out.append("Erreurs de validation : ").append(number(result.getErrors())).append('\n');
        out.append("Journées chargées     : ").append(number(result.getLoadedRows())).append('\n');
        out.append("Durée du traitement   : ").append(String.format(Locale.FRANCE, "%,.3f", result.getDurationMillis() / 1000.0))
                .append(" s\n");

        List<ValidationError> errors = result.getValidationErrors();
        if (errors.isEmpty()) {
            out.append("\nAucune erreur de validation.\n");
            return out.toString();
        }
        out.append("\n--- ERREURS DE VALIDATION (").append(errors.size()).append(") ---\n");
        int shown = 0;
        for (ValidationError error : errors) {
            if (shown >= MAX_REPORTED_ERRORS_PER_FILE) {
                out.append("... et ").append(errors.size() - shown).append(" autre(s) erreur(s) non affichée(s)\n");
                break;
            }
            out.append("[ligne ").append(error.getRowIndex()).append("] ")
                    .append(error.getColumn()).append(" = « ").append(error.getValue()).append(" » : ")
                    .append(error.getDescription()).append('\n');
            shown++;
        }
        return out.toString();
    }

    private static String number(long value) {
        return String.format(Locale.FRANCE, "%,d", value);
    }
}
