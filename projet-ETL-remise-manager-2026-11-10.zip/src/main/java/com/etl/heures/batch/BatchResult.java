package com.etl.heures.batch;

import com.etl.heures.model.ValidationError;

import java.util.List;

/**
 * Bilan complet d'un traitement par lot (plusieurs fichiers fusionnés).
 */
public record BatchResult(
        List<BatchFileResult> files,
        long extractedRows,
        long filteredRows,
        long mergedDuplicates,
        long errors,
        int loadedRows,
        String directoryPath,
        String outputPath,
        String reportPath,
        long durationMillis,
        List<ValidationError> validationErrors
) {

    public BatchResult {
        files = files == null ? List.of() : List.copyOf(files);
        validationErrors = validationErrors == null ? List.of() : List.copyOf(validationErrors);
        directoryPath = directoryPath == null ? "" : directoryPath;
        outputPath = outputPath == null ? "" : outputPath;
        reportPath = reportPath == null ? "" : reportPath;
    }

    public List<BatchFileResult> getFiles() {
        return files;
    }

    public long getExtractedRows() {
        return extractedRows;
    }

    public long getFilteredRows() {
        return filteredRows;
    }

    public long getMergedDuplicates() {
        return mergedDuplicates;
    }

    public long getErrors() {
        return errors;
    }

    public int getLoadedRows() {
        return loadedRows;
    }

    public String getDirectoryPath() {
        return directoryPath;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public String getReportPath() {
        return reportPath;
    }

    public long getDurationMillis() {
        return durationMillis;
    }

    public List<ValidationError> getValidationErrors() {
        return validationErrors;
    }
}
