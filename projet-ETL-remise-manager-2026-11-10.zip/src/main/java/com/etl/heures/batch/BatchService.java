package com.etl.heures.batch;

import com.etl.heures.EtlException;
import com.etl.heures.aggregate.AggregationResult;
import com.etl.heures.aggregate.TrajetAggregator;
import com.etl.heures.extract.ExcelExtractor;
import com.etl.heures.extract.ExtractionResult;
import com.etl.heures.extract.RawRow;
import com.etl.heures.extract.RawRowConsumer;
import com.etl.heures.extract.StreamListener;
import com.etl.heures.extract.TrajetField;
import com.etl.heures.load.ExcelLoader;
import com.etl.heures.model.EtlProgress;
import com.etl.heures.model.FleetFilter;
import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import com.etl.heures.model.ValidationError;
import com.etl.heures.service.EtlProgressListener;
import com.etl.heures.service.EtlReportWriter;
import com.etl.heures.transform.TrajetTransformer;
import com.etl.heures.validation.TrajetValidator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Traitement par lot : tous les .xlsx d'un dossier sont fusionnés dans un
 * même agrégateur, puis un seul rapport Excel et un rapport texte sont écrits.
 */
public class BatchService {

    static final int MAX_REPORTED_DETAILS = 5000;
    private static final int PROGRESS_EVERY_ROWS = 250;
    private static final Pattern GENERATED_OUTPUT = Pattern.compile("(?i)_heures_de_travail(?:_\\d+)?\\.xlsx$");

    private final ExcelExtractor extractor;
    private final TrajetTransformer transformer;
    private final TrajetValidator validator;
    private final ExcelLoader loader;
    private final EtlReportWriter reportWriter;

    public BatchService() {
        this(new ExcelExtractor(), new TrajetTransformer(), new TrajetValidator(), new ExcelLoader(), new EtlReportWriter());
    }

    public BatchService(ExcelExtractor extractor, TrajetTransformer transformer, TrajetValidator validator,
                        ExcelLoader loader, EtlReportWriter reportWriter) {
        this.extractor = extractor;
        this.transformer = transformer;
        this.validator = validator;
        this.loader = loader;
        this.reportWriter = reportWriter;
    }

    public BatchResult execute(Path directory, Path output, String sheetName, FleetFilter flotte,
                               LocalDate from, LocalDate to, EtlProgressListener listener) throws EtlException {
        long start = System.currentTimeMillis();
        Objects.requireNonNull(directory, "Le dossier source est obligatoire");
        Objects.requireNonNull(output, "Le fichier de sortie est obligatoire");
        if (!Files.isDirectory(directory)) {
            throw new EtlException("Dossier introuvable : " + directory);
        }
        FleetFilter fleet = flotte == null ? FleetFilter.TOUTES : flotte;
        EtlProgressListener sink = progress -> {
            if (listener != null) {
                listener.onProgress(progress);
            }
        };
        List<Path> candidates = listExcelFiles(directory);
        if (candidates.isEmpty()) {
            throw new EtlException("Aucun fichier .xlsx à traiter dans le dossier : " + directory);
        }

        TrajetAggregator aggregator = new TrajetAggregator(fleet, from, to);
        List<ValidationError> reportedErrors = new ArrayList<>();
        long[] errorCount = {0};
        List<BatchFileResult> files = new ArrayList<>();
        long totalExtracted = 0;

        sink.onProgress(new EtlProgress(EtlProgress.Stage.EXTRACTION, 0, 0, 0.0,
                candidates.size() + " fichier(s) Excel détecté(s)"));

        int fileIndex = 1;
        for (Path file : candidates) {
            String fileName = file.getFileName().toString();
            String reason = skipReason(fileName, output);
            if (reason != null) {
                files.add(new BatchFileResult(fileName, BatchFileResult.Status.SKIPPED, reason, 0, 0));
                continue;
            }
            long mergedBefore = aggregator.getMergedDuplicates();
            try {
                long extracted = processFile(file, sheetName, fileName, fileIndex, candidates.size(), sink,
                        aggregator, reportedErrors, errorCount);
                totalExtracted += extracted;
                files.add(new BatchFileResult(fileName, BatchFileResult.Status.MERGED,
                        extracted + " ligne(s) intégrée(s)", extracted, aggregator.getMergedDuplicates() - mergedBefore));
            } catch (EtlException | RuntimeException e) {
                files.add(new BatchFileResult(fileName, BatchFileResult.Status.FAILED,
                        e.getMessage() == null ? e.toString() : e.getMessage(), 0, 0));
            }
            fileIndex++;
        }

        AggregationResult aggregation = aggregator.result();
        List<Journee> journees = aggregation.getJournees();
        if (journees.isEmpty()) {
            throw new EtlException("Aucune donnée exploitable dans le dossier : " + directory);
        }
        LocalDate effectiveFrom = from != null ? from : journees.get(0).getDate();
        LocalDate effectiveTo = to != null ? to : journees.get(journees.size() - 1).getDate();

        ensureOutputDirectory(output);
        sink.onProgress(new EtlProgress(EtlProgress.Stage.LOADING, (int) totalExtracted, 0, 0.92,
                "Écriture du classeur heures de travail (" + journees.size() + " journées)"));
        loader.write(output, journees);

        Path reportPath = buildReportPath(output);
        BatchResult result = new BatchResult(files, totalExtracted, aggregator.getFilteredOut(),
                aggregator.getMergedDuplicates(), errorCount[0], journees.size(),
                directory.toString(), output.toString(), reportPath.toString(),
                System.currentTimeMillis() - start, reportedErrors);

        sink.onProgress(new EtlProgress(EtlProgress.Stage.REPORTING, (int) totalExtracted, 0, 0.96,
                "Écriture du rapport texte"));
        reportWriter.write(reportPath, BatchReportFormatter.format(directory, result, fleet, effectiveFrom, effectiveTo));
        sink.onProgress(new EtlProgress(EtlProgress.Stage.COMPLETED, (int) totalExtracted, 0, 1.0,
                "Traitement terminé : " + journees.size() + " journée(s) chargée(s)"));
        return result;
    }

    static String skipReason(String fileName, Path output) {
        if (fileName.startsWith("~$")) {
            return "Fichier temporaire Excel";
        }
        if (fileName.startsWith(".")) {
            return "Fichier caché";
        }
        if (output != null && fileName.equalsIgnoreCase(output.getFileName().toString())) {
            return "Fichier de sortie";
        }
        if (GENERATED_OUTPUT.matcher(fileName).find()) {
            return "Rapport généré précédemment";
        }
        return null;
    }

    static Path buildReportPath(Path output) {
        String name = output.getFileName().toString();
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        return output.resolveSibling(base + "_rapport.txt");
    }

    static double asymptotic(int rows) {
        return 1.0 - 1.0 / (1.0 + rows / 20000.0);
    }

    private long processFile(Path file, String sheetName, String fileName, int fileIndex, int fileTotal,
                             EtlProgressListener sink, TrajetAggregator aggregator,
                             List<ValidationError> reportedErrors, long[] errorCount) throws EtlException {
        long[] extracted = {0};
        if (extractor.requiresStreaming(file)) {
            extractor.stream(file, sheetName, new StreamListener() {
                @Override
                public void onHeader(List<TrajetField> presentFields, List<String> extraLabels) {
                }

                @Override
                public void onProgress(int dataRows) {
                    emitProgress(sink, fileName, fileIndex, fileTotal, dataRows);
                }
            }, row -> {
                extracted[0]++;
                processRow(row, fileName, fileIndex, fileTotal, sink,
                        aggregator, reportedErrors, errorCount, extracted[0]);
            });
        } else {
            ExtractionResult extraction = extractor.extract(file, sheetName);
            for (RawRow row : extraction.getRows()) {
                extracted[0]++;
                processRow(row, fileName, fileIndex, fileTotal, sink, aggregator, reportedErrors, errorCount,
                        extracted[0]);
            }
        }
        return extracted[0];
    }

    private void processRow(RawRow row, String fileName, int fileIndex, int fileTotal, EtlProgressListener sink,
                            TrajetAggregator aggregator, List<ValidationError> reportedErrors, long[] errorCount,
                            long rowInFile) {
        JourneeRecord record = transformer.transform(row);
        List<ValidationError> rowErrors = validator.validateRow(record);
        errorCount[0] += rowErrors.size();
        if (!rowErrors.isEmpty() && reportedErrors.size() < MAX_REPORTED_DETAILS) {
            reportedErrors.addAll(rowErrors.subList(0,
                    (int) Math.min(rowErrors.size(), MAX_REPORTED_DETAILS - reportedErrors.size())));
        }
        if (rowErrors.isEmpty()) {
            aggregator.add(record);
        }
        if (rowInFile == 1 || rowInFile % PROGRESS_EVERY_ROWS == 0) {
            emitProgress(sink, fileName, fileIndex, fileTotal, (int) rowInFile);
        }
    }

    private void emitProgress(EtlProgressListener sink, String fileName, int fileIndex, int fileTotal, int rows) {
        double overall = 0.90 * (((fileIndex - 1) + 0.95 * asymptotic(rows)) / fileTotal);
        sink.onProgress(new EtlProgress(EtlProgress.Stage.EXTRACTION, rows, 0, overall,
                fileName + " : " + rows + " ligne(s)"));
    }

    private static void ensureOutputDirectory(Path output) throws EtlException {
        if (output.getParent() == null) {
            return;
        }
        try {
            Files.createDirectories(output.getParent());
        } catch (IOException e) {
            throw new EtlException("Dossier de sortie indisponible : " + output.getParent(), e);
        }
    }

    private static List<Path> listExcelFiles(Path directory) throws EtlException {
        try (Stream<Path> stream = Files.list(directory)) {
            return stream
                    .filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".xlsx"))
                    .sorted(Comparator.comparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .toList();
        } catch (IOException e) {
            throw new EtlException("Lecture du dossier impossible : " + directory, e);
        }
    }
}
