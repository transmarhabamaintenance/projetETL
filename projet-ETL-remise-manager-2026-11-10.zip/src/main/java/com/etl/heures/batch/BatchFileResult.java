package com.etl.heures.batch;

/**
 * Bilan d'un fichier du dossier traité en lot.
 */
public record BatchFileResult(String fileName, Status status, String message, long extractedRows, long mergedDuplicates) {

    public enum Status {
        MERGED, SKIPPED, FAILED
    }

    public BatchFileResult {
        fileName = fileName == null ? "" : fileName;
        status = status == null ? Status.SKIPPED : status;
        message = message == null ? "" : message;
    }

    public String getFileName() {
        return fileName;
    }

    public Status getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public long getExtractedRows() {
        return extractedRows;
    }

    public long getMergedDuplicates() {
        return mergedDuplicates;
    }
}
