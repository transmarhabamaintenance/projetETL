package com.etl.heures;

import java.io.IOException;

/**
 * Exception métier du pipeline ETL.
 */
public class EtlException extends IOException {

    public EtlException(String message) {
        super(message);
    }

    public EtlException(String message, Throwable cause) {
        super(message, cause);
    }
}
