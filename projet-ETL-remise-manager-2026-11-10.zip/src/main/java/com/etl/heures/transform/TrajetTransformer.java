package com.etl.heures.transform;

import com.etl.heures.extract.CellReading;
import com.etl.heures.extract.RawRow;
import com.etl.heures.extract.TrajetField;
import com.etl.heures.model.ExtraColumn;
import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import com.etl.heures.model.ValidationError;

import java.text.Normalizer;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Transforme une ligne brute du Daily Trip Report en {@link Journee} :
 * nettoyage des textes, découpage « véhicule // chauffeur », lecture des
 * dates/heures/durées (serials Excel ou textes « hh:mm:ss ») et contrôle des
 * durées dérivées (conduite, attente, durée totale, ralenti).
 */
public class TrajetTransformer {

    private static final Set<String> UNKNOWN_VALUES = Set.of(
            "unknown", "inconnu", "inconnue", "non renseigne", "non renseigné",
            "n/a", "na", "nd", "null", "none", "sans");

    static final DateTimeFormatter[] DATE_PATTERNS = {
            DateTimeFormatter.ofPattern("d/M/yyyy", Locale.FRANCE),
            DateTimeFormatter.ofPattern("d-M-yyyy", Locale.FRANCE),
            DateTimeFormatter.ISO_LOCAL_DATE
    };

    static final DateTimeFormatter[] DATETIME_PATTERNS = {
            DateTimeFormatter.ofPattern("d/M/yyyy H:mm:ss", Locale.FRANCE),
            DateTimeFormatter.ofPattern("d/M/yyyy H:mm", Locale.FRANCE),
            DateTimeFormatter.ofPattern("d-M-yyyy H:mm:ss", Locale.FRANCE),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ISO_LOCAL_DATE_TIME
    };

    private static final Pattern DURATION_PATTERN =
            Pattern.compile("^(-?)(\\d{1,5}):(\\d{1,2})(?::(\\d{1,2}))?$");
    private static final Pattern SERIAL_PATTERN = Pattern.compile("\\d{1,6}([.,]\\d+)?");
    private static final Pattern NUMBER_PATTERN = Pattern.compile("^-?\\d+([.,]\\d+)?$");

    public JourneeRecord transform(RawRow raw) {
        List<ValidationError> errors = new ArrayList<>();
        int rowIndex = raw.rowIndex();
        Journee journee = new Journee();

        journee.setFlotte(clean(raw.flotte()));

        String[] identite = raw.get(TrajetField.VEHICULE).text().split("/+");
        journee.setVehicule(clean(identite[0]));
        journee.setChauffeur(identite.length == 1
                ? ""
                : titleCase(clean(String.join(" ", Arrays.copyOfRange(identite, 1, identite.length)))));

        journee.setDate(readDate(rowIndex, raw, errors));
        journee.setHeureDebut(readTime(rowIndex, raw, TrajetField.HEURE_DEBUT, errors));
        journee.setHeureFin(readTime(rowIndex, raw, TrajetField.HEURE_FIN, errors));

        Duration conduite = readDuration(rowIndex, raw, TrajetField.TEMPS_CONDUITE, errors);
        Duration attente = readDuration(rowIndex, raw, TrajetField.TEMPS_ATTENTE, errors);
        Duration duree = readDuration(rowIndex, raw, TrajetField.DUREE, errors);
        Duration ralenti = readDuration(rowIndex, raw, TrajetField.DUREE_RALENTI, errors);
        if (conduite != null && conduite.isNegative()) {
            errors.add(new ValidationError(rowIndex, TrajetField.TEMPS_CONDUITE.label(),
                    raw.get(TrajetField.TEMPS_CONDUITE).text(), "Durée de conduite négative"));
            conduite = Duration.ZERO;
        }
        if (attente != null && attente.isNegative()) {
            errors.add(new ValidationError(rowIndex, TrajetField.TEMPS_ATTENTE.label(),
                    raw.get(TrajetField.TEMPS_ATTENTE).text(), "Temps d'attente négatif"));
            attente = Duration.ZERO;
        }
        if (duree != null && duree.isNegative()) {
            errors.add(new ValidationError(rowIndex, TrajetField.DUREE.label(),
                    raw.get(TrajetField.DUREE).text(), "Durée négative"));
            duree = Duration.ZERO;
        }
        if (ralenti != null && ralenti.isNegative()) {
            errors.add(new ValidationError(rowIndex, TrajetField.DUREE_RALENTI.label(),
                    raw.get(TrajetField.DUREE_RALENTI).text(), "Durée de ralenti négative"));
            ralenti = Duration.ZERO;
        }
        if (conduite == null) {
            conduite = Duration.ZERO;
        }
        if (attente == null) {
            attente = Duration.ZERO;
        }
        if (duree == null) {
            duree = conduite.plus(attente);
        }
        if (ralenti == null) {
            ralenti = Duration.ZERO;
        }

        journee.setTempsConduite(conduite);
        journee.setTempsAttente(attente);
        journee.setDuree(duree);
        journee.setDureeRalenti(ralenti);

        journee.setDistance(readNumber(rowIndex, raw, TrajetField.DISTANCE, errors));
        journee.setVitesseMoy(readNumber(rowIndex, raw, TrajetField.VITESSE_MOY, errors));
        journee.setVitesseMax(readNumber(rowIndex, raw, TrajetField.VITESSE_MAX, errors));

        List<ExtraColumn> extras = new ArrayList<>(raw.extras());
        return new JourneeRecord(rowIndex, journee, errors, extras);
    }

    private LocalDate readDate(int rowIndex, RawRow raw, List<ValidationError> errors) {
        CellReading reading = raw.get(TrajetField.DATE);
        if (reading.isBlank()) {
            return null;
        }
        LocalDate date = parseDate(reading);
        if (date == null) {
            errors.add(new ValidationError(rowIndex, TrajetField.DATE.label(), reading.text(),
                    "Date illisible : " + reading.text()));
        }
        return date;
    }

    private LocalTime readTime(int rowIndex, RawRow raw, TrajetField field, List<ValidationError> errors) {
        CellReading reading = raw.get(field);
        if (reading.isBlank()) {
            return null;
        }
        LocalTime time = parseTime(reading);
        if (time == null) {
            errors.add(new ValidationError(rowIndex, field.label(), reading.text(),
                    "Heure illisible : " + reading.text()));
        }
        return time;
    }

    private Duration readDuration(int rowIndex, RawRow raw, TrajetField field, List<ValidationError> errors) {
        CellReading reading = raw.get(field);
        if (reading.isBlank()) {
            return null;
        }
        Duration duration = parseDuration(reading);
        if (duration == null) {
            errors.add(new ValidationError(rowIndex, field.label(), reading.text(),
                    "Durée illisible : " + reading.text()));
            return Duration.ZERO;
        }
        return duration;
    }

    private Double readNumber(int rowIndex, RawRow raw, TrajetField field, List<ValidationError> errors) {
        CellReading reading = raw.get(field);
        if (reading.isBlank()) {
            return null;
        }
        Double value = parseNumber(reading);
        if (value == null) {
            errors.add(new ValidationError(rowIndex, field.label(), reading.text(),
                    "Nombre illisible : " + reading.text()));
        }
        return value;
    }

    /**
     * Nettoie un texte : normalisation Unicode, espaces de mise en forme,
     * valeurs « inconnues » transformées en chaîne vide.
     */
    public static String clean(String value) {
        if (value == null) {
            return "";
        }
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFC)
                .replace(' ', ' ')
                .replaceAll("[\\p{Cc}\\p{Cf}]", " ")
                .replaceAll("\\s+", " ")
                .strip();
        String lowered = stripAccents(normalized).toLowerCase(Locale.ROOT);
        return UNKNOWN_VALUES.contains(lowered) ? "" : normalized;
    }

    /**
     * Capitalise chaque mot ; un mot entièrement en majuscules est conservé tel quel
     * (« ichraf boughi » → « Ichraf Boughi », « ARKHA » → « ARKHA »).
     */
    public static String titleCase(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }
        List<String> words = new ArrayList<>();
        for (String word : value.strip().split("\\s+")) {
            if (!word.isEmpty()) {
                words.add(finishWord(word));
            }
        }
        return String.join(" ", words);
    }

    private static String finishWord(String word) {
        if (word.isEmpty()) {
            return "";
        }
        long letters = word.chars().filter(Character::isLetter).count();
        long uppers = word.chars().filter(Character::isUpperCase).count();
        if (letters > 1 && uppers == letters) {
            return word;
        }
        int first = word.codePointAt(0);
        String rest = word.substring(Character.charCount(first));
        StringBuilder out = new StringBuilder(word.length());
        out.appendCodePoint(Character.toUpperCase(first));
        out.append(rest.toLowerCase(Locale.ROOT));
        return out.toString();
    }

    static String stripAccents(String value) {
        if (value == null) {
            return "";
        }
        return Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    /**
     * Convertit un serial Excel (1900) en date locale.
     */
    static LocalDate excelSerialToDate(double serial) {
        return LocalDate.of(1899, 12, 30).plusDays((long) Math.floor(serial));
    }

    static LocalDate parseDate(CellReading reading) {
        if (reading.numeric() != null) {
            return excelSerialToDate(reading.numeric());
        }
        String text = reading.text().strip();
        if (text.isEmpty()) {
            return null;
        }
        if (SERIAL_PATTERN.matcher(text).matches()) {
            return excelSerialToDate(Double.parseDouble(text.replace(',', '.')));
        }
        for (DateTimeFormatter pattern : DATE_PATTERNS) {
            try {
                return LocalDate.parse(text, pattern);
            } catch (DateTimeParseException ignored) {
                // on tente le motif suivant
            }
        }
        for (DateTimeFormatter pattern : DATETIME_PATTERNS) {
            try {
                return LocalDateTime.parse(text, pattern).toLocalDate();
            } catch (DateTimeParseException ignored) {
                // on tente le motif suivant
            }
        }
        return null;
    }

    static LocalTime parseTime(CellReading reading) {
        if (reading.numeric() != null) {
            long seconds = Math.round(reading.numeric() * 86400.0);
            return LocalTime.ofSecondOfDay(Math.floorMod(seconds, 86400L));
        }
        String text = reading.text().strip();
        if (text.isEmpty()) {
            return null;
        }
        if (SERIAL_PATTERN.matcher(text).matches()) {
            long seconds = Math.round(Double.parseDouble(text.replace(',', '.')) * 86400.0);
            return LocalTime.ofSecondOfDay(Math.floorMod(seconds, 86400L));
        }
        Matcher matcher = DURATION_PATTERN.matcher(text);
        if (matcher.matches()) {
            long seconds = Long.parseLong(matcher.group(2)) * 3600L
                    + Long.parseLong(matcher.group(3)) * 60L
                    + (matcher.group(4) == null ? 0 : Long.parseLong(matcher.group(4)));
            return LocalTime.ofSecondOfDay(Math.floorMod(seconds, 86400L));
        }
        for (DateTimeFormatter pattern : DATETIME_PATTERNS) {
            try {
                return LocalDateTime.parse(text, pattern).toLocalTime();
            } catch (DateTimeParseException ignored) {
                // on tente le motif suivant
            }
        }
        return null;
    }

    /**
     * Lit une durée : serial Excel (0,1948 = 04:40:30 ; 1,2708 = 30:30:00),
     * texte « hh:mm:ss » avec heures cumulées, ou datetime 1900
     * (la valeur excédant 24 h est stockée comme date en 1900 par Excel).
     */
    static Duration parseDuration(CellReading reading) {
        if (reading.numeric() != null) {
            return Duration.ofSeconds(Math.round(reading.numeric() * 86400.0));
        }
        String text = reading.text().strip();
        if (text.isEmpty()) {
            return null;
        }
        Matcher matcher = DURATION_PATTERN.matcher(text);
        if (matcher.matches()) {
            long sign = matcher.group(1).isEmpty() ? 1L : -1L;
            return Duration.ofSeconds(sign * (Long.parseLong(matcher.group(2)) * 3600L
                    + Long.parseLong(matcher.group(3)) * 60L
                    + (matcher.group(4) == null ? 0 : Long.parseLong(matcher.group(4)))));
        }
        if (SERIAL_PATTERN.matcher(text).matches()) {
            double hours = Double.parseDouble(text.replace(',', '.'));
            if (hours <= 24) {
                return Duration.ofSeconds(Math.round(hours * 3600.0));
            }
            return null;
        }
        for (DateTimeFormatter pattern : DATETIME_PATTERNS) {
            try {
                LocalDateTime dateTime = LocalDateTime.parse(text, pattern);
                if (dateTime.getYear() >= 1910) {
                    return null;
                }
                // datetime 1900 : le jour encode les heures excédentaires (j-1) × 24 h
                return Duration.ofSeconds((dateTime.getDayOfMonth() - 1) * 86400L
                        + dateTime.toLocalTime().toSecondOfDay());
            } catch (DateTimeParseException ignored) {
                // on tente le motif suivant
            }
        }
        return null;
    }

    static Double parseNumber(CellReading reading) {
        if (reading.numeric() != null) {
            return reading.numeric();
        }
        String text = reading.text().strip();
        if (text.isEmpty()) {
            return null;
        }
        text = text.replace("km/h", "").replace("km", "").replace("Km", "").strip();
        if (NUMBER_PATTERN.matcher(text).matches()) {
            return Double.parseDouble(text.replace(',', '.'));
        }
        return null;
    }

    public static Double round5(double value) {
        return Math.round(value * 100000.0) / 100000.0;
    }
}
