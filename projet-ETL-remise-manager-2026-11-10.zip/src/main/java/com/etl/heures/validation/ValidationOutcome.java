package com.etl.heures.validation;

import com.etl.heures.model.JourneeRecord;
import com.etl.heures.model.ValidationError;

import java.util.List;

/**
 * Résultat d'une validation : les lignes utilisables et l'ensemble des erreurs
 * (erreurs de lecture cumulées lors de la transformation + erreurs sémantiques).
 */
public record ValidationOutcome(List<JourneeRecord> valid, List<ValidationError> errors) {

    public ValidationOutcome {
        valid = List.copyOf(valid);
        errors = List.copyOf(errors);
    }

    public List<JourneeRecord> getValid() {
        return valid;
    }

    public List<ValidationError> getErrors() {
        return errors;
    }
}
