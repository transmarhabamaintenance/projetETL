package com.etl.heures.validation;

import com.etl.heures.extract.TrajetField;
import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import com.etl.heures.model.ValidationError;

import java.util.ArrayList;
import java.util.List;

/**
 * Contrôle sémantique des lignes transformées : une ligne n'est conservée que si
 * la date et le véhicule sont présents. Les erreurs de lecture relevées lors de
 * la transformation sont également remontées dans le bilan.
 */
public class TrajetValidator {

    public ValidationOutcome validate(List<JourneeRecord> records) {
        List<JourneeRecord> valid = new ArrayList<>();
        List<ValidationError> errors = new ArrayList<>();
        for (JourneeRecord record : records) {
            List<ValidationError> rowErrors = validateRow(record);
            if (rowErrors.isEmpty()) {
                valid.add(record);
            } else {
                errors.addAll(rowErrors);
            }
        }
        return new ValidationOutcome(valid, errors);
    }

    /**
     * Retourne toutes les erreurs de la ligne (lecture + sémantique) ;
     * la ligne est valide si la liste est vide.
     */
    public List<ValidationError> validateRow(JourneeRecord record) {
        List<ValidationError> errors = new ArrayList<>(record.errors());
        Journee journee = record.journee();
        if (journee.getDate() == null && !hasErrorFor(errors, TrajetField.DATE.label())) {
            errors.add(new ValidationError(record.rowIndex(), TrajetField.DATE.label(), "",
                    "Date absente ou illisible : la ligne est ignorée"));
        }
        if (journee.getVehicule().isBlank() && !hasErrorFor(errors, TrajetField.VEHICULE.label())) {
            errors.add(new ValidationError(record.rowIndex(), TrajetField.VEHICULE.label(), "",
                    "Véhicule absent ou inconnu : la ligne est ignorée"));
        }
        return errors;
    }

    private boolean hasErrorFor(List<ValidationError> errors, String column) {
        for (ValidationError error : errors) {
            if (error.getColumn().equals(column)) {
                return true;
            }
        }
        return false;
    }
}
