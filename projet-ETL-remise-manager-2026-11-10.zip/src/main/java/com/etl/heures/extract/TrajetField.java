package com.etl.heures.extract;

/**
 * Champs métier reconnus dans la feuille « Daily Trip Report » du fichier
 * source. Les colonnes non listées sont ignorées ; la flotte n'a pas de
 * colonne, elle est détectée dans le bloc de titre du rapport.
 */
public enum TrajetField {
    DATE("Date"),
    VEHICULE("Description du vehicule"),
    HEURE_DEBUT("Première heure de début du trajet"),
    HEURE_FIN("Heure de fin du dernier trajet"),
    TEMPS_CONDUITE("Temps de conduite (hh:mm:ss)"),
    TEMPS_ATTENTE("Temps d'attente (hh:mm:ss)"),
    DUREE("durée (hh:mm:ss)"),
    DUREE_RALENTI("Durée de ralenti (hh:mm:ss)"),
    DISTANCE("Distance (km)"),
    VITESSE_MOY("Vitesse moy. (km/h)"),
    VITESSE_MAX("vitesse maximale (km/h)");

    private final String label;

    TrajetField(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
