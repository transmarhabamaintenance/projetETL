package com.etl.heures.extract;

import java.util.List;

/**
 * Résultat d'une extraction complète en mémoire.
 */
public record ExtractionResult(List<RawRow> rows, List<TrajetField> presentFields, List<String> extraLabels, String sheetName) {

    public ExtractionResult {
        rows = rows == null ? List.of() : List.copyOf(rows);
        presentFields = presentFields == null ? List.of() : List.copyOf(presentFields);
        extraLabels = extraLabels == null ? List.of() : List.copyOf(extraLabels);
        sheetName = sheetName == null ? "" : sheetName;
    }

    public List<RawRow> getRows() {
        return rows;
    }

    public List<TrajetField> getPresentFields() {
        return presentFields;
    }

    public List<String> getExtraLabels() {
        return extraLabels;
    }

    public String getSheetName() {
        return sheetName;
    }
}
