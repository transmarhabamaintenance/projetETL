package com.etl.heures.extract;

import com.etl.heures.EtlException;
import com.etl.heures.model.ExtraColumn;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.util.XMLHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.SharedStrings;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

/**
 * Lecture du fichier « Daily Trip Report » (.xlsx).
 * <p>
 * La ligne d'en-têtes est localisée en rapprochant les libellés d'un
 * dictionnaire d'alias (insensible à la casse, aux accents et aux
 * séparateurs). Les lignes « Totaux » / « Moyennes » ferment la zone de
 * données. La flotte n'ayant pas de colonne, elle est détectée dans le
 * titre de la feuille (VIVO / TOTAL). Au-delà du seuil, la feuille est lue
 * en flux (API SAX) pour ne pas charger le classeur en mémoire.
 */
public class ExcelExtractor {

    public static final int MAX_HEADER_SCAN_ROWS = 25;
    public static final int MINIMUM_RECOGNIZED_HEADERS = 4;
    public static final long STREAMING_THRESHOLD_BYTES = 20L * 1024 * 1024;

    private static final Map<String, TrajetField> HEADER_ALIASES = new LinkedHashMap<>();

    static {
        HEADER_ALIASES.put("date", TrajetField.DATE);
        HEADER_ALIASES.put("description du vehicule", TrajetField.VEHICULE);
        HEADER_ALIASES.put("description du bien", TrajetField.VEHICULE);
        HEADER_ALIASES.put("premiere heure de debut du trajet", TrajetField.HEURE_DEBUT);
        HEADER_ALIASES.put("heure de debut", TrajetField.HEURE_DEBUT);
        HEADER_ALIASES.put("heure de fin du dernier trajet", TrajetField.HEURE_FIN);
        HEADER_ALIASES.put("heure de fin", TrajetField.HEURE_FIN);
        HEADER_ALIASES.put("temps de conduite hh mm ss", TrajetField.TEMPS_CONDUITE);
        HEADER_ALIASES.put("duree de conduite hh mm ss", TrajetField.TEMPS_CONDUITE);
        HEADER_ALIASES.put("temps de conduite", TrajetField.TEMPS_CONDUITE);
        HEADER_ALIASES.put("duree de conduite", TrajetField.TEMPS_CONDUITE);
        HEADER_ALIASES.put("driving time (hh:mm:ss)", TrajetField.TEMPS_CONDUITE);
        HEADER_ALIASES.put("driving time", TrajetField.TEMPS_CONDUITE);
        HEADER_ALIASES.put("standing time (hh:mm:ss)", TrajetField.TEMPS_ATTENTE);
        HEADER_ALIASES.put("standing time", TrajetField.TEMPS_ATTENTE);
        HEADER_ALIASES.put("temps d attente hh mm ss", TrajetField.TEMPS_ATTENTE);
        HEADER_ALIASES.put("temps d attente", TrajetField.TEMPS_ATTENTE);
        HEADER_ALIASES.put("waiting time", TrajetField.TEMPS_ATTENTE);
        HEADER_ALIASES.put("duree hh mm ss", TrajetField.DUREE);
        HEADER_ALIASES.put("duree", TrajetField.DUREE);
        HEADER_ALIASES.put("duration (hh:mm:ss)", TrajetField.DUREE);
        HEADER_ALIASES.put("duration", TrajetField.DUREE);
        HEADER_ALIASES.put("duree de ralenti hh mm ss", TrajetField.DUREE_RALENTI);
        HEADER_ALIASES.put("duree de ralenti", TrajetField.DUREE_RALENTI);
        HEADER_ALIASES.put("duree ralentie", TrajetField.DUREE_RALENTI);
        HEADER_ALIASES.put("idle time (hh:mm:ss)", TrajetField.DUREE_RALENTI);
        HEADER_ALIASES.put("idle time", TrajetField.DUREE_RALENTI);
        HEADER_ALIASES.put("distance (km)", TrajetField.DISTANCE);
        HEADER_ALIASES.put("distance km", TrajetField.DISTANCE);
        HEADER_ALIASES.put("distance", TrajetField.DISTANCE);
        HEADER_ALIASES.put("avg. speed (km/h)", TrajetField.VITESSE_MOY);
        HEADER_ALIASES.put("average speed (km/h)", TrajetField.VITESSE_MOY);
        HEADER_ALIASES.put("avg speed (km/h)", TrajetField.VITESSE_MOY);
        HEADER_ALIASES.put("vitesse moy km h", TrajetField.VITESSE_MOY);
        HEADER_ALIASES.put("vitesse moyenne km h", TrajetField.VITESSE_MOY);
        HEADER_ALIASES.put("vitesse moy", TrajetField.VITESSE_MOY);
        HEADER_ALIASES.put("max speed (km/h)", TrajetField.VITESSE_MAX);
        HEADER_ALIASES.put("max. speed (km/h)", TrajetField.VITESSE_MAX);
        HEADER_ALIASES.put("vitesse maximale km h", TrajetField.VITESSE_MAX);
        HEADER_ALIASES.put("vitesse max km h", TrajetField.VITESSE_MAX);
        HEADER_ALIASES.put("asset description", TrajetField.VEHICULE);
        HEADER_ALIASES.put("description du vehicule", TrajetField.VEHICULE);
        HEADER_ALIASES.put("description du bien", TrajetField.VEHICULE);
        HEADER_ALIASES.put("first trip start time", TrajetField.HEURE_DEBUT);
        HEADER_ALIASES.put("trip start time", TrajetField.HEURE_DEBUT);
        HEADER_ALIASES.put("premiere heure de debut du trajet", TrajetField.HEURE_DEBUT);
        HEADER_ALIASES.put("heure de debut du trajet", TrajetField.HEURE_DEBUT);
        HEADER_ALIASES.put("first trip end time", TrajetField.HEURE_FIN);
        HEADER_ALIASES.put("last trip end time", TrajetField.HEURE_FIN);
        HEADER_ALIASES.put("trip end time", TrajetField.HEURE_FIN);
        HEADER_ALIASES.put("heure de fin du dernier trajet", TrajetField.HEURE_FIN);
        HEADER_ALIASES.put("heure de fin", TrajetField.HEURE_FIN);
    }

    public boolean requiresStreaming(Path source) throws EtlException {
        try {
            return Files.size(source) > STREAMING_THRESHOLD_BYTES;
        } catch (IOException e) {
            throw new EtlException("Taille du fichier illisible : " + source, e);
        }
    }

    public ExtractionResult extract(Path source, String sheetName) throws EtlException {
        validateSource(source);
        if (requiresStreaming(source)) {
            List<RawRow> rows = new ArrayList<>();
            List<TrajetField> presentFields = new ArrayList<>();
            List<String> extraLabels = new ArrayList<>();
            stream(source, sheetName, new StreamListener() {
                @Override
                public void onHeader(List<TrajetField> fields, List<String> labels) {
                    presentFields.addAll(fields);
                    extraLabels.addAll(labels);
                }
            }, rows::add);
            return new ExtractionResult(rows, presentFields, extraLabels, "");
        }
        return extractInMemory(source, sheetName);
    }

    private ExtractionResult extractInMemory(Path source, String sheetName) throws EtlException {
        try (Workbook workbook = WorkbookFactory.create(source.toFile(), null, true)) {
            Sheet sheet = resolveSheet(workbook, sheetName);
            DataFormatter formatter = new DataFormatter();
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            String flotte = detectFleet(sheet);

            int headerRowIndex = -1;
            HeaderMapping mapping = null;
            int lastRow = sheet.getLastRowNum();
            for (int r = 0; r < Math.min(MAX_HEADER_SCAN_ROWS, lastRow + 1); r++) {
                Row row = sheet.getRow(r);
                if (row == null) {
                    continue;
                }
                HeaderMapping candidate = readHeaderRow(row);
                if (candidate != null) {
                    headerRowIndex = r;
                    mapping = candidate;
                    break;
                }
            }
            if (mapping == null) {
                throw new EtlException("En-têtes introuvables dans les " + MAX_HEADER_SCAN_ROWS
                        + " premières lignes de la feuille « " + sheet.getSheetName()
                        + " ». Colonnes attendues : Date, Description du vehicule, "
                        + "Première heure de début du trajet, Heure de fin du dernier trajet…");
            }

            List<RawRow> rows = new ArrayList<>();
            for (int r = headerRowIndex + 1; r <= lastRow; r++) {
                Row row = sheet.getRow(r);
                if (row == null) {
                    continue;
                }
                if (isSummaryRow(row)) {
                    break;
                }
                Map<TrajetField, CellReading> cells = new EnumMap<>(TrajetField.class);
                List<ExtraColumn> extras = new ArrayList<>();
                boolean hasContent = false;
                for (int c = 0; c < row.getLastCellNum(); c++) {
                    Cell cell = row.getCell(c);
                    CellReading reading = readCell(cell, formatter, evaluator);
                    if (reading.isBlank()) {
                        continue;
                    }
                    hasContent = true;
                    TrajetField field = mapping.fields().get(c);
                    if (field != null) {
                        cells.put(field, reading);
                    } else {
                        String label = mapping.labels().getOrDefault(c, "");
                        if (!label.isBlank()) {
                            extras.add(new ExtraColumn(label, reading.text()));
                        }
                    }
                }
                if (hasContent) {
                    rows.add(new RawRow(r + 1, cells, extras, flotte));
                }
            }
            return new ExtractionResult(rows, new ArrayList<>(mapping.fields().values()),
                    new ArrayList<>(new LinkedHashSet<>(mapping.labels().values())), sheet.getSheetName());
        } catch (EtlException e) {
            throw e;
        } catch (Exception e) {
            throw new EtlException("Lecture du fichier impossible : " + source.getFileName()
                    + " (" + e.getMessage() + ")", e);
        }
    }

    static boolean isSummaryRow(Row row) {
        for (int c = 0; c < Math.min(row.getLastCellNum(), 2); c++) {
            Cell cell = row.getCell(c);
            if (cell == null) {
                continue;
            }
            String text = switch (cell.getCellType()) {
                case STRING -> cell.getStringCellValue();
                case FORMULA -> {
                    try {
                        yield cell.getStringCellValue();
                    } catch (Exception e) {
                        yield "";
                    }
                }
                default -> "";
            };
            if (text != null) {
                String normalized = text.strip().toLowerCase(Locale.ROOT);
                if (normalized.startsWith("totaux") || normalized.startsWith("moyennes")) {
                    return true;
                }
            }
        }
        return false;
    }

    static String detectFleet(Sheet sheet) {
        for (int r = 0; r < Math.min(5, sheet.getLastRowNum() + 1); r++) {
            Row row = sheet.getRow(r);
            if (row == null) {
                continue;
            }
            for (int c = 0; c < Math.min(4, row.getLastCellNum()); c++) {
                Cell cell = row.getCell(c);
                if (cell == null || cell.getCellType() != org.apache.poi.ss.usermodel.CellType.STRING) {
                    continue;
                }
                String text = cell.getStringCellValue();
                if (text == null || text.isBlank()) {
                    continue;
                }
                String upper = text.toUpperCase(Locale.ROOT);
                if (upper.contains("VIVO")) {
                    return "vivo";
                }
                if (upper.contains("TOTAL")) {
                    return "TOTAL";
                }
                return "";
            }
        }
        return "";
    }

    public void stream(Path source, String sheetName, StreamListener listener, RawRowConsumer consumer) throws EtlException {
        validateSource(source);
        try (OPCPackage pkg = OPCPackage.open(source.toFile(), PackageAccess.READ)) {
            XSSFReader reader = new XSSFReader(pkg);
            SharedStrings sharedStrings = new ReadOnlySharedStringsTable(pkg);
            StylesTable styles = reader.getStylesTable();
            XSSFReader.SheetIterator sheets = (XSSFReader.SheetIterator) reader.getSheetsData();
            String target = sheetName == null || sheetName.isBlank() ? null : sheetName.strip();
            boolean found = false;
            while (sheets.hasNext()) {
                try (InputStream sheetStream = sheets.next()) {
                    String name = sheets.getSheetName();
                    if (target != null && !target.equals(name)) {
                        continue;
                    }
                    String flotte = detectFleetFromWorkbook(source, name);
                    parseSheet(sheetStream, styles, sharedStrings, listener, consumer, flotte);
                    found = true;
                    break;
                }
            }
            if (!found) {
                throw new EtlException("Feuille introuvable : " + (target == null ? "(première feuille)" : target));
            }
        } catch (EtlException e) {
            throw e;
        } catch (HeaderFailure e) {
            throw (EtlException) e.getCause();
        } catch (Exception e) {
            throw new EtlException("Lecture du fichier impossible : " + source.getFileName()
                    + " (" + e.getMessage() + ")", e);
        }
    }

    private String detectFleetFromWorkbook(Path source, String sheetName) {
        try (Workbook workbook = WorkbookFactory.create(source.toFile(), null, true)) {
            Sheet sheet = workbook.getSheet(sheetName);
            return sheet == null ? "" : detectFleet(sheet);
        } catch (Exception e) {
            return "";
        }
    }

    private void parseSheet(InputStream sheetStream, StylesTable styles, SharedStrings sharedStrings,
                            StreamListener listener, RawRowConsumer consumer, String flotte) throws Exception {
        XMLReader parser = XMLHelper.newXMLReader();
        RawValueCapture formatter = new RawValueCapture();
        StreamingRowPump pump = new StreamingRowPump(listener, consumer, flotte);
        ContentHandler handler = new XSSFSheetXMLHandler(styles, sharedStrings, pump, formatter, false);
        parser.setContentHandler(handler);
        parser.parse(new InputSource(sheetStream));
    }

    public List<String> listSheetNames(Path source) throws EtlException {
        validateSource(source);
        List<String> names = new ArrayList<>();
        try (OPCPackage pkg = OPCPackage.open(source.toFile(), PackageAccess.READ)) {
            XSSFReader reader = new XSSFReader(pkg);
            XSSFReader.SheetIterator sheets = (XSSFReader.SheetIterator) reader.getSheetsData();
            while (sheets.hasNext()) {
                try (InputStream ignored = sheets.next()) {
                    names.add(sheets.getSheetName());
                }
            }
        } catch (Exception e) {
            throw new EtlException("Lecture du fichier impossible : " + source.getFileName()
                    + " (" + e.getMessage() + ")", e);
        }
        return names;
    }

    public void validateSource(Path source) throws EtlException {
        Objects.requireNonNull(source, "Le fichier source est obligatoire");
        String name = source.getFileName() == null ? "" : source.getFileName().toString();
        if (name.startsWith("~$") || name.startsWith(".")) {
            throw new EtlException("Fichier temporaire ou caché ignoré : " + name);
        }
        if (!name.toLowerCase(Locale.ROOT).endsWith(".xlsx")) {
            throw new EtlException("Le fichier source doit être au format .xlsx : " + name);
        }
        if (!Files.exists(source)) {
            throw new EtlException("Fichier source introuvable : " + source);
        }
        if (!Files.isRegularFile(source)) {
            throw new EtlException("Le chemin source n'est pas un fichier : " + source);
        }
        if (!Files.isReadable(source)) {
            throw new EtlException("Fichier source illisible (droits insuffisants) : " + source);
        }
        try {
            if (Files.size(source) == 0) {
                throw new EtlException("Fichier source vide : " + source);
            }
        } catch (IOException e) {
            throw new EtlException("Taille du fichier illisible : " + source, e);
        }
    }

    private Sheet resolveSheet(Workbook workbook, String sheetName) throws EtlException {
        if (sheetName == null || sheetName.isBlank()) {
            if (workbook.getNumberOfSheets() == 0) {
                throw new EtlException("Le classeur ne contient aucune feuille");
            }
            return workbook.getSheetAt(0);
        }
        Sheet sheet = workbook.getSheet(sheetName.strip());
        if (sheet == null) {
            List<String> names = new ArrayList<>();
            for (Sheet s : workbook) {
                names.add(s.getSheetName());
            }
            throw new EtlException("Feuille introuvable : " + sheetName + ". Feuilles disponibles : " + names);
        }
        return sheet;
    }

    private HeaderMapping readHeaderRow(Row row) {
        Map<Integer, TrajetField> fields = new LinkedHashMap<>();
        Map<Integer, String> labels = new LinkedHashMap<>();
        int recognized = 0;
        for (int c = 0; c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            String label = cell == null ? "" : displayText(cell, new DataFormatter(), null).strip();
            if (label.isEmpty()) {
                continue;
            }
            TrajetField field = HEADER_ALIASES.get(normalizeHeader(label));
            if (field != null && !fields.containsValue(field)) {
                fields.put(c, field);
                recognized++;
            } else {
                labels.put(c, label);
            }
        }
        return recognized >= MINIMUM_RECOGNIZED_HEADERS ? new HeaderMapping(fields, labels) : null;
    }

    private CellReading readCell(Cell cell, DataFormatter formatter, FormulaEvaluator evaluator) {
        if (cell == null) {
            return CellReading.EMPTY;
        }
        return switch (cell.getCellType()) {
            case NUMERIC -> new CellReading(displayText(cell, formatter, null), cell.getNumericCellValue());
            case FORMULA -> readFormulaCell(cell, formatter, evaluator);
            case STRING -> new CellReading(cell.getStringCellValue(), null);
            case BOOLEAN -> new CellReading(String.valueOf(cell.getBooleanCellValue()), null);
            case BLANK, _NONE -> CellReading.EMPTY;
            case ERROR -> new CellReading(displayText(cell, formatter, null), null);
        };
    }

    private CellReading readFormulaCell(Cell cell, DataFormatter formatter, FormulaEvaluator evaluator) {
        try {
            org.apache.poi.ss.usermodel.CellValue value = evaluator.evaluate(cell);
            if (value != null && value.getCellType() == org.apache.poi.ss.usermodel.CellType.NUMERIC) {
                return new CellReading(displayText(cell, formatter, evaluator), value.getNumberValue());
            }
        } catch (RuntimeException ignored) {
            // formule non évaluable : on retombe sur le texte affiché
        }
        return new CellReading(displayText(cell, formatter, evaluator), null);
    }

    /**
     * Texte affiché par Excel pour une cellule, sans jamais échouer : certains
     * classeurs français portent des préfixes de locale (« [$-040c]hh:mm:ss »)
     * que le formateur de POI refuse, on retombe alors sur la valeur brute.
     */
    private static String displayText(Cell cell, DataFormatter formatter, FormulaEvaluator evaluator) {
        try {
            return evaluator == null
                    ? formatter.formatCellValue(cell)
                    : formatter.formatCellValue(cell, evaluator);
        } catch (RuntimeException e) {
            return switch (cell.getCellType()) {
                case NUMERIC -> String.valueOf(cell.getNumericCellValue());
                case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
                case FORMULA -> cell.getCellFormula();
                case STRING -> cell.getStringCellValue();
                default -> "";
            };
        }
    }

    static String normalizeHeader(String label) {
        if (label == null) {
            return "";
        }
        String decomposed = Normalizer.normalize(label, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return decomposed.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").strip();
    }

    private record HeaderMapping(Map<Integer, TrajetField> fields, Map<Integer, String> labels) {
    }

    private record BufferedRow(int rowNumber, Map<Integer, CellReading> cells) {
    }

    /**
     * DataFormatter qui mémorise la valeur numérique brute de la dernière
     * cellule mise en forme, afin de relire les serials Excel (dates, durées).
     */
    private static final class RawValueCapture extends DataFormatter {

        private static final ThreadLocal<Double> CURRENT = new ThreadLocal<>();

        static Double poll() {
            Double value = CURRENT.get();
            CURRENT.remove();
            return value;
        }

        @Override
        public String formatRawCellContents(double value, int formatIndex, String formatString) {
            CURRENT.set(value);
            return super.formatRawCellContents(value, formatIndex, formatString);
        }

        @Override
        public String formatRawCellContents(double value, int formatIndex, String formatString, boolean use1904) {
            CURRENT.set(value);
            return super.formatRawCellContents(value, formatIndex, formatString, use1904);
        }
    }

    /** Véhicule RuntimeException d'une EtlException levée dans le parseur SAX (interfaces sans clause throws). */
    private static final class HeaderFailure extends RuntimeException {
        private HeaderFailure(EtlException cause) {
            super(cause);
        }
    }

    private static final class StreamingRowPump implements XSSFSheetXMLHandler.SheetContentsHandler {

        private final StreamListener listener;
        private final RawRowConsumer consumer;
        private final String flotte;
        private final List<BufferedRow> buffered = new ArrayList<>();
        private Map<Integer, CellReading> current;
        private boolean headerResolved;
        private boolean terminated;
        private HeaderMapping mapping;
        private int dataRows;

        private StreamingRowPump(StreamListener listener, RawRowConsumer consumer, String flotte) {
            this.listener = listener;
            this.consumer = consumer;
            this.flotte = flotte;
        }

        @Override
        public void startRow(int rowNum) {
            current = terminated ? null : new TreeMap<>();
        }

        @Override
        public void cell(String cellReference, String formattedValue, XSSFComment comment) {
            if (current == null || cellReference == null) {
                return;
            }
            int column = new CellReference(cellReference).getCol();
            Double numeric = RawValueCapture.poll();
            String text = formattedValue == null ? "" : formattedValue.strip();
            if (text.isEmpty() && numeric == null) {
                return;
            }
            current.put(column, new CellReading(text, numeric));
        }

        @Override
        public void endRow(int rowNum) {
            Map<Integer, CellReading> row = current;
            current = null;
            if (terminated || row == null || row.isEmpty()) {
                return;
            }
            if (headerResolved) {
                if (isSummary(row)) {
                    terminated = true;
                    return;
                }
                emit(new BufferedRow(rowNum + 1, row));
                return;
            }
            buffered.add(new BufferedRow(rowNum + 1, row));
            if (!tryResolveHeader() && buffered.size() >= MAX_HEADER_SCAN_ROWS) {
                throw new HeaderFailure(new EtlException("En-têtes introuvables dans les " + MAX_HEADER_SCAN_ROWS
                        + " premières lignes. Colonnes attendues : Date, Description du vehicule, "
                        + "Première heure de début du trajet, Heure de fin du dernier trajet…"));
            }
        }

        @Override
        public void endSheet() {
            if (!headerResolved && !tryResolveHeader()) {
                throw new HeaderFailure(new EtlException("En-têtes introuvables : la feuille est vide ou ne contient pas les colonnes attendues"));
            }
        }

        private boolean isSummary(Map<Integer, CellReading> row) {
            for (int c = 0; c < 2; c++) {
                CellReading reading = row.get(c);
                if (reading == null || reading.text().isBlank()) {
                    continue;
                }
                String normalized = reading.text().strip().toLowerCase(Locale.ROOT);
                if (normalized.startsWith("totaux") || normalized.startsWith("moyennes")) {
                    return true;
                }
            }
            return false;
        }

        private boolean tryResolveHeader() {
            for (int i = 0; i < buffered.size(); i++) {
                BufferedRow candidate = buffered.get(i);
                Map<Integer, TrajetField> fields = new LinkedHashMap<>();
                Map<Integer, String> labels = new LinkedHashMap<>();
                int recognized = 0;
                for (Map.Entry<Integer, CellReading> entry : candidate.cells().entrySet()) {
                    String label = entry.getValue().text();
                    TrajetField field = label.isBlank() ? null : HEADER_ALIASES.get(normalizeHeader(label));
                    if (field != null && !fields.containsValue(field)) {
                        fields.put(entry.getKey(), field);
                        recognized++;
                    } else if (!label.isBlank()) {
                        labels.put(entry.getKey(), label);
                    }
                }
                if (recognized < MINIMUM_RECOGNIZED_HEADERS) {
                    continue;
                }
                headerResolved = true;
                mapping = new HeaderMapping(fields, labels);
                listener.onHeader(new ArrayList<>(new LinkedHashSet<>(fields.values())),
                        new ArrayList<>(new LinkedHashSet<>(labels.values())));
                for (int j = i + 1; j < buffered.size(); j++) {
                    BufferedRow row = buffered.get(j);
                    if (row.rowNumber() > candidate.rowNumber()) {
                        emit(row);
                    }
                }
                buffered.clear();
                return true;
            }
            return false;
        }

        private void emit(BufferedRow row) {
            Map<TrajetField, CellReading> cells = new EnumMap<>(TrajetField.class);
            List<ExtraColumn> extras = new ArrayList<>();
            for (Map.Entry<Integer, CellReading> entry : row.cells().entrySet()) {
                TrajetField field = mapping.fields().get(entry.getKey());
                if (field != null) {
                    cells.put(field, entry.getValue());
                } else {
                    String label = mapping.labels().getOrDefault(entry.getKey(), "");
                    if (!label.isBlank()) {
                        extras.add(new ExtraColumn(label, entry.getValue().text()));
                    }
                }
            }
            dataRows++;
            try {
                consumer.accept(new RawRow(row.rowNumber(), cells, extras, flotte));
            } catch (EtlException e) {
                throw new HeaderFailure(e);
            }
            listener.onProgress(dataRows);
        }
    }
}
