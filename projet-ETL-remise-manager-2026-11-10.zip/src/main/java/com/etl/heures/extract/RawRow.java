package com.etl.heures.extract;

import com.etl.heures.model.ExtraColumn;

import java.util.List;
import java.util.Map;

/**
 * Une ligne de données lue dans la feuille source : les cellules reconnues,
 * indexées par champ métier, la flotte détectée dans le titre du rapport
 * (« vivo » / « TOTAL » / chaîne vide) et les colonnes supplémentaires.
 */
public record RawRow(int rowIndex, Map<TrajetField, CellReading> cells, List<ExtraColumn> extras, String flotte) {

    public RawRow {
        if (rowIndex < 1) {
            throw new IllegalArgumentException("Le numéro de ligne doit être supérieur ou égal à 1");
        }
        cells = cells == null ? Map.of() : Map.copyOf(cells);
        extras = extras == null ? List.of() : List.copyOf(extras);
        flotte = flotte == null ? "" : flotte;
    }

    public RawRow(int rowIndex, Map<TrajetField, CellReading> cells, List<ExtraColumn> extras) {
        this(rowIndex, cells, extras, "");
    }

    public CellReading get(TrajetField field) {
        CellReading reading = cells.get(field);
        return reading == null ? CellReading.EMPTY : reading;
    }
}
