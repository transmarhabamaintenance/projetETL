package com.etl.heures.extract;

import com.etl.heures.EtlException;

/**
 * Consomme une ligne de données au fil de la lecture du fichier.
 */
@FunctionalInterface
public interface RawRowConsumer {

    void accept(RawRow row) throws EtlException;
}
