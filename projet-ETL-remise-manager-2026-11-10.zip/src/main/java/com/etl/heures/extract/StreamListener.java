package com.etl.heures.extract;

import java.util.List;

/**
 * Écouteur des événements de la lecture en flux.
 */
public interface StreamListener {

    void onHeader(List<TrajetField> presentFields, List<String> extraLabels);

    default void onProgress(int dataRows) {
    }
}
