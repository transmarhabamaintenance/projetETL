package com.etl.heures.extract;

/**
 * Lecture brute d'une cellule : le texte affiché par Excel et,
 * lorsque la cellule est numérique, la valeur du serial Excel.
 * La valeur numérique permet de relire correctement les durées
 * supérieures à 24 h (stockées comme dates en 1900) et les dates.
 */
public record CellReading(String text, Double numeric) {

    public static final CellReading EMPTY = new CellReading("", null);

    public CellReading {
        text = text == null ? "" : text.strip();
    }

    public boolean isBlank() {
        return text.isEmpty() && numeric == null;
    }
}
