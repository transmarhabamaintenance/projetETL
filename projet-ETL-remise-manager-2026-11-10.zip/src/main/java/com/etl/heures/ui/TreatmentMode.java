package com.etl.heures.ui;

/**
 * Mode de traitement : un seul fichier Excel ou tout un dossier fusionné.
 */
public enum TreatmentMode {

    FICHIER_UNIQUE("Un seul fichier", "Traiter un fichier Excel unique (.xlsx)"),
    DOSSIER("Un dossier (plusieurs fichiers)", "Fusionner tous les fichiers .xlsx d'un dossier");

    private final String label;
    private final String description;

    TreatmentMode(String label, String description) {
        this.label = label;
        this.description = description;
    }

    public String getLabel() {
        return label;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return label;
    }
}
