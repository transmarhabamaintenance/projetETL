package com.etl.heures.ui;

import javafx.application.Application;

/**
 * Point d'entrée sans JavaFX module-directives : lance {@link Main}.
 */
public class Launcher {

    public static void main(String[] args) {
        Application.launch(Main.class, args);
    }
}
