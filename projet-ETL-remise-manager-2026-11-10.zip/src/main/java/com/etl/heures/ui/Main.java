package com.etl.heures.ui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.net.URL;

/**
 * Fenêtre principale de l'application « heures de travail ».
 */
public class Main extends Application {

    public static final String TITLE = "ETL Trajets";

    @Override
    public void start(Stage stage) {
        open(stage);
    }

    /**
     * Construit la scène principale, stylesheet comprise.
     */
    public static Scene createScene() {
        Rectangle2D screen = Screen.getPrimary().getVisualBounds();
        double width = Math.min(1100, screen.getWidth() * 0.92);
        double height = Math.min(760, screen.getHeight() * 0.90);
        Scene scene = new Scene(new MainView(), width, height);
        URL css = MainView.class.getResource("application.css");
        if (css != null) {
            scene.getStylesheets().add(css.toExternalForm());
        }
        return scene;
    }

    /**
     * Ouvre l'application « heures de travail » dans la fenêtre fournie.
     */
    public static Stage open(Stage stage) {
        stage.setTitle(TITLE);
        Rectangle2D screen = Screen.getPrimary().getVisualBounds();
        stage.setMinWidth(Math.min(760, screen.getWidth() * 0.92));
        stage.setMinHeight(Math.min(520, screen.getHeight() * 0.90));
        stage.setScene(createScene());
        stage.show();
        return stage;
    }
}
