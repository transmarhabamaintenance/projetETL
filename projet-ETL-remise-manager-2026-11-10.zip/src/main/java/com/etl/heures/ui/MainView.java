package com.etl.heures.ui;

import com.etl.heures.batch.BatchService;
import com.etl.heures.model.EtlProgress;
import com.etl.heures.model.FleetFilter;
import com.etl.heures.service.EtlProgressListener;
import com.etl.heures.service.EtlService;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.util.StringConverter;
import java.util.Optional;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Vue principale : choix du mode, des fichiers, des options, exécution en
 * tâche de fond et affichage du rapport texte.
 */
public class MainView extends BorderPane {

    private static final DateTimeFormatter DAY_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final EtlService fileService = new EtlService();
    private final BatchService batchService = new BatchService();

    private final ComboBox<TreatmentMode> modeSelector = new ComboBox<>();
    private final TextField inputField = new TextField();
    private final TextField outputField = new TextField();
    private final ComboBox<String> sheetSelector = new ComboBox<>();
    private final ComboBox<FleetFilter> fleetSelector = new ComboBox<>();
    private final DatePicker dateFrom = datePicker();
    private final DatePicker dateTo = datePicker();
    private final Button chooseInputButton = new Button("Parcourir...");
    private final Button chooseOutputButton = new Button("Parcourir...");
    private final Button chooseCustomOutputButton = new Button("Parcourir...");
    private final TextField customOutputField = new TextField();
    private final Button runButton = new Button("Lancer le traitement");
    private final Button openButton = new Button("Ouvrir le résultat");
    private final ProgressBar progressBar = new ProgressBar(0);
    private final Label progressLabel = new Label("Prêt");
    private final TextArea reportArea = new TextArea();

    private Path lastOutput;

    public MainView() {
        getStyleClass().add("app-root");
        setTop(buildHeader());
        setCenter(buildContent());
        inputField.setPromptText("Chemin du fichier .xlsx");
        outputField.setPromptText("Chemin du fichier de sortie .xlsx");
        customOutputField.setPromptText("Fichier de sortie personnalisé (facultatif)");
    }

    private VBox buildHeader() {
        Label title = new Label("ETL Trajets");
        title.getStyleClass().add("app-title");
        Label subtitle = new Label("Daily Trip Report → Fichiers « heures de travail »");
        subtitle.getStyleClass().add("app-subtitle");
        VBox header = new VBox(4, title, subtitle);
        header.getStyleClass().add("app-header");
        header.setPadding(new Insets(18, 24, 18, 24));
        return header;
    }

    private BorderPane buildContent() {
        BorderPane content = new BorderPane();
        VBox controls = new VBox(14);
        controls.setPadding(new Insets(14, 16, 12, 16));
        VBox filesCard = card("Mode et fichiers", buildFilesCard());
        VBox optionsCard = card("Options", buildOptionsCard());
        VBox runCard = card("Exécution", buildRunCard());
        VBox reportCard = card("Rapport de traitement", buildReportCard());
        controls.getChildren().addAll(filesCard, optionsCard, runCard);
        ScrollPane controlsScroll = new ScrollPane(controls);
        controlsScroll.setFitToWidth(true);
        controlsScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        controlsScroll.getStyleClass().add("content-scroll");
        reportCard.setMinHeight(150);
        content.setCenter(controlsScroll);
        content.setBottom(reportCard);
        BorderPane.setMargin(reportCard, new Insets(0, 16, 14, 16));
        return content;
    }

    private static VBox card(String title, Node body) {
        Label label = new Label(title);
        label.getStyleClass().add("card-title");
        VBox box = new VBox(10, label, body);
        box.getStyleClass().add("card");
        return box;
    }

    private Node buildFilesCard() {
        modeSelector.getItems().setAll(TreatmentMode.values());
        modeSelector.getSelectionModel().selectFirst();
        modeSelector.setMaxWidth(Double.MAX_VALUE);
        modeSelector.valueProperty().addListener((obs, oldValue, value) -> {
            if (value != null) {
                Tooltip.install(modeSelector, new Tooltip(value.getDescription()));
                inputField.setPromptText(value == TreatmentMode.FICHIER_UNIQUE
                        ? "Chemin du fichier .xlsx"
                        : "Chemin du dossier contenant les .xlsx");
            }
        });

        chooseInputButton.getStyleClass().add("secondary-button");
        chooseInputButton.setOnAction(event -> chooseInput());
        chooseOutputButton.getStyleClass().add("secondary-button");
        chooseOutputButton.setOnAction(event -> chooseOutput());
        chooseCustomOutputButton.getStyleClass().add("secondary-button");
        chooseCustomOutputButton.setOnAction(event -> chooseCustomOutput());

        HBox inputRow = new HBox(8, field("Entrée", inputField), chooseInputButton);
        HBox outputRow = new HBox(8, field("Sortie (par défaut)", outputField), chooseOutputButton);
        HBox customOutputRow = new HBox(8, field("Sortie personnalisée (facultatif)", customOutputField),
                chooseCustomOutputButton);
        HBox.setHgrow(inputField, Priority.ALWAYS);
        HBox.setHgrow(outputField, Priority.ALWAYS);
        HBox.setHgrow(customOutputField, Priority.ALWAYS);
        inputRow.setAlignment(Pos.BOTTOM_LEFT);
        outputRow.setAlignment(Pos.BOTTOM_LEFT);
        customOutputRow.setAlignment(Pos.BOTTOM_LEFT);
        return new VBox(10, field("Mode de traitement", modeSelector), inputRow, outputRow, customOutputRow);
    }

    private Node buildOptionsCard() {
        sheetSelector.setEditable(true);
        sheetSelector.setPromptText("Première feuille (par défaut)");
        fleetSelector.getItems().setAll(FleetFilter.values());
        fleetSelector.setValue(FleetFilter.TOUTES);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(10);
        grid.add(field("Feuille Excel", sheetSelector), 0, 0);
        grid.add(field("Flotte", fleetSelector), 1, 0);
        grid.add(field("Date de début", dateFrom), 0, 1);
        grid.add(field("Date de fin", dateTo), 1, 1);
        ColumnConstraints left = new ColumnConstraints();
        left.setPercentWidth(50);
        left.setHgrow(Priority.ALWAYS);
        ColumnConstraints right = new ColumnConstraints();
        right.setPercentWidth(50);
        right.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(left, right);
        return grid;
    }

    private Node buildRunCard() {
        runButton.getStyleClass().add("primary-button");
        runButton.setOnAction(event -> runTreatment());
        openButton.getStyleClass().add("secondary-button");
        openButton.setDisable(true);
        openButton.setOnAction(event -> openResult());

        progressBar.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(progressBar, Priority.ALWAYS);
        HBox row = new HBox(12, runButton, openButton, progressBar, progressLabel);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private Node buildReportCard() {
        reportArea.setEditable(false);
        reportArea.setWrapText(true);
        reportArea.getStyleClass().add("report-area");
        reportArea.setPrefHeight(180);
        reportArea.setMinHeight(100);
        return reportArea;
    }

    private static VBox field(String labelText, Node control) {
        Label label = new Label(labelText);
        label.getStyleClass().add("field-label");
        VBox box = new VBox(4, label, control);
        box.setFillWidth(true);
        return box;
    }

    private static DatePicker datePicker() {
        DatePicker picker = new DatePicker();
        picker.setPromptText("jj/mm/aaaa");
        picker.setConverter(new StringConverter<>() {
            @Override
            public String toString(LocalDate date) {
                return date == null ? "" : DAY_FORMAT.format(date);
            }

            @Override
            public LocalDate fromString(String text) {
                if (text == null || text.isBlank()) {
                    return null;
                }
                try {
                    return LocalDate.parse(text.strip(), DAY_FORMAT);
                } catch (Exception e) {
                    return null;
                }
            }
        });
        return picker;
    }

    private void chooseInput() {
        if (modeSelector.getValue() == TreatmentMode.DOSSIER) {
            DirectoryChooser chooser = new DirectoryChooser();
            chooser.setTitle("Dossier des fichiers Excel");
            File directory = chooser.showDialog(window());
            if (directory != null) {
                Path path = directory.toPath();
                inputField.setText(path.toString());
                suggestOutput(path);
            }
            return;
        }
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Fichier Excel d'entrée");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers Excel (*.xlsx)", "*.xlsx"));
        File file = chooser.showOpenDialog(window());
        if (file != null) {
            Path path = file.toPath();
            inputField.setText(path.toString());
            suggestOutput(path);
        }
    }

    private void chooseOutput() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Fichier Excel de sortie (par défaut)");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers Excel (*.xlsx)", "*.xlsx"));
        Path input = Paths.get(inputField.getText() == null ? "" : inputField.getText().strip());
        String suggested = suggestedOutputName(input);
        if (!suggested.isBlank()) {
            chooser.setInitialFileName(suggested);
            if (input.getParent() != null && Files.isDirectory(input.getParent())) {
                chooser.setInitialDirectory(input.getParent().toFile());
            }
        }
        File file = chooser.showSaveDialog(window());
        if (file != null) {
            outputField.setText(file.toPath().toString());
        }
    }

    private void chooseCustomOutput() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Fichier Excel de sortie personnalisé");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers Excel (*.xlsx)", "*.xlsx"));
        File file = chooser.showSaveDialog(window());
        if (file != null) {
            customOutputField.setText(file.toPath().toString());
        }
    }

    private void suggestOutput(Path input) {
        if (outputField.getText() != null && !outputField.getText().isBlank()) {
            return;
        }
        String suggested = suggestedOutputName(input);
        if (suggested.isBlank()) {
            return;
        }
        Path parent = input.getParent();
        outputField.setText(parent == null ? suggested : parent.resolve(suggested).toString());
    }

    private static String suggestedOutputName(Path input) {
        String name = input.getFileName() == null ? "" : input.getFileName().toString();
        if (name.isBlank()) {
            return "";
        }
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        return base + "_heures_de_travail.xlsx";
    }

    private void runTreatment() {
        TreatmentMode mode = modeSelector.getValue();
        String inputText = inputField.getText() == null ? "" : inputField.getText().strip();
        String outputText = outputField.getText() == null ? "" : outputField.getText().strip();
        String customOutputText = customOutputField.getText() == null ? "" : customOutputField.getText().strip();
        if (inputText.isEmpty() || outputText.isEmpty()) {
            alert(Alert.AlertType.WARNING, "Champs manquants",
                    "Renseignez l'entrée (fichier ou dossier) et le fichier de sortie.");
            return;
        }
        Path input = Paths.get(inputText);
        Path output = Paths.get(outputText);
        Path customOutput = customOutputText.isEmpty() ? null : Paths.get(customOutputText);
        if (mode == TreatmentMode.FICHIER_UNIQUE && !Files.isRegularFile(input)) {
            alert(Alert.AlertType.WARNING, "Fichier introuvable", "Le fichier d'entrée n'existe pas : " + input);
            return;
        }
        if (mode == TreatmentMode.DOSSIER && !Files.isDirectory(input)) {
            alert(Alert.AlertType.WARNING, "Dossier introuvable", "Le dossier d'entrée n'existe pas : " + input);
            return;
        }
        LocalDate from = dateFrom.getValue();
        LocalDate to = dateTo.getValue();
        if (from != null && to != null && from.isAfter(to)) {
            alert(Alert.AlertType.WARNING, "Période invalide",
                    "La date de début doit être antérieure ou égale à la date de fin.");
            return;
        }
        Path targetOutput = mode == TreatmentMode.FICHIER_UNIQUE && customOutput != null
                ? customOutput : output;
        boolean appendExistingOutput = false;
        if (Files.exists(targetOutput)) {
            if (mode == TreatmentMode.FICHIER_UNIQUE) {
                ButtonType appendChoice = new ButtonType("Ajouter à l’historique", ButtonBar.ButtonData.YES);
                ButtonType replaceChoice = new ButtonType("Remplacer", ButtonBar.ButtonData.NO);
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                        "Le fichier de sortie existe déjà :\n" + targetOutput
                                + "\n\nL’ajout conserve les résultats précédents et ajoute les nouvelles journées à la suite.",
                        appendChoice, replaceChoice, ButtonType.CANCEL);
                confirm.setTitle("Fichier de sortie existant");
                confirm.setHeaderText(null);
                Optional<ButtonType> choice = confirm.showAndWait();
                if (choice.isEmpty() || choice.get() == ButtonType.CANCEL) return;
                appendExistingOutput = choice.get() == appendChoice;
            } else if (!confirmReplacement(targetOutput)) {
                return;
            }
        }
        final boolean appendHistory = appendExistingOutput;

        String selectedSheet = sheetSelector.getValue();
        String sheet = selectedSheet == null || selectedSheet.isBlank() ? null : selectedSheet.strip();
        FleetFilter fleet = fleetSelector.getValue() == null ? FleetFilter.TOUTES : fleetSelector.getValue();

        setBusy(true);
        progressBar.setProgress(-1);
        progressLabel.setText("Traitement en cours...");
        reportArea.clear();
        openButton.setDisable(true);

        Task<Path> task = new Task<>() {
            @Override
            protected Path call() throws Exception {
                EtlProgressListener listener = progress -> Platform.runLater(() -> {
                    progressBar.setProgress(progress.getProgress());
                    progressLabel.setText(progress.getStage() + " — " + progress.getMessage());
                });
                Path target;
                if (mode == TreatmentMode.DOSSIER) {
                    batchService.execute(input, output, sheet, fleet, from, to, listener);
                    target = output;
                } else {
                    fileService.execute(input, output, sheet, fleet, from, to, listener, customOutput,
                            appendHistory);
                    target = customOutput != null ? customOutput : output;
                }
                return target;
            }
        };
        task.setOnSucceeded(event -> onSucceeded(task.getValue()));
        task.setOnFailed(event -> {
            Throwable error = task.getException();
            setBusy(false);
            progressBar.setProgress(0);
            progressLabel.setText("Échec du traitement");
            alert(Alert.AlertType.ERROR, "Échec du traitement",
                    error.getMessage() == null ? error.toString() : error.getMessage());
        });
        Thread worker = new Thread(task, "etl-background-worker");
        worker.setDaemon(true);
        worker.start();
    }

    private void onSucceeded(Path output) {
        setBusy(false);
        progressBar.setProgress(1);
        progressLabel.setText("Traitement terminé");
        lastOutput = output;
        openButton.setDisable(false);
        Path report = reportPathFor(output);
        if (Files.exists(report)) {
            try {
                reportArea.setText(Files.readString(report));
            } catch (IOException e) {
                reportArea.setText("Rapport écrit dans : " + report);
            }
        }
    }

    private void openResult() {
        if (lastOutput == null || !Files.exists(lastOutput)) {
            return;
        }
        try {
            Desktop.getDesktop().open(lastOutput.toFile());
        } catch (IOException e) {
            alert(Alert.AlertType.ERROR, "Ouverture impossible",
                    e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    private void setBusy(boolean busy) {
        runButton.setDisable(busy);
        modeSelector.setDisable(busy);
        inputField.setDisable(busy);
        outputField.setDisable(busy);
        sheetSelector.setDisable(busy);
        fleetSelector.setDisable(busy);
        dateFrom.setDisable(busy);
        dateTo.setDisable(busy);
        chooseInputButton.setDisable(busy);
        chooseOutputButton.setDisable(busy);
        chooseCustomOutputButton.setDisable(busy);
    }

    private boolean confirmReplacement(Path output) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "Le fichier suivant existe déjà :\n" + output + "\n\nLe remplacer ?",
                ButtonType.YES, ButtonType.NO);
        alert.setTitle("Remplacer le fichier");
        alert.setHeaderText(null);
        return alert.showAndWait().filter(ButtonType.YES::equals).isPresent();
    }

    private static void alert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type, message, ButtonType.OK);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private javafx.stage.Window window() {
        return getScene() == null ? null : getScene().getWindow();
    }

    private static Path reportPathFor(Path output) {
        String name = output.getFileName().toString();
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        return output.resolveSibling(base + "_rapport.txt");
    }
}
