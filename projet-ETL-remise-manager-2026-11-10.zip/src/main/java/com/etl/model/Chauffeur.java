package com.etl.model;

import java.util.Objects;

/**
 * Représente une ligne de données de suivi de flotte.
 */
public class Chauffeur {

    private String statutMobile;
    private String description;
    private String inscription;
    private String numeroFlotte;
    private String site;
    private String chauffeurNom;
    private String emplacement;
    private String dernierEvenement;
    private String valeurDernierEvenement;
    private String vitesse;

    public Chauffeur() {
        this.statutMobile = "";
        this.description = "";
        this.inscription = "";
        this.numeroFlotte = "";
        this.site = "";
        this.chauffeurNom = "";
        this.emplacement = "";
        this.dernierEvenement = "";
        this.valeurDernierEvenement = "";
        this.vitesse = "";
    }

    public Chauffeur(String statutMobile, String description, String inscription,
                     String numeroFlotte, String site, String chauffeurNom,
                     String emplacement, String dernierEvenement,
                     String valeurDernierEvenement, String vitesse) {
        this.statutMobile = statutMobile;
        this.description = description;
        this.inscription = inscription;
        this.numeroFlotte = numeroFlotte;
        this.site = site;
        this.chauffeurNom = chauffeurNom;
        this.emplacement = emplacement;
        this.dernierEvenement = dernierEvenement;
        this.valeurDernierEvenement = valeurDernierEvenement;
        this.vitesse = vitesse;
    }

    public String getStatutMobile() {
        return statutMobile;
    }

    public void setStatutMobile(String statutMobile) {
        this.statutMobile = statutMobile;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getInscription() {
        return inscription;
    }

    public void setInscription(String inscription) {
        this.inscription = inscription;
    }

    public String getNumeroFlotte() {
        return numeroFlotte;
    }

    public void setNumeroFlotte(String numeroFlotte) {
        this.numeroFlotte = numeroFlotte;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getChauffeurNom() {
        return chauffeurNom;
    }

    public void setChauffeurNom(String chauffeurNom) {
        this.chauffeurNom = chauffeurNom;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(String emplacement) {
        this.emplacement = emplacement;
    }

    public String getDernierEvenement() {
        return dernierEvenement;
    }

    public void setDernierEvenement(String dernierEvenement) {
        this.dernierEvenement = dernierEvenement;
    }

    public String getValeurDernierEvenement() {
        return valeurDernierEvenement;
    }

    public void setValeurDernierEvenement(String valeurDernierEvenement) {
        this.valeurDernierEvenement = valeurDernierEvenement;
    }

    public String getVitesse() {
        return vitesse;
    }

    public void setVitesse(String vitesse) {
        this.vitesse = vitesse;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Chauffeur chauffeur)) {
            return false;
        }
        return Objects.equals(numeroFlotte, chauffeur.numeroFlotte)
                && Objects.equals(chauffeurNom, chauffeur.chauffeurNom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroFlotte, chauffeurNom);
    }
}
