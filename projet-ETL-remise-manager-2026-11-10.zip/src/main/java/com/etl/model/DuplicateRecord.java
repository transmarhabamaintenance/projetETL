package com.etl.model;

/**
 * Conserve une occurrence dupliquée afin qu'elle soit explicitement listée dans le rapport.
 */
public record DuplicateRecord(int rowIndex, Chauffeur chauffeur) {

    public DuplicateRecord {
        if (rowIndex < 1) {
            throw new IllegalArgumentException("Le numéro de ligne doit être supérieur ou égal à 1");
        }
        if (chauffeur == null) {
            throw new IllegalArgumentException("Un enregistrement dupliqué ne peut pas être null");
        }
    }

    public int getRowIndex() {
        return rowIndex;
    }

    public Chauffeur getChauffeur() {
        return chauffeur;
    }
}
