package com.etl.model;

/**
 * Colonne de la feuille source qui ne correspond a aucun champ metier du modele.
 * Elle est recopiee telle quelle dans le classeur de sortie afin de ne rien perdre.
 */
public record ExtraColumn(String label, String value) {

    public ExtraColumn {
        label = label == null ? "" : label;
        value = value == null ? "" : value;
    }
}
