package com.etl.model;

import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Objects;

/**
 * Résultat immutable et statistiques d'une exécution ETL complète.
 */
public record EtlResult(
        int extractedRows,
        int transformedRows,
        int duplicates,
        int errors,
        int loadedRows,
        Path sourcePath,
        Path outputPath,
        Path reportPath,
        long durationMillis,
        List<ValidationError> validationErrors,
        List<DuplicateRecord> duplicateRecords
) {

    public EtlResult {
        if (extractedRows < 0 || transformedRows < 0 || duplicates < 0
                || errors < 0 || loadedRows < 0 || durationMillis < 0) {
            throw new IllegalArgumentException("Les statistiques ne peuvent pas être négatives");
        }
        sourcePath = Objects.requireNonNull(sourcePath, "Le chemin source est obligatoire").toAbsolutePath().normalize();
        outputPath = Objects.requireNonNull(outputPath, "Le chemin de sortie est obligatoire").toAbsolutePath().normalize();
        reportPath = Objects.requireNonNull(reportPath, "Le chemin du rapport est obligatoire").toAbsolutePath().normalize();
        validationErrors = List.copyOf(Objects.requireNonNullElse(validationErrors, List.of()));
        duplicateRecords = List.copyOf(Objects.requireNonNullElse(duplicateRecords, List.of()));
    }

    public Duration duration() {
        return Duration.ofMillis(durationMillis);
    }

    public int getExtractedRows() {
        return extractedRows;
    }

    public int getTransformedRows() {
        return transformedRows;
    }

    public int getDuplicates() {
        return duplicates;
    }

    public int getErrors() {
        return errors;
    }

    public int getLoadedRows() {
        return loadedRows;
    }

    public Path getSourcePath() {
        return sourcePath;
    }

    public Path getOutputPath() {
        return outputPath;
    }

    public Path getReportPath() {
        return reportPath;
    }

    public long getDurationMillis() {
        return durationMillis;
    }

    public List<ValidationError> getValidationErrors() {
        return validationErrors;
    }

    public List<DuplicateRecord> getDuplicateRecords() {
        return duplicateRecords;
    }
}
