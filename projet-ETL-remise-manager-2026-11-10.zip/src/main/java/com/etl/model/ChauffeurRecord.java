package com.etl.model;

import java.util.List;
import java.util.Objects;

/**
 * Associe un chauffeur à sa ligne source et aux éventuelles erreurs de lecture.
 */
public record ChauffeurRecord(int rowIndex, Chauffeur chauffeur, List<ValidationError> extractionErrors,
                              List<ExtraColumn> extraColumns) {

    public ChauffeurRecord {
        if (rowIndex < 1) {
            throw new IllegalArgumentException("Le numéro de ligne doit être supérieur ou égal à 1");
        }
        if (chauffeur == null) {
            throw new IllegalArgumentException("Un chauffeur ne peut pas être null");
        }
        extractionErrors = List.copyOf(Objects.requireNonNullElse(extractionErrors, List.of()));
        extraColumns = List.copyOf(Objects.requireNonNullElse(extraColumns, List.of()));
    }

    public ChauffeurRecord(int rowIndex, Chauffeur chauffeur, List<ValidationError> extractionErrors) {
        this(rowIndex, chauffeur, extractionErrors, List.of());
    }

    public ChauffeurRecord(int rowIndex, Chauffeur chauffeur) {
        this(rowIndex, chauffeur, List.of(), List.of());
    }

    public int getRowIndex() {
        return rowIndex;
    }

    public Chauffeur getChauffeur() {
        return chauffeur;
    }

    public List<ValidationError> getExtractionErrors() {
        return extractionErrors;
    }
}
