package com.etl.model;

/**
 * Décrit une erreur de validation associée à une cellule du fichier source.
 * Le numéro de ligne correspond à la ligne visible dans Excel, en démarrant à 1.
 */
public record ValidationError(int rowIndex, String column, String value, String description) {

    public ValidationError {
        if (rowIndex < 1) {
            throw new IllegalArgumentException("Le numéro de ligne doit être supérieur ou égal à 1");
        }
        column = column == null ? "" : column;
        value = value == null ? "" : value;
        description = description == null ? "" : description;
    }

    public int getRowIndex() {
        return rowIndex;
    }

    public String getColumn() {
        return column;
    }

    public String getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }
}
