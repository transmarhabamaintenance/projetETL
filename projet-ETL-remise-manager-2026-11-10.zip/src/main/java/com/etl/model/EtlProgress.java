package com.etl.model;

import java.util.Objects;

/**
 * Progression-safe transmise depuis le thread d'arrière-plan vers l'interface JavaFX.
 */
public record EtlProgress(Stage stage, int processedRows, int totalRows, double progress, String message) {

    public enum Stage {
        EXTRACTION,
        TRANSFORMATION,
        VALIDATION,
        LOADING,
        REPORTING,
        COMPLETED
    }

    public EtlProgress {
        stage = Objects.requireNonNull(stage, "L'étape de progression est obligatoire");
        if (processedRows < 0 || totalRows < 0 || processedRows > totalRows) {
            throw new IllegalArgumentException("Compteurs de progression incohérents");
        }
        progress = Math.max(0.0, Math.min(1.0, progress));
        message = message == null ? "" : message;
    }

    public Stage getStage() {
        return stage;
    }

    public int getProcessedRows() {
        return processedRows;
    }

    public int getTotalRows() {
        return totalRows;
    }

    public double getProgress() {
        return progress;
    }

    public String getMessage() {
        return message;
    }
}
