package com.etl.mail;

/**
 * Erreur de preparation du message destinee a etre affichee telle quelle a l'utilisateur. Le
 * traitement ETL deja abouti n'est jamais affecte : cette exception reste volontairement
 * distincte de {@link com.etl.EtlException} pour ne jamais ressembler a un echec du pipeline
 * extract/transform/load.
 */
public class MailException extends RuntimeException {

    public MailException(String message) {
        super(message);
    }

    public MailException(String message, Throwable cause) {
        super(message, cause);
    }
}