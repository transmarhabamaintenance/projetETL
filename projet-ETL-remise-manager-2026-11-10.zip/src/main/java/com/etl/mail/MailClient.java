package com.etl.mail;

import java.nio.file.Path;
import java.util.List;

/**
 * Transport d'envoi d'un message avec ses pieces jointes. Implementations :
 * {@link HttpMailClient} en production, stub de test pour simuler un fournisseur.
 */
public interface MailClient {

    /**
     * Envoie le message. Toute echec est signale par une {@link MailException},
     * jamais par une {@code EtlException} : un probleme d'email n'invalide jamais
     * un traitement ETL deja abouti.
     */
    void send(MailConfiguration configuration, MailMessage message, List<Path> attachments);
}
