package com.etl.mail;

import java.awt.Desktop;
import java.net.URI;

/**
 * Ouvre le message dans le client de messagerie lourd du poste via le protocole
 * {@code mailto:}. L'application n'envoie aucun e-mail : elle demande au système de lancer le
 * logiciel de messagerie par défaut (Outlook, Thunderbird, Courrier Windows...) avec les
 * champs to, subject et body pré-remplis. Gmail web n'est pas visé.
 */
public final class MailLauncher {

    private MailLauncher() {
    }

    /**
     * Construit le lien {@code mailto:} puis demande au systeme de l'ouvrir. L'appel rend la
     * main aussitot : le client de messagerie demarre, l'utilisateur n'a plus qu'a cliquer sur
     * « Envoyer » dans sa fenetre.
     *
     * @return le lien ouvert, afin que l'interface puisse l'afficher en cas de doute
     * @throws MailException si aucun client de messagerie n'est associe au poste
     */
    public static String open(MailMessage message) {
        URI uri = MailtoLink.toUri(message);
        String url = uri.toString();

        if (!Desktop.isDesktopSupported()) {
            throw new MailException(noClientMessage(url));
        }
        Desktop desktop = Desktop.getDesktop();
        if (!desktop.isSupported(Desktop.Action.MAIL)) {
            throw new MailException(noClientMessage(url));
        }
        try {
            desktop.mail(uri);
        } catch (Exception exception) {
            throw new MailException(
                    "Le client de messagerie lourd n'a pas pu être démarré.\n\n"
                            + "Copiez ce lien dans votre messagerie :\n" + url,
                    exception
            );
        }
        return url;
    }

    private static String noClientMessage(String url) {
        return "Aucun client de messagerie lourd n'est associé à cet ordinateur.\n"
                + "Associez un client de messagerie (Outlook, Thunderbird, Courrier Windows...) aux liens mailto:, "
                + "ou copiez ce lien :\n\n"
                + url;
    }
}
