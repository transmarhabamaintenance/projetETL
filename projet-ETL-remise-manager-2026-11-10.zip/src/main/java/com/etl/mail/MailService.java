package com.etl.mail;

import java.nio.file.Path;
import java.util.List;

/**
 * Point d'entree de l'envoi apres un traitement reussi : charge la configuration
 * au moment de l'appel, puis delegue au transport HTTP du fournisseur configure.
 * L'interface reste isolee du pipeline ETL : une {@link MailException} n'invalide
 * jamais un traitement deja abouti.
 */
public final class MailService {

    private final MailConfigurationLoader loader;
    private final MailClient client;

    public MailService() {
        this(new MailConfigurationLoader(), new HttpMailClient());
    }

    /**
     * Permet aux tests d'injecter un loader et un client factices.
     */
    MailService(MailConfigurationLoader loader, MailClient client) {
        this.loader = loader;
        this.client = client;
    }

    /**
     * Envoie le message avec le classeur de sortie et le rapport en pieces
     * jointes. Toute anomalie (configuration, reseau, fournisseur) est signalee
     * par une {@link MailException}.
     */
    public void send(MailMessage message, List<Path> attachments) {
        MailConfiguration configuration = loader.load();
        client.send(configuration, message, attachments);
    }

    /**
     * Fournisseur effectivement configure, pour afficher « Envoi via BREVO »
     * dans l'interface. Retourne null si la configuration est absente : l'erreur
     * complete sera produite par {@link #send}.
     */
    public MailProvider configuredProvider() {
        try {
            return loader.load().provider();
        } catch (MailException exception) {
            return null;
        }
    }
}
