package com.etl.mail;

import java.net.URI;
import java.nio.charset.StandardCharsets;

/**
 * Construit le lien {@code mailto:} ouvert par le client de messagerie du poste. Aucune
 * connexion sortante n'est effectuee : l'application se contente de produire une URL et de la
 * transmettre au systeme, qui ouvre Outlook, Thunderbird, Gmail ou le webmail par defaut.
 *
 * <p>L'objet et le corps sont encodes en UTF-8 sous forme de sequences {@code %XX}, l'espace
 * devenant {@code %20} plutot que {@code +}, afin que les clients interprets les plus divers
 * les lisent de facon identique.
 */
public final class MailtoLink {

    private static final String SCHEME = "mailto:";
    private static final char[] HEX = "0123456789ABCDEF".toCharArray();

    private MailtoLink() {
    }

    /**
     * Adresse complete du lien, prete a etre ouverte par le systeme.
     */
    public static String toUrl(MailMessage message) {
        StringBuilder url = new StringBuilder(SCHEME);
        url.append(encodeAddresses(message));
        boolean separator = false;
        if (!message.subject().isEmpty()) {
            url.append("?subject=").append(encodeComponent(message.subject()));
            separator = true;
        }
        String body = message.body();
        if (!body.isEmpty()) {
            url.append(separator ? "&body=" : "?body=").append(encodeComponent(body));
        }
        return url.toString();
    }

    /**
     * Meme contenu que {@link #toUrl(MailMessage)}, expose sous forme d'URI.
     */
    public static URI toUri(MailMessage message) {
        String url = toUrl(message);
        try {
            return new URI(url);
        } catch (java.net.URISyntaxException exception) {
            throw new MailException(
                    "Le lien mailto: n'a pas pu être construit : " + url, exception
            );
        }
    }

    private static String encodeAddresses(MailMessage message) {
        StringBuilder addresses = new StringBuilder();
        for (MailAddress address : message.recipients()) {
            if (addresses.length() > 0) {
                addresses.append(',');
            }
            addresses.append(encodeComponent(address.value()));
        }
        return addresses.toString();
    }

    /**
     * Encode une valeur pour un parametre d'URL. Les caracteres reserves sont tous encodes,
     * '@' compris dans une adresse, qui reste ainsi reconnue par les clients de messagerie.
     */
    private static String encodeComponent(String value) {
        StringBuilder encoded = new StringBuilder();
        for (byte current : value.getBytes(StandardCharsets.UTF_8)) {
            int character = current & 0xFF;
            if (isAllowed(character)) {
                encoded.append((char) character);
            } else {
                encoded.append('%').append(HEX[character >> 4]).append(HEX[character & 0x0F]);
            }
        }
        return encoded.toString();
    }

    /**
     * Caracteres laisses tels quels : alphanumeriques, signes de ponctuation usuels et les
     * separateurs d'adresses acceptes par le parametre {@code to}.
     */
    private static boolean isAllowed(int character) {
        if (character >= 'A' && character <= 'Z') {
            return true;
        }
        if (character >= 'a' && character <= 'z') {
            return true;
        }
        if (character >= '0' && character <= '9') {
            return true;
        }
        return switch (character) {
            case '-', '.', '_', '~', '!', '*', '\'', '(', ')', '@', ',', ';', '+', '=' -> true;
            default -> false;
        };
    }
}
