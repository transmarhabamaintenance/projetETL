 package com.etl.mail;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Adresse email de destinataire, validee sans dependance externe.
 */
public record MailAddress(String value) {

    public MailAddress {
        value = normalize(value);
        if (value == null || value.isBlank()) {
            throw new MailException("L'adresse email du destinataire est obligatoire.");
        }
        if (!isValid(value)) {
            throw new MailException(
                    "Adresse email invalide : \"" + value + "\". Format attendu : nom@domaine.fr"
            );
        }
    }

    /**
     * Analyse une liste de destinataires separes par des virgules, des points-virgules ou des
     * espaces, et renvoie les adresses normalisees, sans doublon.
     */
    public static List<MailAddress> parse(String recipients) {
        if (recipients == null || recipients.isBlank()) {
            throw new MailException("Saisissez au moins une adresse email de destinataire.");
        }
        List<MailAddress> parsed = new ArrayList<>();
        for (String candidate : recipients.split("[,;\\s]+")) {
            String trimmed = candidate.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            MailAddress address = new MailAddress(trimmed);
            if (!parsed.contains(address)) {
                parsed.add(address);
            }
        }
        if (parsed.isEmpty()) {
            throw new MailException("Saisissez au moins une adresse email de destinataire.");
        }
        return List.copyOf(parsed);
    }

    private static String normalize(String value) {
        return value == null ? null : value.trim().toLowerCase(Locale.ROOT);
    }

    private static boolean isValid(String value) {
        int at = value.indexOf('@');
        if (at <= 0 || at != value.lastIndexOf('@') || at == value.length() - 1) {
            return false;
        }
        for (int index = 0; index < value.length(); index++) {
            if (Character.isWhitespace(value.charAt(index))) {
                return false;
            }
        }
        String localPart = value.substring(0, at);
        if (localPart.startsWith(".") || localPart.endsWith(".") || localPart.contains("..")) {
            return false;
        }
        String domain = value.substring(at + 1);
        if (domain.startsWith(".") || domain.endsWith(".") || domain.contains("..")) {
            return false;
        }
        int dot = domain.indexOf('.');
        return dot > 0 && dot < domain.length() - 1;
    }

    @Override
    public String toString() {
        return value;
    }
}