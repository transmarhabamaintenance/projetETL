package com.etl.mail;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;

/**
 * Fournisseurs d'email pris en charge, avec leur endpoint et leur maniere
 * d'authentifier l'appel HTTP. Le format du corps de requete differe aussi :
 * Brevo et SendGrid acceptent du JSON avec pieces jointes base64, Mailgun
 * exige du multipart pour transmettre des fichiers binaires.
 */
public enum MailProvider {

    BREVO("https://api.brevo.com/v3/smtp/email", BodyFormat.JSON),
    SENDGRID("https://api.sendgrid.com/v3/mail/send", BodyFormat.JSON),
    MAILGUN("https://api.mailgun.net/v3/{domain}/messages", BodyFormat.MULTIPART);

    private final String endpointTemplate;
    private final BodyFormat bodyFormat;

    MailProvider(String endpointTemplate, BodyFormat bodyFormat) {
        this.endpointTemplate = endpointTemplate;
        this.bodyFormat = bodyFormat;
    }

    /**
     * Endpoint complet : Mailgun incorpore le domaine du compte, les autres sont fixes.
     */
    public URI endpoint(MailConfiguration configuration) {
        String endpoint = endpointTemplate;
        if (this == MAILGUN) {
            String domain = configuration.domain();
            if (domain.isEmpty()) {
                throw new MailException("Le domaine Mailgun est requis (ETL_MAIL_DOMAIN ou mail.domain).");
            }
            endpoint = endpoint.replace("{domain}", domain);
        }
        return URI.create(endpoint);
    }

    public boolean usesMultipart() {
        return bodyFormat == BodyFormat.MULTIPART;
    }

    /**
     * En-tete d'authentification propre au fournisseur.
     */
    public String authorizationHeader(MailConfiguration configuration) {
        String apiKey = configuration.apiKey();
        return switch (this) {
            case BREVO -> "api-key: " + apiKey;
            case SENDGRID -> "Authorization: Bearer " + apiKey;
            case MAILGUN -> "Authorization: Basic "
                    + Base64.getEncoder().encodeToString(("api:" + apiKey).getBytes(StandardCharsets.UTF_8));
        };
    }

    /**
     * Adresse d'expedition au format attendu par le fournisseur, avec le nom
     * lorsque celui-ci est renseigne.
     */
    public String formattedSender(MailConfiguration configuration) {
        String email = configuration.senderEmail();
        String name = configuration.senderName();
        if (name.isEmpty()) {
            return email;
        }
        return switch (this) {
            case BREVO -> "\"" + escapeJson(name) + "\" <" + email + ">";
            case SENDGRID -> "\"" + escapeJson(name) + "\" <" + email + ">";
            case MAILGUN -> name + " <" + email + ">";
        };
    }

    /**
     * Valeur canonique d'un fournisseur depuis la saisie utilisateur
     * (\"brevo\", \" SendGrid \" ...), ou null si inconnue.
     */
    public static MailProvider from(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private enum BodyFormat {
        JSON, MULTIPART
    }
}
