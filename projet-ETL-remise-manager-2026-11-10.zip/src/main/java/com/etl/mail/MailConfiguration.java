package com.etl.mail;

/**
 * Reglages valides de l'envoi par API HTTP. Les valeurs proviennent des variables
 * d'environnement ou d'un fichier mail.properties, jamais du code. La cle d'API est
 * un secret : elle n'est ni journalisee ni affichee dans les messages d'erreur.
 *
 * @param provider    fournisseur choisi
 * @param apiKey      cle d'API, obligatoire
 * @param senderName  nom d'expedition, "ETL Flotte" par defaut
 * @param senderEmail adresse d'expedition, obligatoire
 * @param domain      domaine du compte, requis uniquement par Mailgun
 */
public record MailConfiguration(MailProvider provider, String apiKey, String senderName,
                                String senderEmail, String domain) {

    public MailConfiguration {
        if (provider == null) {
            throw new MailException(configurationHelp("Le fournisseur d'email n'est pas reconnu."));
        }
        apiKey = apiKey == null ? "" : apiKey.trim();
        if (apiKey.isEmpty()) {
            throw new MailException(configurationHelp(
                    "La cle d'API est obligatoire (ETL_MAIL_API_KEY ou mail.api.key)."));
        }
        senderName = senderName == null || senderName.trim().isEmpty()
                ? MailConfigurationLoader.DEFAULT_SENDER_NAME
                : senderName.trim();
        senderEmail = senderEmail == null ? "" : senderEmail.trim();
        if (senderEmail.isEmpty()) {
            throw new MailException(configurationHelp(
                    "L'adresse d'expedition est obligatoire (ETL_MAIL_SENDER_EMAIL ou mail.sender.email)."));
        }
        try {
            new MailAddress(senderEmail);
        } catch (MailException exception) {
            throw new MailException(configurationHelp(
                    "L'adresse d'expedition est invalide : " + senderEmail), exception);
        }
        domain = domain == null ? "" : domain.trim();
        if (provider == MailProvider.MAILGUN && domain.isEmpty()) {
            throw new MailException(configurationHelp(
                    "Le domaine est requis avec Mailgun (ETL_MAIL_DOMAIN ou mail.domain)."));
        }
    }

    private static String configurationHelp(String reason) {
        return reason
                + "\n\nConfiguration lue depuis les variables d'environnement (prioritaires)"
                + " ou le fichier mail.properties (recherche : repertoire de travail, config/,"
                + " dossier personnel, ~/.etl/). Copiez mail.properties.example pour demarrer.";
    }
}
