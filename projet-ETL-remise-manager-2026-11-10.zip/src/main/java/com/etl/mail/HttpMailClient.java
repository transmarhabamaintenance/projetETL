package com.etl.mail;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;

/**
 * Envoie un email par l'API HTTP du fournisseur configure : JSON avec pieces
 * jointes base64 pour Brevo et SendGrid, multipart/form-data pour Mailgun dont
 * l'API n'accepte pas les fichiers binaires en JSON. Aucune dependance externe :
 * {@code java.net.http.HttpClient} suffit.
 *
 * <p>Les echecs sont traduits en messages distincts (cle refusee, quota,
 * service indisponible, reseau injoignable) sans jamais exposer la cle d'API.
 * Un envoi rate n'affecte jamais le traitement ETL deja abouti.</p>
 */
public class HttpMailClient implements MailClient {

    /** Marge sous la limite des fournisseurs : le base64 gonfle les fichiers d'un tiers. */
    static final long MAX_TOTAL_BYTES = 18L * 1024 * 1024;

    private static final Duration CONNECT_TIMEOUT = Duration.ofSeconds(10);
    private static final Duration REQUEST_TIMEOUT = Duration.ofSeconds(30);
    private static final String CRLF = "\r\n";
    private static final int MAX_REPORTED_BODY = 400;

    private final HttpClient httpClient;
    private final URI forcedEndpoint;

    public HttpMailClient() {
        this(null);
    }

    /**
     * Endpoint force, uniquement pour les tests : le stub local remplace l'API
     * reelle du fournisseur.
     */
    HttpMailClient(URI forcedEndpoint) {
        this.forcedEndpoint = forcedEndpoint;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(CONNECT_TIMEOUT)
                .build();
    }

    @Override
    public void send(MailConfiguration configuration, MailMessage message, List<Path> attachments) {
        if (configuration == null) {
            throw new MailException("La configuration d'envoi est obligatoire.");
        }
        if (message == null) {
            throw new MailException("Le message à envoyer est obligatoire.");
        }
        List<Attachment> files = readAttachments(attachments);
        MailProvider provider = configuration.provider();
        URI endpoint = forcedEndpoint != null ? forcedEndpoint : provider.endpoint(configuration);
        String authorization = provider.authorizationHeader(configuration);
        int separator = authorization.indexOf(':');
        String authName = authorization.substring(0, separator);
        String authValue = authorization.substring(separator + 1).trim();

        String boundary = boundary();
        HttpRequest request = HttpRequest.newBuilder(endpoint)
                .timeout(REQUEST_TIMEOUT)
                .header(authName, authValue)
                .header("Content-Type", provider.usesMultipart()
                        ? "multipart/form-data; boundary=" + boundary
                        : "application/json; charset=utf-8")
                .header("Accept", "application/json")
                .header("User-Agent", "Suite-ETL/1.0")
                .method("POST", provider.usesMultipart()
                        ? multipartBody(configuration, message, files, boundary)
                        : HttpRequest.BodyPublishers.ofString(jsonBody(provider, configuration, message, files),
                        StandardCharsets.UTF_8))
                .build();
        execute(request, provider);
    }

    private void execute(HttpRequest request, MailProvider provider) {
        HttpResponse<String> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new MailException("L'envoi a été interrompu : le réseau ou le service "
                    + "d'envoi n'a pas répondu.", exception);
        } catch (IOException exception) {
            throw new MailException("Le service d'envoi est injoignable : vérifiez votre "
                    + "connexion réseau. (" + safeReason(exception) + ")", exception);
        }
        int status = response.statusCode();
        if (status >= 200 && status < 300) {
            return;
        }
        throw describeFailure(status, response.body(), provider);
    }

    /**
     * Traduit le code HTTP en cause racine distincte, avec un extrait de la
     * reponse du fournisseur pour diagnostiquer. La cle d'API n'apparait
     * jamais dans ces messages.
     */
    private MailException describeFailure(int status, String body, MailProvider provider) {
        String detail = excerpt(body);
        if (status == 429) {
            return new MailException("Quota d'envoi atteint chez " + provider + " (HTTP 429)"
                    + detail + ". Réessayez plus tard.");
        }
        if (status >= 500) {
            return new MailException("Le service " + provider + " est indisponible (HTTP "
                    + status + ")" + detail + ". Réessayez dans quelques instants.");
        }
        if (status == 401 || status == 403) {
            return new MailException("Cle d'API refusée par " + provider + " (HTTP " + status
                    + ")" + detail + ". Vérifiez ETL_MAIL_API_KEY / mail.api.key.");
        }
        if (status >= 400) {
            return new MailException("Requête refusée par " + provider + " (HTTP " + status
                    + ")" + detail + ". Vérifiez la configuration d'expéditeur et les destinataires.");
        }
        return new MailException("Réponse inattendue de " + provider + " (HTTP " + status + ")" + detail + ".");
    }

    private String excerpt(String body) {
        if (body == null || body.isBlank()) {
            return "";
        }
        String cleaned = body.replaceAll("\\s+", " ").trim();
        if (cleaned.length() > MAX_REPORTED_BODY) {
            cleaned = cleaned.substring(0, MAX_REPORTED_BODY) + "…";
        }
        return " — " + cleaned;
    }

    private String safeReason(IOException exception) {
        String reason = exception.getMessage();
        return reason == null || reason.isBlank() ? exception.getClass().getSimpleName() : reason;
    }

    private List<Attachment> readAttachments(List<Path> attachments) {
        if (attachments == null || attachments.isEmpty()) {
            throw new MailException("Aucun fichier à joindre : le résultat du traitement est introuvable.");
        }
        List<Attachment> files = new ArrayList<>();
        long total = 0;
        for (Path attachment : attachments) {
            if (!Files.isRegularFile(attachment)) {
                throw new MailException("Pièce jointe introuvable : " + attachment);
            }
            byte[] content;
            try {
                content = Files.readAllBytes(attachment);
            } catch (IOException exception) {
                throw new MailException("La pièce jointe ne peut pas être lue : " + attachment, exception);
            }
            total += content.length;
            files.add(new Attachment(attachment.getFileName().toString(), content));
        }
        if (total > MAX_TOTAL_BYTES) {
            throw new MailException("Les pièces jointes dépassent 18 Mo : leur encodage en base64 "
                    + "dépasserait la limite des fournisseurs d'email. Utilisez « Ouvrir dans ma "
                    + "messagerie » pour transmettre le fichier autrement.");
        }
        return files;
    }

    // ------------------------------------------------------------------ JSON

    /**
     * Corps JSON de Brevo et SendGrid, construit a la main pour eviter toute
     * dependance de serialization.
     */
    private String jsonBody(MailProvider provider, MailConfiguration configuration,
                            MailMessage message, List<Attachment> files) {
        StringBuilder json = new StringBuilder(512);
        if (provider == MailProvider.BREVO) {
            json.append("{\"sender\":{\"email\":").append(quote(configuration.senderEmail()));
            if (!configuration.senderName().isEmpty()) {
                json.append(",\"name\":").append(quote(configuration.senderName()));
            }
            json.append("},\"to\":[");
            appendRecipients(json, message);
            json.append("],\"subject\":").append(quote(message.subject()));
            json.append(",\"htmlContent\":").append(quote(toHtml(message.body())));
            if (!files.isEmpty()) {
                json.append(",\"attachment\":[");
                for (int index = 0; index < files.size(); index++) {
                    Attachment file = files.get(index);
                    if (index > 0) {
                        json.append(',');
                    }
                    json.append("{\"name\":").append(quote(file.name()))
                            .append(",\"content\":").append(quote(file.base64()))
                            .append('}');
                }
                json.append(']');
            }
            json.append('}');
        } else {
            json.append("{\"personalizations\":[{\"to\":[");
            appendRecipients(json, message);
            json.append("]}],\"from\":").append(quote(provider.formattedSender(configuration)));
            json.append(",\"subject\":").append(quote(message.subject()));
            json.append(",\"content\":[{\"type\":\"text/plain\",\"value\":")
                    .append(quote(message.body())).append("}]");
            if (!files.isEmpty()) {
                json.append(",\"attachments\":[");
                for (int index = 0; index < files.size(); index++) {
                    Attachment file = files.get(index);
                    if (index > 0) {
                        json.append(',');
                    }
                    json.append("{\"content\":").append(quote(file.base64()))
                            .append(",\"filename\":").append(quote(file.name()))
                            .append(",\"type\":").append(quote(contentType(file.name())))
                            .append(",\"disposition\":\"attachment\"}");
                }
                json.append(']');
            }
            json.append('}');
        }
        return json.toString();
    }

    private void appendRecipients(StringBuilder json, MailMessage message) {
        for (int index = 0; index < message.recipients().size(); index++) {
            if (index > 0) {
                json.append(',');
            }
            json.append("{\"email\":").append(quote(message.recipients().get(index).value())).append('}');
        }
    }

    // ------------------------------------------------------------ multipart

    private HttpRequest.BodyPublisher multipartBody(MailConfiguration configuration, MailMessage message,
                                                    List<Attachment> files, String boundary) {
        StringBuilder head = new StringBuilder(256);
        appendField(head, boundary, "from", MailProvider.MAILGUN.formattedSender(configuration));
        appendField(head, boundary, "to", message.recipientsAsText());
        appendField(head, boundary, "subject", message.subject());
        appendField(head, boundary, "text", message.body());
        byte[] prefix = head.toString().getBytes(StandardCharsets.UTF_8);
        byte[] suffix = ("--" + boundary + "--" + CRLF).getBytes(StandardCharsets.UTF_8);
        List<byte[]> parts = new ArrayList<>();
        long length = prefix.length + suffix.length;
        for (Attachment file : files) {
            byte[] part = attachmentPart(boundary, file);
            parts.add(part);
            length += part.length;
        }
        byte[] body = new byte[(int) length];
        int offset = 0;
        offset = copy(prefix, body, offset);
        for (byte[] part : parts) {
            offset = copy(part, body, offset);
        }
        copy(suffix, body, offset);
        return HttpRequest.BodyPublishers.ofByteArray(body);
    }

    private byte[] attachmentPart(String boundary, Attachment file) {
        StringBuilder header = new StringBuilder(160);
        header.append("--").append(boundary).append(CRLF);
        header.append("Content-Disposition: attachment; filename=\"")
                .append(file.name().replace("\"", "")).append('"').append(CRLF);
        header.append("Content-Type: ").append(contentType(file.name())).append(CRLF);
        header.append("Content-Transfer-Encoding: binary").append(CRLF).append(CRLF);
        byte[] head = header.toString().getBytes(StandardCharsets.UTF_8);
        byte[] part = new byte[head.length + file.content().length + CRLF.length()];
        int offset = copy(head, part, 0);
        offset = copy(file.content(), part, offset);
        copy(CRLF.getBytes(StandardCharsets.US_ASCII), part, offset);
        return part;
    }

    private void appendField(StringBuilder part, String boundary, String name, String value) {
        part.append("--").append(boundary).append(CRLF);
        part.append("Content-Disposition: form-data; name=\"").append(name).append('"').append(CRLF);
        part.append("Content-Type: text/plain; charset=utf-8").append(CRLF).append(CRLF);
        part.append(value).append(CRLF);
    }

    private String boundary() {
        return "etl-" + Long.toUnsignedString(System.nanoTime(), 36);
    }

    // --------------------------------------------------------------- divers

    private static int copy(byte[] source, byte[] target, int offset) {
        System.arraycopy(source, 0, target, offset, source.length);
        return offset + source.length;
    }

    private static String quote(String value) {
        StringBuilder quoted = new StringBuilder(value.length() + 16);
        quoted.append('"');
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            switch (character) {
                case '"' -> quoted.append("\\\"");
                case '\\' -> quoted.append("\\\\");
                case '\b' -> quoted.append("\\b");
                case '\f' -> quoted.append("\\f");
                case '\n' -> quoted.append("\\n");
                case '\r' -> quoted.append("\\r");
                case '\t' -> quoted.append("\\t");
                default -> {
                    if (character < 0x20) {
                        quoted.append(String.format("\\u%04x", (int) character));
                    } else {
                        quoted.append(character);
                    }
                }
            }
        }
        return quoted.append('"').toString();
    }

    /**
     * Corps HTML minimal pour Brevo, qui exige htmlContent : le texte est echappe
     * et les sauts de ligne deviennent des retours a la ligne.
     */
    private static String toHtml(String body) {
        String escaped = body.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        return escaped.replace("\n", "<br>" + CRLF);
    }

    private static String contentType(String fileName) {
        String lower = fileName.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".xlsx")) {
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
        if (lower.endsWith(".xls")) {
            return "application/vnd.ms-excel";
        }
        if (lower.endsWith(".txt")) {
            return "text/plain";
        }
        if (lower.endsWith(".pdf")) {
            return "application/pdf";
        }
        return "application/octet-stream";
    }

    private record Attachment(String name, byte[] content) {
        private String base64() {
            return Base64.getEncoder().encodeToString(content);
        }
    }
}
