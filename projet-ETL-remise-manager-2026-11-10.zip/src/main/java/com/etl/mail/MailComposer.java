package com.etl.mail;

import com.etl.batch.BatchResult;
import com.etl.model.EtlResult;

import java.util.Objects;

/**
 * Compose l'email de synthese envoye apres un traitement ETL reussi. Le corps reste volontairement
 * court : une seule ligne recapitulative, la ou le rapport complet est disponible dans le
 * classeur de sortie et dans le rapport ecrit a cote.
 */
public final class MailComposer {

    private MailComposer() {
    }

    /**
     * Objet propose par defaut pour un traitement de fichier unique.
     */
    public static String defaultSubject(EtlResult result) {
        Objects.requireNonNull(result, "Le résultat du traitement est obligatoire");
        return "Traitement ETL terminé : " + result.loadedRows() + " ligne(s)";
    }

    /**
     * Objet propose par defaut pour un traitement par lot.
     */
    public static String defaultSubject(BatchResult result) {
        Objects.requireNonNull(result, "Le résultat du lot est obligatoire");
        return "Traitement ETL terminé : " + result.mergedFiles() + " classeur(s) fusionné(s)";
    }

    /**
     * Ligne recapitulative jointe a l'email lorsque l'utilisateur ne saisit pas de message. Le
     * rapport detaille n'est volontairement pas repris ici : il reste consultable dans
     * {@code reportArea}, dans le fichier de rapport et dans le classeur produit.
     */
    public static String defaultBody(EtlResult result) {
        Objects.requireNonNull(result, "Le résultat du traitement est obligatoire");
        return "Traitement ETL terminé : "
                + result.loadedRows() + " ligne(s) chargée(s), "
                + result.errors() + " erreur(s), "
                + result.duplicates() + " doublon(s). Fichier : " + result.outputPath();
    }

    /**
     * Ligne recapitulative d'un traitement par lot.
     */
    public static String defaultBody(BatchResult result) {
        Objects.requireNonNull(result, "Le résultat du lot est obligatoire");
        return "Traitement ETL terminé : "
                + result.mergedFiles() + " classeur(s) fusionné(s), "
                + result.appendedRows() + " ligne(s) ajoutée(s), "
                + result.errors() + " erreur(s). Fichier : " + result.outputPath();
    }

    /**
     * Corps final : le message libre de l'utilisateur suivi de la ligne recapitulative, celle-ci
     * n'etant pas repetee si elle figure deja dans le message saisi.
     */
    public static String compose(String userMessage, String defaultBody) {
        String message = userMessage == null ? "" : userMessage.trim();
        String summary = defaultBody == null ? "" : defaultBody.trim();
        if (message.isEmpty()) {
            return summary;
        }
        if (summary.isEmpty() || message.contains(summary)) {
            return message;
        }
        return message + "\n\n" + summary;
    }
}