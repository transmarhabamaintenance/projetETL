package com.etl.mail;

import java.util.List;

/**
 * Contenu d'un email a ouvrir dans le client de messagerie du poste. Le message est
 * facultatif : le corps peut alors etre uniquement constitue du resume du traitement.
 *
 * @param recipients adresses des destinataires
 * @param subject    objet du message
 * @param body       message facultatif, vide si l'utilisateur n'en saisit pas
 */
public record MailMessage(List<MailAddress> recipients, String subject, String body) {

    public MailMessage {
        recipients = List.copyOf(recipients == null ? List.of() : recipients);
        if (recipients.isEmpty()) {
            throw new MailException("Saisissez au moins une adresse email de destinataire.");
        }
        subject = subject == null ? "" : subject.trim();
        if (subject.isEmpty()) {
            throw new MailException("Saisissez l'objet du message.");
        }
        if (subject.length() > 200) {
            throw new MailException("L'objet du message ne peut pas dépasser 200 caractères.");
        }
        body = body == null ? "" : body.trim();
    }

    /**
     * Cree un email a partir des saisies de l'utilisateur. Les destinataires peuvent etre
     * separes par des virgules, des points-virgules ou des espaces.
     */
    public static MailMessage of(String recipients, String subject, String body) {
        return new MailMessage(MailAddress.parse(recipients), subject, body);
    }

    public boolean hasBody() {
        return !body.isEmpty();
    }

    public String recipientsAsText() {
        return String.join(", ", recipients.stream().map(MailAddress::value).toList());
    }
}