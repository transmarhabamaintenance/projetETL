package com.etl.mail;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;

/**
 * Envoie directement le message par SMTP avec les fichiers produits par le traitement
 * en pièces jointes. Gmail est la configuration par défaut (smtp.gmail.com:587,
 * STARTTLS) ; le compte expéditeur et son mot de passe d'application sont lus dans un
 * fichier {@code mail.properties} placé à la racine du dossier de lancement, dans
 * {@code config/}, ou dans le dossier utilisateur. Ce fichier contient un secret et
 * n'est jamais versionné. Un échec d'envoi n'affecte jamais le traitement ETL déjà
 * abouti : l'exception levée reste une {@link MailException}.
 */
public final class MailSender {

    private static final String CONFIG_NAME = "mail.properties";
    /** Marge volontaire sous la limite Gmail de 25 Mo par message. */
    private static final long MAX_TOTAL_BYTES = 24L * 1024 * 1024;

    private MailSender() {
    }

    public static void send(MailMessage mail, List<Path> attachments) {
        if (mail == null) {
            throw new MailException("Le message à envoyer est obligatoire.");
        }
        Properties config = loadConfig();
        String from = config.getProperty("etl.email.from", "").trim();
        String password = config.getProperty("etl.email.password", "").trim();
        if (from.isEmpty() || password.isEmpty()) {
            throw new MailException(configHelp("etl.email.from / etl.email.password sont manquants."));
        }
        List<Path> files = checkAttachments(attachments);
        try {
            doSend(config, from, password, mail, files);
        } catch (MessagingException | IOException exception) {
            throw new MailException("L'envoi SMTP a échoué : " + exception.getMessage(), exception);
        }
    }

    /**
     * Cherche mail.properties puis applique les valeurs Gmail par défaut pour les
     * clés SMTP absentes. Aucun fichier trouvé : exception avec la marche à suivre.
     */
    private static Properties loadConfig() {
        Path location = findConfig();
        if (location == null) {
            throw new MailException(configHelp("Le fichier mail.properties est introuvable."));
        }
        Properties file = new Properties();
        try (InputStream in = Files.newInputStream(location)) {
            file.load(in);
        } catch (IOException exception) {
            throw new MailException("Le fichier " + location + " n'a pas pu être lu.", exception);
        }
        Properties config = new Properties();
        config.put("mail.smtp.host", "smtp.gmail.com");
        config.put("mail.smtp.port", "587");
        config.put("mail.smtp.auth", "true");
        config.put("mail.smtp.starttls.enable", "true");
        config.putAll(file);
        return config;
    }

    private static Path findConfig() {
        Path workingDir = Paths.get(System.getProperty("user.dir", ".")).toAbsolutePath().normalize();
        List<Path> candidates = List.of(
                workingDir.resolve(CONFIG_NAME),
                workingDir.resolve("config").resolve(CONFIG_NAME),
                Paths.get(System.getProperty("user.home", ".")).resolve(CONFIG_NAME));
        for (Path candidate : candidates) {
            if (Files.isRegularFile(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private static List<Path> checkAttachments(List<Path> attachments) {
        if (attachments == null || attachments.isEmpty()) {
            throw new MailException("Aucun fichier à joindre : le résultat du traitement est introuvable.");
        }
        long total = 0;
        for (Path attachment : attachments) {
            if (!Files.isRegularFile(attachment)) {
                throw new MailException("Pièce jointe introuvable : " + attachment);
            }
            try {
                total += Files.size(attachment);
            } catch (IOException exception) {
                throw new MailException("La taille de la pièce jointe ne peut pas être lue : " + attachment,
                        exception);
            }
        }
        if (total > MAX_TOTAL_BYTES) {
            throw new MailException("Les pièces jointes dépassent 24 Mo : Gmail refuse les messages de plus "
                    + "de 25 Mo. Utilisez « Ouvrir dans ma messagerie » pour transmettre le fichier "
                    + "autrement.");
        }
        return List.copyOf(attachments);
    }

    private static void doSend(Properties config, String from, String password,
                               MailMessage mail, List<Path> attachments) throws MessagingException, IOException {
        Session session = Session.getInstance(config, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        for (MailAddress recipient : mail.recipients()) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient.value()));
        }
        message.setSubject(mail.subject(), "UTF-8");

        MimeMultipart multipart = new MimeMultipart();
        MimeBodyPart text = new MimeBodyPart();
        text.setText(mail.body(), "UTF-8");
        multipart.addBodyPart(text);
        for (Path attachment : attachments) {
            MimeBodyPart part = new MimeBodyPart();
            part.attachFile(attachment.toFile());
            multipart.addBodyPart(part);
        }
        message.setContent(multipart);
        Transport.send(message);
    }

    private static String configHelp(String reason) {
        return reason
                + "\n\nCréez un fichier mail.properties à la racine du dossier de lancement (ou dans config/) :"
                + "\n  etl.email.from=votre.compte@gmail.com"
                + "\n  etl.email.password=mot de passe d'application Gmail (16 caractères)"
                + "\n\nLe mot de passe d'application exige la validation en deux étapes du compte Google :"
                + " https://myaccount.google.com/apppasswords";
    }
}
