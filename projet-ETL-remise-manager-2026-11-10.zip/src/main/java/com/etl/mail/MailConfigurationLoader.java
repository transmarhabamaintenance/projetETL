package com.etl.mail;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.function.Function;

/**
 * Charge la configuration d'envoi au moment de l'envoi. Les variables d'environnement
 * sont prioritaires sur le fichier mail.properties, lui-même cherche dans le repertoire
 * de travail, puis config/, puis le dossier personnel, puis ~/.etl/. Aucune valeur n'est
 * codée en dur a part les defauts sans secret.
 */
public final class MailConfigurationLoader {

    /** Nom d'expedition propose lorsque l'utilisateur n'en renseigne aucun. */
    public static final String DEFAULT_SENDER_NAME = "ETL Flotte";
    /** Fournisseur retenu lorsque rien n'est configure. */
    static final MailProvider DEFAULT_PROVIDER = MailProvider.BREVO;

    private static final String CONFIG_NAME = "mail.properties";
    private static final String ENV_PROVIDER = "ETL_MAIL_PROVIDER";
    private static final String ENV_API_KEY = "ETL_MAIL_API_KEY";
    private static final String ENV_SENDER_NAME = "ETL_MAIL_SENDER_NAME";
    private static final String ENV_SENDER_EMAIL = "ETL_MAIL_SENDER_EMAIL";
    private static final String ENV_DOMAIN = "ETL_MAIL_DOMAIN";

    private final Function<String, String> environment;

    public MailConfigurationLoader() {
        this(System::getenv);
    }

    /**
     * Permet aux tests d'injecter un environnement factice sans toucher au processus.
     */
    MailConfigurationLoader(Function<String, String> environment) {
        this.environment = environment;
    }

    /**
     * Lit la configuration puis la valide. La cle vient de l'environnement si present,
     * sinon du fichier, sinon l'exception explique comment creer mail.properties.
     */
    public MailConfiguration load() {
        Properties file = loadFile();
        String provider = firstNonBlank(environment.apply(ENV_PROVIDER), file.getProperty("mail.provider"));
        String apiKey = firstNonBlank(environment.apply(ENV_API_KEY), file.getProperty("mail.api.key"));
        String senderName = firstNonBlank(environment.apply(ENV_SENDER_NAME), file.getProperty("mail.sender.name"));
        String senderEmail = firstNonBlank(environment.apply(ENV_SENDER_EMAIL), file.getProperty("mail.sender.email"));
        String domain = firstNonBlank(environment.apply(ENV_DOMAIN), file.getProperty("mail.domain"));
        if (apiKey == null || senderEmail == null) {
            throw new MailException(configHelp(
                    "La cle d'API et l'adresse d'expedition sont obligatoires."));
        }
        return new MailConfiguration(parseProvider(provider), apiKey, senderName, senderEmail, domain);
    }

    private MailProvider parseProvider(String raw) {
        if (raw == null || raw.isBlank()) {
            return DEFAULT_PROVIDER;
        }
        try {
            return MailProvider.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            throw new MailException("Fournisseur d'email inconnu : \"" + raw.trim()
                    + "\". Valeurs acceptees : BREVO, SENDGRID, MAILGUN.", exception);
        }
    }

    /**
     * Cherche mail.properties aux quatre emplacements documentes. Aucun fichier : on
     * continue avec un properties vide, l'absence de cle sera signalee apres.
     */
    private Properties loadFile() {
        Path location = findConfig();
        if (location == null) {
            return new Properties();
        }
        Properties file = new Properties();
        try (InputStream in = Files.newInputStream(location)) {
            file.load(in);
        } catch (IOException exception) {
            throw new MailException("Le fichier " + location + " n'a pas pu être lu.", exception);
        }
        return file;
    }

    private Path findConfig() {
        Path workingDir = Paths.get(System.getProperty("user.dir", ".")).toAbsolutePath().normalize();
        Path home = Paths.get(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        List<Path> candidates = List.of(
                workingDir.resolve(CONFIG_NAME),
                workingDir.resolve("config").resolve(CONFIG_NAME),
                home.resolve(CONFIG_NAME),
                home.resolve(".etl").resolve(CONFIG_NAME));
        for (Path candidate : candidates) {
            if (Files.isRegularFile(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private static String firstNonBlank(String first, String second) {
        if (first != null && !first.isBlank()) {
            return first;
        }
        if (second != null && !second.isBlank()) {
            return second.trim();
        }
        return null;
    }

    private static String configHelp(String reason) {
        return reason
                + "\n\nVariables d'environnement :"
                + "\n  ETL_MAIL_PROVIDER   = BREVO | SENDGRID | MAILGUN (defaut BREVO)"
                + "\n  ETL_MAIL_API_KEY    = cle d'API"
                + "\n  ETL_MAIL_SENDER_EMAIL = adresse d'expedition"
                + "\n  ETL_MAIL_SENDER_NAME  = nom d'expedition (defaut " + DEFAULT_SENDER_NAME + ")"
                + "\n  ETL_MAIL_DOMAIN     = domaine du compte (requis par Mailgun)"
                + "\n\nOu copiez mail.properties.example vers mail.properties (recherche :"
                + " repertoire de travail, config/, dossier personnel, ~/.etl/).";
    }
}
