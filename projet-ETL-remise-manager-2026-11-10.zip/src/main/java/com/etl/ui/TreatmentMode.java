package com.etl.ui;

/**
 * Etendue du traitement demande depuis l'interface.
 */
public enum TreatmentMode {

    /** Un seul classeur source, traite selon le gabarit choisi. */
    FICHIER_UNIQUE("Un seul fichier", "Sélectionnez un classeur .xlsx"),

    /**
     * Tous les classeurs d'un dossier, accumules dans un classeur de sortie unique sur une
     * seule feuille.
     */
    DOSSIER("Un dossier (plusieurs fichiers)",
            "Sélectionnez le dossier contenant tous les classeurs .xlsx");

    private final String label;
    private final String prompt;

    TreatmentMode(String label, String prompt) {
        this.label = label;
        this.prompt = prompt;
    }

    public String label() {
        return label;
    }

    public String prompt() {
        return prompt;
    }

    @Override
    public String toString() {
        return label;
    }
}
