package com.etl.ui;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 * Écran lanceur : deux entrées vers les deux applications de la suite.
 */
public class HubView extends BorderPane {

    public HubView() {
        getStyleClass().add("app-root");
        setTop(createHeader());
        setCenter(createContent());
    }

    private VBox createHeader() {
        Label title = new Label(Hub.TITLE);
        title.getStyleClass().add("app-title");

        Label subtitle = new Label("Choisissez l'application à ouvrir dans sa propre fenêtre.");
        subtitle.getStyleClass().add("app-subtitle");
        subtitle.setWrapText(true);

        VBox header = new VBox(4, title, subtitle);
        header.getStyleClass().add("app-header");
        header.setPadding(new Insets(24, 30, 22, 30));
        return header;
    }

    private VBox createContent() {
        VBox content = new VBox(18);
        content.setPadding(new Insets(26, 30, 30, 30));

        content.getChildren().addAll(
                createCard("ETL liveTracking",
                        "Nettoyez, validez et exportez vos données de suivi de flotte.",
                        () -> Main.open(new Stage())),
                createCard("ETL heures de travail",
                        "Transforme un Daily Trip Report en fichiers d'heures de travail.",
                        () -> com.etl.heures.ui.Main.open(new Stage()))
        );
        return content;
    }

    private static VBox createCard(String title, String description, Runnable action) {
        Label descriptionLabel = new Label(description);
        descriptionLabel.getStyleClass().add("app-description");
        descriptionLabel.setWrapText(true);
        descriptionLabel.setTextAlignment(TextAlignment.LEFT);

        Button button = new Button(title);
        button.getStyleClass().add("primary-button");
        button.setMaxWidth(Double.MAX_VALUE);
        button.setPrefHeight(48);
        button.setOnAction(event -> action.run());

        VBox card = new VBox(12, descriptionLabel, button);
        card.getStyleClass().add("card");
        return card;
    }
}