package com.etl.ui;

import com.etl.mail.MailException;
import com.etl.mail.MailMessage;
import javafx.geometry.Insets;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Optional;

/**
 * Boîte de dialogue de préparation du message, affichée après un traitement réussi. Elle
 * collecte les destinataires, l'objet et le message facultatif, puis renvoie ces valeurs
 * avec le mode d'envoi choisi : ouverture dans le client de messagerie lourd
 * ({@link com.etl.mail.MailLauncher}) ou envoi direct par l'API via
 * {@link com.etl.mail.MailService} avec le classeur de sortie et le rapport en pièces
 * jointes.
 */
public class MailSendDialog extends Dialog<MailSendDialog.MailSendChoice> {

    private final TextField recipientsField = new TextField();
    private final TextField subjectField = new TextField();
    private final TextArea messageArea = new TextArea();
    private static final ButtonType CANCEL_ACTION = ButtonType.CANCEL;
    private static final ButtonType OPEN_ACTION = new ButtonType(
            "Ouvrir dans ma messagerie", ButtonBar.ButtonData.OTHER);
    private static final ButtonType SEND_ACTION = new ButtonType(
            "Envoyer par email", ButtonBar.ButtonData.OK_DONE);

    private MailSendChoice pendingChoice;

    public MailSendDialog(String defaultRecipients, String defaultSubject, String defaultBody) {
        setTitle("Envoyer le résultat par email");
        setHeaderText("Destinataires, objet et texte serviront soit à un envoi direct par le fournisseur configuré "
                + "(classeur et rapport joints), soit à un message pré-rempli dans votre "
                + "logiciel de messagerie.");
        setResizable(true);

        getDialogPane().getStyleClass().add("mail-dialog");
        getDialogPane().setPrefWidth(580);
        getDialogPane().setMinWidth(480);
        getDialogPane().getButtonTypes().setAll(CANCEL_ACTION, OPEN_ACTION, SEND_ACTION);
        setResultConverter(buttonType -> buttonType == CANCEL_ACTION ? null : pendingChoice);

        recipientsField.setText(defaultRecipients == null ? "" : defaultRecipients);
        recipientsField.setPromptText("nom1@domaine.fr, nom2@domaine.fr");
        recipientsField.setPrefColumnCount(40);
        recipientsField.setTooltip(new Tooltip(
                "Plusieurs destinataires sont acceptés, séparés par des virgules, "
                        + "des points-virgules ou des espaces."
        ));

        subjectField.setText(defaultSubject == null ? "" : defaultSubject);
        subjectField.setPrefColumnCount(40);

        messageArea.setPromptText("Message facultatif. Laissez vide pour n'envoyer que la ligne de résumé.");
        messageArea.setWrapText(true);
        messageArea.setPrefRowCount(6);
        messageArea.getStyleClass().add("mail-text-area");

        getDialogPane().setContent(createContent(defaultBody));
        Button cancelButton = (Button) getDialogPane().lookupButton(CANCEL_ACTION);
        Button openButton = (Button) getDialogPane().lookupButton(OPEN_ACTION);
        Button sendButton = (Button) getDialogPane().lookupButton(SEND_ACTION);
        cancelButton.getStyleClass().add("secondary-button");
        openButton.getStyleClass().add("secondary-button");
        sendButton.getStyleClass().add("primary-button");
        sendButton.setDefaultButton(true);
        openButton.addEventFilter(ActionEvent.ACTION, event -> submit(false, event));
        sendButton.addEventFilter(ActionEvent.ACTION, event -> submit(true, event));
        setOnShown(event -> {
            recipientsField.requestFocus();
        });
    }

    private VBox createContent(String defaultBody) {
        GridPane form = new GridPane();
        form.setHgap(14);
        form.setVgap(12);
        ColumnConstraints labels = new ColumnConstraints();
        labels.setMinWidth(110);
        labels.setPrefWidth(125);
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(labels, fields);

        Label recipientsLabel = new Label("Destinataire(s)");
        recipientsLabel.setLabelFor(recipientsField);
        recipientsField.setMaxWidth(Double.MAX_VALUE);

        Label subjectLabel = new Label("Objet");
        subjectLabel.setLabelFor(subjectField);
        subjectField.setMaxWidth(Double.MAX_VALUE);

        Label messageLabel = new Label("Message");
        messageLabel.setLabelFor(messageArea);
        messageArea.setMaxWidth(Double.MAX_VALUE);
        VBox.setVgrow(messageArea, Priority.ALWAYS);

        form.addRow(0, recipientsLabel, recipientsField);
        form.addRow(1, subjectLabel, subjectField);
        form.addRow(2, messageLabel, messageArea);

        Label hint = new Label(hintMessage(defaultBody));
        hint.setWrapText(true);
        hint.getStyleClass().add("mail-hint");

        VBox content = new VBox(14, form, hint);
        content.setPadding(new Insets(20, 24, 18, 24));
        return content;
    }

    /**
     * Precise la ligne recapitulative jointe lorsque le message reste vide, et rappelle ce
     * que fait chaque bouton d'envoi.
     */
    private String hintMessage(String defaultBody) {
        StringBuilder hint = new StringBuilder();
        hint.append("Si le message reste vide, le texte sera uniquement :");
        if (defaultBody != null && !defaultBody.isBlank()) {
            hint.append("\n\n").append(defaultBody);
        }
        hint.append("\n\n« Envoyer par email » transmet le classeur de sortie et le rapport en pièces "
                + "jointes ; il exige une clé API et une adresse d'expédition configurées dans "
                + "mail.properties. « Ouvrir dans ma messagerie » prépare le message dans votre "
                + "logiciel de messagerie : relisez-le, ajoutez les fichiers si besoin, puis cliquez "
                + "sur Envoyer.");
        return hint.toString();
    }

    /**
     * Valide la saisie puis publie le résultat avec le mode d'envoi choisi. La boîte reste
     * ouverte tant que les destinataires ou l'objet ne sont pas valides.
     */
    private void submit(boolean sendDirectly, ActionEvent event) {
        try {
            pendingChoice = new MailSendChoice(MailMessage.of(recipientsField.getText(), subjectField.getText(),
                    messageArea.getText()), sendDirectly);
        } catch (MailException exception) {
            event.consume();
            Alert alert = new Alert(Alert.AlertType.WARNING, exception.getMessage(), ButtonType.OK);
            alert.initOwner(getOwner());
            alert.setHeaderText("Saisie incomplète");
            alert.showAndWait();
        }
    }

    /**
     * Affiche la boîte de dialogue et renvoie le message validé avec son mode d'envoi, ou un
     * résultat vide si l'utilisateur annule.
     */
    public static Optional<MailSendChoice> show(Stage owner, String defaultRecipients,
                                                String defaultSubject, String defaultBody) {
        MailSendDialog dialog = new MailSendDialog(defaultRecipients, defaultSubject, defaultBody);
        dialog.initOwner(owner);
        return dialog.showAndWait();
    }

    /**
     * Message validé et mode d'envoi choisi : envoi direct par API avec pièces
     * jointes, ou ouverture pré-remplie dans le client de messagerie lourd du poste.
     */
    public record MailSendChoice(MailMessage message, boolean sendDirectly) {
    }
}
