package com.etl.ui;

import com.etl.service.EtlReportFormatter;
import com.etl.service.EtlService;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.net.URL;

/**
 * Point d'entrée JavaFX de l'application ETL liveTracking.
 */
public class Main extends Application {

    public static final String TITLE = "ETL Flotte";

    @Override
    public void start(Stage stage) {
        open(stage);
    }

    /**
     * Construit la scène principale, stylesheet comprise.
     */
    public static Scene createScene(Stage stage) {
        URL stylesheet = MainView.class.getResource("application.css");
        if (stylesheet == null) {
            throw new IllegalStateException("La feuille de style application.css est introuvable");
        }
        Rectangle2D screen = Screen.getPrimary().getVisualBounds();
        double width = Math.min(1100, screen.getWidth() * 0.92);
        double height = Math.min(760, screen.getHeight() * 0.90);
        Scene scene = new Scene(new MainView(stage), width, height);
        scene.getStylesheets().add(stylesheet.toExternalForm());
        return scene;
    }

    /**
     * Ouvre l'application ETL liveTracking dans la fenêtre fournie.
     */
    public static Stage open(Stage stage) {
        stage.setTitle(TITLE);
        Rectangle2D screen = Screen.getPrimary().getVisualBounds();
        stage.setMinWidth(Math.min(760, screen.getWidth() * 0.92));
        stage.setMinHeight(Math.min(520, screen.getHeight() * 0.90));
        stage.setScene(createScene(stage));
        stage.show();
        return stage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
