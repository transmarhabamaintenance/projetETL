package com.etl.ui;

import javafx.application.Application;

/**
 * Point d'entrée sans JavaFX module-directives : lance l'écran {@link Hub}.
 */
public final class Launcher {

    private Launcher() {
    }

    public static void main(String[] args) {
        Application.launch(Hub.class, args);
    }
}