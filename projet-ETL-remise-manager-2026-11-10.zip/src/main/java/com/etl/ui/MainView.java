package com.etl.ui;

import com.etl.batch.BatchResult;
import com.etl.batch.BatchService;
import com.etl.extract.ExcelExtractor;
import com.etl.load.OutputProfile;
import com.etl.mail.MailComposer;
import com.etl.mail.MailException;
import com.etl.mail.MailLauncher;
import com.etl.mail.MailMessage;
import com.etl.mail.MailService;
import com.etl.model.EtlProgress;
import com.etl.model.EtlResult;
import com.etl.service.BatchReportFormatter;
import com.etl.service.EtlReportFormatter;
import com.etl.service.EtlService;
import com.etl.validation.DuplicatePolicy;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Vue JavaFX construite par programme, indépendante de toute plateforme desktop.
 */
public class MainView extends BorderPane {

    private static final double INDETERMINATE_PROGRESS = ProgressBar.INDETERMINATE_PROGRESS;

    private static final String SINGLE_PROFILE_TOOLTIP =
            "Choisissez le format correspondant à votre suivi. VIVO reçoit le rapport à 14 colonnes. "
                    + "TOTAL renseigne le tableau horaire (code camion, tracteur, chauffeur et position). "
                    + "Pour conserver les autres onglets, choisissez le classeur de suivi existant "
                    + "comme sortie et sélectionnez « Ajouter à l’historique ». Les vitesses de 80 km/h "
                    + "ou plus sont ramenées à 75 dans le rapport manager.";
    private static final String BATCH_PROFILE_TOOLTIP =
            "Le mode dossier ajoute les lignes de chaque fichier dans le format choisi. Si le "
                    + "classeur de sortie existe, choisissez « Ajouter à l’historique » pour garder "
                    + "les données et les autres onglets.";

    private final Stage owner;
    private final EtlService etlService = new EtlService();
    private final BatchService batchService = new BatchService();
    private final MailService mailService = new MailService();
    private final String defaultMailRecipient = "";
    private final ExcelExtractor sheetLister = new ExcelExtractor();
    private final TextField inputPathField = new TextField();
    private final TextField outputPathField = new TextField();
    private final Label inputLabel = new Label("Fichier source");
    private final Label sheetLabel = new Label("Feuille");
    private final Label sheetSpacer = new Label();
    private final ComboBox<String> sheetSelector = new ComboBox<>();
    private final ComboBox<TreatmentMode> modeSelector = new ComboBox<>();
    private final ComboBox<OutputProfile> profileSelector = new ComboBox<>();
    private final Button chooseInputButton = new Button("Parcourir…");
    private final Button chooseOutputButton = new Button("Parcourir…");
    private final Button runButton = new Button("Lancer le traitement");
    private final Button openOutputButton = new Button("Ouvrir le fichier de sortie");
    private final Button sendMailButton = new Button("Envoyer par email");
    private final ProgressBar progressBar = new ProgressBar(INDETERMINATE_PROGRESS);
    private final Label progressLabel = new Label("Prêt à traiter un fichier Excel.");
    private final TextArea reportArea = new TextArea();
    private TreatmentMode lastMode = TreatmentMode.FICHIER_UNIQUE;
    private OutputProfile profileBeforeBatch = OutputProfile.NETTOYAGE;
    private Path lastOutputPath;
    private List<Path> lastAttachments = List.of();
    private String lastMailSubject;
    private String lastMailBody;

    public MainView(Stage owner) {
        this.owner = owner;
        getStyleClass().add("app-root");
        profileSelector.getItems().setAll(OutputProfile.values());
        profileSelector.setValue(OutputProfile.NETTOYAGE);
        modeSelector.getItems().setAll(TreatmentMode.values());
        modeSelector.setValue(TreatmentMode.FICHIER_UNIQUE);
        setTop(createHeader());
        setCenter(createContent());
        configureActions();
        applyMode();
    }

    private VBox createHeader() {
        Label title = new Label("ETL Flotte");
        title.getStyleClass().add("app-title");

        Label subtitle = new Label(
                "Nettoyez, validez et exportez vos données de suivi sans modifier le fichier source."
        );
        subtitle.getStyleClass().add("app-subtitle");
        subtitle.setWrapText(true);

        VBox header = new VBox(4, title, subtitle);
        header.getStyleClass().add("app-header");
        header.setPadding(new Insets(24, 30, 22, 30));
        return header;
    }

    private BorderPane createContent() {
        BorderPane content = new BorderPane();
        VBox controls = new VBox(18);
        controls.setPadding(new Insets(18, 28, 18, 28));
        controls.getChildren().addAll(createFileCard(), createProgressCard());
        ScrollPane controlsScroll = new ScrollPane(controls);
        controlsScroll.setFitToWidth(true);
        controlsScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        controlsScroll.getStyleClass().add("content-scroll");
        VBox reportCard = createReportCard();
        content.setCenter(controlsScroll);
        content.setBottom(reportCard);
        BorderPane.setMargin(reportCard, new Insets(0, 28, 18, 28));
        return content;
    }

    private VBox createFileCard() {
        Label sectionTitle = new Label("Fichiers");
        sectionTitle.getStyleClass().add("section-title");

        GridPane form = new GridPane();
        form.setHgap(14);
        form.setVgap(14);
        ColumnConstraints labels = new ColumnConstraints();
        labels.setMinWidth(120);
        labels.setPrefWidth(145);
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(labels, fields, new ColumnConstraints());

        Label modeLabel = new Label("Traitement");
        modeLabel.setLabelFor(modeSelector);
        modeSelector.setMaxWidth(Double.MAX_VALUE);
        modeSelector.setTooltip(new Tooltip(
                "Un seul fichier : traite le classeur choisi. Un dossier : fusionne tous les "
                        + "classeurs .xlsx du dossier dans un classeur unique."
        ));

        inputLabel.setLabelFor(inputPathField);
        inputPathField.setPromptText(TreatmentMode.FICHIER_UNIQUE.prompt());

        Label outputLabel = new Label("Fichier de sortie");
        outputLabel.setLabelFor(outputPathField);
        outputPathField.setPromptText("Choisissez un nouveau fichier ou un classeur de suivi existant");
        outputPathField.setTooltip(new Tooltip("Un rapport texte est créé à côté de ce fichier."));

        sheetLabel.setLabelFor(sheetSelector);
        sheetSelector.setPromptText("Choisissez la feuille à traiter");
        sheetSelector.setTooltip(new Tooltip("Par exemple VIVO ou TOTAL dans un classeur multi-feuilles."));
        sheetSelector.setMaxWidth(Double.MAX_VALUE);
        sheetSelector.setDisable(true);

        Label profileLabel = new Label("Format de sortie");
        profileLabel.setLabelFor(profileSelector);
        profileSelector.setMaxWidth(Double.MAX_VALUE);

        form.addRow(0, modeLabel, modeSelector, new Label());
        form.addRow(1, inputLabel, inputPathField, chooseInputButton);
        form.addRow(2, outputLabel, outputPathField, chooseOutputButton);
        form.addRow(3, sheetLabel, sheetSelector, sheetSpacer);
        form.addRow(4, profileLabel, profileSelector, new Label());

        HBox actions = new HBox(12, runButton);
        actions.setAlignment(Pos.CENTER_RIGHT);

        VBox card = new VBox(14, sectionTitle, form, actions);
        card.getStyleClass().add("card");
        return card;
    }

    private VBox createProgressCard() {
        progressBar.setMaxWidth(Double.MAX_VALUE);
        progressBar.setProgress(INDETERMINATE_PROGRESS);
        progressBar.setTooltip(new Tooltip("Le traitement s'exécute en arrière-plan."));
        progressLabel.getStyleClass().add("progress-label");
        progressLabel.setWrapText(true);

        VBox card = new VBox(10, progressLabel, progressBar);
        card.getStyleClass().add("card");
        return card;
    }

    private VBox createReportCard() {
        Label sectionTitle = new Label("Rapport de traitement");
        sectionTitle.getStyleClass().add("section-title");

        reportArea.setEditable(false);
        reportArea.setWrapText(false);
        reportArea.setPromptText("Le rapport complet et la liste des erreurs s'afficheront ici.");
        reportArea.setPrefHeight(180);
        reportArea.getStyleClass().add("report-area");
        VBox.setVgrow(reportArea, Priority.ALWAYS);

        sendMailButton.setTooltip(new Tooltip(
                "Prépare le message dans le client de messagerie du poste, ou l'envoie directement "
                        + "via Gmail (classeur de sortie et rapport en pièces jointes, fichier "
                        + "mail.properties requis)."
        ));

        HBox titleRow = new HBox(12, sectionTitle, sendMailButton, openOutputButton);
        titleRow.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(sectionTitle, Priority.ALWAYS);

        VBox card = new VBox(10, titleRow, reportArea);
        card.getStyleClass().add("card");
        card.setMinHeight(160);
        return card;
    }

    private void configureActions() {
        modeSelector.setOnAction(event -> applyMode());
        chooseInputButton.setOnAction(event -> chooseInput());
        chooseOutputButton.setOnAction(event -> chooseOutput());
        runButton.getStyleClass().addAll("button", "primary-button");
        openOutputButton.getStyleClass().addAll("button", "secondary-button");
        openOutputButton.setDisable(true);
        openOutputButton.setOnAction(event -> openOutput());
        sendMailButton.getStyleClass().addAll("button", "secondary-button");
        sendMailButton.setDisable(true);
        sendMailButton.setOnAction(event -> startMail());
        runButton.setOnAction(event -> startEtl());
    }

    private TreatmentMode selectedMode() {
        TreatmentMode mode = modeSelector.getValue();
        return mode == null ? TreatmentMode.FICHIER_UNIQUE : mode;
    }

    /**
     * Aligne les champs sur le mode choisi : un dossier en mode lot, un classeur sinon.
     */
    private void applyMode() {
        TreatmentMode mode = selectedMode();
        boolean single = mode == TreatmentMode.FICHIER_UNIQUE;

        inputLabel.setText(single ? "Fichier source" : "Dossier des sources");
        inputPathField.setPromptText(mode.prompt());
        setRowVisible(single, sheetLabel, sheetSelector, sheetSpacer);

        if (lastMode != mode) {
            if (single) {
                profileSelector.setValue(profileBeforeBatch);
            } else {
                profileBeforeBatch = selectedProfile();
                profileSelector.setValue(OutputProfile.VIVO);
            }
            lastMode = mode;
            inputPathField.clear();
            outputPathField.clear();
            resetLastResult();
        }
        profileSelector.setDisable(false);
        profileSelector.setTooltip(new Tooltip(single ? SINGLE_PROFILE_TOOLTIP : BATCH_PROFILE_TOOLTIP));

        sheetSelector.getItems().clear();
        sheetSelector.setValue(null);
        sheetSelector.setDisable(true);
        progressLabel.setText(single
                ? "Prêt à traiter un fichier Excel."
                : "Prêt à fusionner tous les classeurs d'un dossier.");
    }

    /**
     * Oublie le dernier resultat exploitable : les actions portant sur la sortie et l'envoi
     * ne sont plus proposees tant qu'un nouveau traitement n'a pas abouti.
     */
    private void resetLastResult() {
        lastOutputPath = null;
        lastAttachments = List.of();
        lastMailSubject = null;
        lastMailBody = null;
        openOutputButton.setDisable(true);
        sendMailButton.setDisable(true);
    }

    private void setRowVisible(boolean visible, Node... nodes) {
        for (Node node : nodes) {
            node.setVisible(visible);
            node.setManaged(visible);
        }
    }

    private void chooseInput() {
        if (selectedMode() == TreatmentMode.DOSSIER) {
            chooseInputDirectory();
        } else {
            chooseInputFile();
        }
    }

    private void chooseInputFile() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Sélectionner le fichier Excel source");
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Classeurs Excel (*.xlsx)", "*.xlsx")
        );
        chooser.setInitialDirectory(resolveInitialDirectory(inputPathField.getText()).toFile());

        File selectedFile = chooser.showOpenDialog(owner);
        if (selectedFile == null) {
            return;
        }

        Path selected = selectedFile.toPath().toAbsolutePath().normalize();
        inputPathField.setText(selected.toString());
        if (outputPathField.getText() == null || outputPathField.getText().isBlank()) {
            outputPathField.setText(defaultOutputPath(selected).toString());
        }
        loadSheetNames(selected);
        progressLabel.setText("Fichier source sélectionné.");
    }

    private void chooseInputDirectory() {
        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("Sélectionner le dossier des classeurs source");
        Path initialDirectory = resolveInitialDirectory(inputPathField.getText());
        if (Files.isDirectory(initialDirectory)) {
            chooser.setInitialDirectory(initialDirectory.toFile());
        }

        File selectedDirectory = chooser.showDialog(owner);
        if (selectedDirectory == null) {
            return;
        }

        Path directory = selectedDirectory.toPath().toAbsolutePath().normalize();
        inputPathField.setText(directory.toString());
        outputPathField.setText(defaultOutputPath(directory).toString());
        sheetSelector.getItems().clear();
        sheetSelector.setValue(null);
        sheetSelector.setDisable(true);
        progressLabel.setText("Dossier sélectionné : " + directory.getFileName()
                + " (tous les .xlsx seront fusionnés).");
    }

    private void loadSheetNames(Path source) {
        List<String> names;
        try {
            names = sheetLister.listSheetNames(source);
        } catch (IOException | RuntimeException exception) {
            sheetSelector.getItems().clear();
            sheetSelector.setValue(null);
            sheetSelector.setPromptText("Feuilles illisibles");
            sheetSelector.setDisable(true);
            return;
        }

        String previous = sheetSelector.getValue();
        sheetSelector.getItems().setAll(names);
        if (previous != null && names.contains(previous)) {
            sheetSelector.setValue(previous);
        } else if (!names.isEmpty()) {
            sheetSelector.setValue(names.get(0));
        }
        sheetSelector.setPromptText(names.isEmpty() ? "Aucune feuille" : "Choisissez la feuille à traiter");
        sheetSelector.setDisable(names.size() <= 1);
    }

    private void chooseOutput() {
        ButtonType existingChoice = new ButtonType("Sélectionner un classeur existant", ButtonBar.ButtonData.YES);
        ButtonType newChoice = new ButtonType("Créer un nouveau classeur", ButtonBar.ButtonData.NO);
        Alert destination = new Alert(Alert.AlertType.CONFIRMATION);
        destination.initOwner(owner);
        destination.setTitle("Choisir le classeur de sortie");
        destination.setHeaderText("Comment veux-tu enregistrer les résultats ?");
        destination.setContentText("Pour ajouter les résultats à ton suivi, sélectionne le classeur existant. "
                + "Pour créer une nouvelle sortie, choisis un nouveau classeur.");
        destination.getButtonTypes().setAll(existingChoice, newChoice, ButtonType.CANCEL);
        Optional<ButtonType> destinationChoice = destination.showAndWait();
        if (destinationChoice.isEmpty() || destinationChoice.get() == ButtonType.CANCEL) return;

        FileChooser chooser = new FileChooser();
        boolean selectExisting = destinationChoice.get() == existingChoice;
        chooser.setTitle(selectExisting ? "Sélectionner le classeur de suivi existant"
                : "Enregistrer un nouveau classeur de sortie");
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Classeurs Excel (*.xlsx)", "*.xlsx")
        );
        chooser.setInitialDirectory(resolveInitialDirectory(outputPathField.getText()).toFile());

        File selectedFile;
        if (selectExisting) {
            selectedFile = chooser.showOpenDialog(owner);
        } else {
            chooser.setInitialFileName(defaultOutputFileName());
            selectedFile = chooser.showSaveDialog(owner);
        }
        if (selectedFile == null) {
            return;
        }

        Path selected = selectedFile.toPath().toAbsolutePath().normalize();
        outputPathField.setText(selected.toString());
    }

    private String defaultOutputFileName() {
        if (selectedMode() == TreatmentMode.DOSSIER) {
            return "resultat" + selectedProfile().fileSuffix();
        }
        return "flotte" + selectedProfile().fileSuffix();
    }

    private void startEtl() {
        TreatmentMode mode = selectedMode();
        boolean single = mode == TreatmentMode.FICHIER_UNIQUE;
        Path input;
        Path output;
        try {
            input = readRequiredPath(inputPathField, "source");
            output = readRequiredPath(outputPathField, "sortie");
        } catch (IllegalArgumentException exception) {
            showError("Sélection invalide", exception.getMessage());
            return;
        }

        if (single) {
            if (!Files.isRegularFile(input)) {
                showError("Fichier source introuvable",
                        "Le fichier source n'existe pas ou n'est pas un fichier :\n" + input);
                return;
            }
            if (input.equals(output)) {
                showError("Choix invalide", "Le fichier de sortie doit être différent du fichier source.");
                return;
            }
        } else if (!Files.isDirectory(input)) {
            showError("Dossier source introuvable",
                    "Le dossier source n'existe pas ou n'est pas un dossier :\n" + input);
            return;
        }

        if (Files.exists(output) && Files.isDirectory(output)) {
            showError("Choix invalide", "Le chemin de sortie désigne un dossier :\n" + output);
            return;
        }
        boolean append = false;
        if (Files.exists(output)) {
            ButtonType appendChoice = new ButtonType("Ajouter à l’historique", ButtonBar.ButtonData.YES);
            ButtonType replaceChoice = new ButtonType("Remplacer", ButtonBar.ButtonData.NO);
            Alert choice = new Alert(Alert.AlertType.CONFIRMATION);
            choice.initOwner(owner);
            choice.setTitle("Fichier de sortie existant");
            choice.setHeaderText("Que faire avec le classeur de suivi ?");
            choice.setContentText("L’ajout garde les onglets et lignes déjà présents, puis ajoute les résultats dans l’onglet "
                    + selectedProfile().sheetName() + ".\n" + output);
            choice.getButtonTypes().setAll(appendChoice, replaceChoice, ButtonType.CANCEL);
            Optional<ButtonType> selected = choice.showAndWait();
            if (selected.isEmpty() || selected.get() == ButtonType.CANCEL) return;
            append = selected.get() == appendChoice;
        }

        if (single && sheetSelector.getItems().isEmpty()) {
            loadSheetNames(input);
        }

        Task<?> task = single ? createSingleTask(input, output, append) : createBatchTask(input, output, append);
        setBusy(true);
        progressBar.progressProperty().bind(task.progressProperty());
        progressLabel.textProperty().bind(task.messageProperty());
        task.setOnSucceeded(event -> onTaskSucceeded(task));
        task.setOnFailed(event -> onTaskFailed(task.getException()));
        task.setOnCancelled(event -> onTaskCancelled());

        Thread worker = new Thread(task, "etl-background-worker");
        worker.setDaemon(true);
        worker.start();
    }

    private Task<EtlResult> createSingleTask(Path source, Path output, boolean append) {
        OutputProfile profile = selectedProfile();
        String sheetName = sheetSelector.getValue();
        return new Task<>() {
            @Override
            protected EtlResult call() throws Exception {
                return etlService.execute(
                        source, output, DuplicatePolicy.KEEP_ALL, profile, sheetName, this::publishProgress, append
                );
            }

            private void publishProgress(EtlProgress progress) {
                updateProgress(progress.progress(), 1.0);
                updateMessage(progress.message());
            }
        };
    }

    private Task<BatchResult> createBatchTask(Path directory, Path output, boolean append) {
        OutputProfile profile = selectedProfile();
        return new Task<>() {
            @Override
            protected BatchResult call() throws Exception {
                return batchService.execute(
                        directory, output, DuplicatePolicy.KEEP_ALL, this::publishProgress, profile, append
                );
            }

            private void publishProgress(EtlProgress progress) {
                updateProgress(progress.progress(), 1.0);
                updateMessage(progress.message());
            }
        };
    }

    private OutputProfile selectedProfile() {
        OutputProfile profile = profileSelector.getValue();
        return OutputProfile.orDefault(profile);
    }

    private void onTaskSucceeded(Task<?> task) {
        unbindProgress();
        setBusy(false);
        Object value = task.getValue();
        lastMailSubject = null;
        lastMailBody = null;
        lastAttachments = List.of();
        if (value instanceof EtlResult result) {
            lastOutputPath = result.outputPath();
            lastAttachments = attachmentsOf(result.outputPath(), result.reportPath());
            lastMailSubject = MailComposer.defaultSubject(result);
            lastMailBody = MailComposer.defaultBody(result);
            reportArea.setText(EtlReportFormatter.format(result.sourcePath(), result));
            progressLabel.setText(String.format(
                    Locale.FRANCE,
                    "Terminé : %d ligne(s) chargée(s), %d erreur(s), %d doublon(s).",
                    result.loadedRows(), result.errors(), result.duplicates()
            ));
        } else if (value instanceof BatchResult result) {
            lastOutputPath = result.outputPath();
            lastAttachments = attachmentsOf(result.outputPath(), result.reportPath());
            lastMailSubject = MailComposer.defaultSubject(result);
            lastMailBody = MailComposer.defaultBody(result);
            reportArea.setText(BatchReportFormatter.format(result));
            progressLabel.setText(String.format(
                    Locale.FRANCE,
                    "Lot terminé : %d classeur(s) fusionné(s), %d ligne(s) ajoutée(s), %d erreur(s).",
                    result.mergedFiles(), result.appendedRows(), result.errors()
            ));
        }
        openOutputButton.setDisable(lastOutputPath == null);
        sendMailButton.setDisable(lastMailSubject == null);
    }

    private void onTaskFailed(Throwable throwable) {
        unbindProgress();
        setBusy(false);
        String message = throwable == null || throwable.getMessage() == null || throwable.getMessage().isBlank()
                ? "Une erreur inattendue est survenue."
                : throwable.getMessage();
        reportArea.setText(message);
        progressLabel.setText("Le traitement n'a pas pu aboutir.");
        showError("Erreur de traitement", message);
    }

    private void onTaskCancelled() {
        unbindProgress();
        setBusy(false);
        progressLabel.setText("Traitement annulé.");
    }

    private void unbindProgress() {
        progressBar.progressProperty().unbind();
        progressLabel.textProperty().unbind();
    }

    private void setBusy(boolean busy) {
        inputPathField.setDisable(busy);
        outputPathField.setDisable(busy);
        chooseInputButton.setDisable(busy);
        chooseOutputButton.setDisable(busy);
        runButton.setDisable(busy);
        modeSelector.setDisable(busy);
        boolean single = selectedMode() == TreatmentMode.FICHIER_UNIQUE;
        profileSelector.setDisable(busy);
        if (!busy && !sheetSelector.getItems().isEmpty()) {
            sheetSelector.setDisable(sheetSelector.getItems().size() <= 1);
        } else {
            sheetSelector.setDisable(busy || !single || sheetSelector.getItems().size() <= 1);
        }
        if (busy) {
            openOutputButton.setDisable(true);
            if (!progressBar.progressProperty().isBound()) {
                progressBar.setProgress(INDETERMINATE_PROGRESS);
            }
        }
    }

    /**
     * Ouvre la boîte de préparation, puis selon le bouton choisi : envoi direct par API
     * via {@link MailService} avec le classeur et le rapport en pièces jointes, ou ouverture
     * du client de messagerie via {@code mailto:} avec les champs pré-remplis.
     */
    private void startMail() {
        if (lastMailSubject == null) {
            showError("Aucun traitement à envoyer",
                    "Lancez d'abord un traitement : son résultat pourra ensuite être préparé dans "
                            + "le client de messagerie.");
            return;
        }

        Optional<MailSendDialog.MailSendChoice> choice = MailSendDialog.show(
                owner,
                defaultMailRecipient,
                lastMailSubject,
                lastMailBody
        );
        if (choice.isEmpty()) {
            return;
        }
        MailMessage message = new MailMessage(
                choice.get().message().recipients(),
                choice.get().message().subject(),
                MailComposer.compose(choice.get().message().body(), lastMailBody)
        );
        if (choice.get().sendDirectly()) {
            sendDirectly(message);
            return;
        }

        try {
            String url = MailLauncher.open(message);
            progressLabel.setText("Message préparé dans votre client de messagerie.");
        } catch (MailException exception) {
            showError("Client de messagerie indisponible", exception.getMessage());
            progressLabel.setText("Message non ouvert dans le client de messagerie.");
        }
    }

    /**
     * Pièces jointes d'un envoi direct : le classeur de sortie, plus le rapport texte
     * lorsqu'il a bien été écrit à côté.
     */
    private List<Path> attachmentsOf(Path output, Path report) {
        List<Path> attachments = new ArrayList<>();
        attachments.add(output);
        if (report != null && Files.isRegularFile(report)) {
            attachments.add(report);
        }
        return List.copyOf(attachments);
    }

    /**
     * Envoie le message en tâche de fond : le SMTP peut bloquer quelques secondes et ne
     * doit pas geler l'interface. Un échec d'envoi n'affecte jamais le traitement ETL déjà
     * terminé, il est signalé dans une boîte dédiée.
     */
    private void sendDirectly(MailMessage message) {
        List<Path> attachments = lastAttachments;
        sendMailButton.setDisable(true);
        runButton.setDisable(true);
        progressLabel.setText("Envoi de l'email…");
        Task<Void> task = new Task<>() {
            @Override
            protected Void call() {
                mailService.send(message, attachments);
                return null;
            }
        };
        task.setOnSucceeded(event -> onMailSucceeded(message));
        task.setOnFailed(event -> onMailFailed(task.getException()));
        Thread worker = new Thread(task, "mail-smtp-worker");
        worker.setDaemon(true);
        worker.start();
    }

    private void onMailSucceeded(MailMessage message) {
        restoreAfterMail();
        progressLabel.setText("Email envoyé à " + message.recipientsAsText() + ".");
        Alert confirmation = new Alert(Alert.AlertType.INFORMATION);
        confirmation.initOwner(owner);
        confirmation.setTitle("Email envoyé");
        confirmation.setHeaderText("Email envoyé");
        confirmation.setContentText("L'email a été transmis à :\n" + message.recipientsAsText());
        confirmation.showAndWait();
    }

    private void onMailFailed(Throwable throwable) {
        restoreAfterMail();
        String message = throwable == null || throwable.getMessage() == null
                || throwable.getMessage().isBlank()
                ? "L'envoi de l'email a échoué pour une raison inconnue."
                : throwable.getMessage();
        progressLabel.setText("Email non envoyé : le traitement ETL reste valide.");
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(owner);
        alert.setTitle("Erreur d'envoi d'email");
        alert.setHeaderText("Erreur d'envoi d'email");
        alert.setContentText(message
                + "\n\nLe traitement ETL est terminé : le classeur de sortie et le rapport "
                + "ont bien été produits et restent accessibles.");
        alert.showAndWait();
    }

    private void restoreAfterMail() {
        sendMailButton.setDisable(lastMailSubject == null);
        runButton.setDisable(false);
    }

    private void openOutput() {
        if (lastOutputPath == null) {
            return;
        }
        try {
            if (!Files.isRegularFile(lastOutputPath)) {
                throw new IOException("Le fichier de sortie est introuvable : " + lastOutputPath);
            }
            if (!Desktop.isDesktopSupported()) {
                throw new IOException("L'ouverture automatique n'est pas prise en charge par ce système.");
            }
            Desktop.getDesktop().open(lastOutputPath.toFile());
        } catch (IOException | RuntimeException exception) {
            showError(
                    "Ouverture impossible",
                    "Le fichier n'a pas pu être ouvert. Utilisez le chemin indiqué dans le rapport.\n"
                            + lastOutputPath
            );
        }
    }

    private Path readRequiredPath(TextField field, String label) {
        String value = field.getText();
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Sélectionnez un chemin de " + label + ".");
        }
        try {
            return Paths.get(value).toAbsolutePath().normalize();
        } catch (InvalidPathException exception) {
            throw new IllegalArgumentException("Le chemin de " + label + " n'est pas valide.");
        }
    }

    private Path resolveInitialDirectory(String currentPath) {
        if (currentPath != null && !currentPath.isBlank()) {
            try {
                Path path = Paths.get(currentPath).toAbsolutePath().normalize();
                if (Files.isDirectory(path)) {
                    return path;
                }
                if (path.getParent() != null && Files.isDirectory(path.getParent())) {
                    return path.getParent();
                }
            } catch (InvalidPathException ignored) {
                // Le dossier utilisateur reste une valeur de repli sûre.
            }
        }
        return Paths.get(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
    }

    private Path defaultOutputPath(Path source) {
        if (selectedMode() == TreatmentMode.DOSSIER) {
            Path parent = source.getParent();
            Path target = parent == null ? source : parent;
            return target.resolve("resultat" + selectedProfile().fileSuffix());
        }
        String fileName = source.getFileName() == null ? "chauffeurs" : source.getFileName().toString();
        int extension = fileName.toLowerCase(Locale.FRANCE).lastIndexOf(".xlsx");
        String baseName = extension > 0 ? fileName.substring(0, extension) : fileName;
        Path parent = source.getParent() == null ? Paths.get(".").toAbsolutePath().normalize() : source.getParent();
        return parent.resolve(baseName + selectedProfile().fileSuffix());
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
