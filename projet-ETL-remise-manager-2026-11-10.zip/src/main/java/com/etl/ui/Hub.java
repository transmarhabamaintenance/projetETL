package com.etl.ui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

/**
 * Point d'entrée JavaFX de la suite ETL : ouvre l'écran lanceur.
 */
public class Hub extends Application {

    public static final String TITLE = "Suite ETL";

    @Override
    public void start(Stage stage) {
        URL stylesheet = HubView.class.getResource("application.css");
        if (stylesheet == null) {
            throw new IllegalStateException("La feuille de style application.css est introuvable");
        }
        Scene scene = new Scene(new HubView(), 720, 460);
        scene.getStylesheets().add(stylesheet.toExternalForm());
        stage.setTitle(TITLE);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
}