package com.etl.service;

import com.etl.batch.BatchFileResult;
import com.etl.batch.BatchResult;
import com.etl.model.ValidationError;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Produit le rapport texte decrivant l'execution par lot : quel classeur a ete ajoute, dans
 * quel ordre, et pourquoi un classeur a pu etre ecarte.
 */
public final class BatchReportFormatter {

    private static final String SEPARATOR = "-".repeat(78);
    private static final DateTimeFormatter STAMP =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", Locale.FRANCE);

    private BatchReportFormatter() {
    }

    public static String format(BatchResult result) {
        StringBuilder report = new StringBuilder();
        report.append(SEPARATOR).append('\n')
                .append("RAPPORT DE TRAITEMENT PAR LOT\n")
                .append("Exécuté le ").append(STAMP.format(LocalDateTime.now())).append('\n')
                .append(SEPARATOR).append('\n')
                .append("Dossier d'entrée    : ").append(result.inputDirectory()).append('\n')
                .append("Classeur fusionné  : ").append(result.outputPath()).append('\n')
                .append("Rapport            : ").append(result.reportPath()).append('\n')
                .append("Feuille            : une seule feuille, un seul en-tête\n")
                .append("Ordre des lignes   : ordre alphabétique des fichiers du dossier\n")
                .append("Date et heure      : horodatage du traitement, propre à chaque fichier\n")
                .append("Feuille lue        : première feuille de chaque classeur\n")
                .append("Doublons           : toutes les occurrences sont conservées\n")
                .append('\n')
                .append("Classeurs trouvés  : ").append(result.filesFound())
                .append("   fusionnés : ").append(result.mergedFiles())
                .append("   ignorés : ").append(result.skippedFiles())
                .append("   en échec : ").append(result.failedFiles()).append('\n')
                .append("Lignes ajoutées     : ").append(result.appendedRows()).append('\n')
                .append("Erreurs de validation : ").append(result.errors()).append('\n')
                .append("Doublons             : ").append(result.duplicates()).append('\n')
                .append(String.format(Locale.FRANCE, "Durée totale       : %,d ms (%.3f s)%n",
                        result.durationMillis(), result.durationMillis() / 1000.0))
                .append(SEPARATOR).append('\n');

        int index = 1;
        for (BatchFileResult file : result.files()) {
            report.append(index++).append(". ").append(file.fileName()).append('\n');
            appendStatus(report, file);
            if (file.errors() > 0) {
                appendErrors(report, file);
            }
        }

        report.append(SEPARATOR).append('\n')
                .append("Chaque classeur traité a été ajouté au classeur unique, à la suite du ")
                .append("précédent\n")
                .append("et dans l'ordre alphabétique du dossier. Aucun fichier source n'a été ")
                .append("modifié.\n");
        return report.toString();
    }

    private static void appendStatus(StringBuilder report, BatchFileResult file) {
        report.append("   ");
        switch (file.status()) {
            case MERGED -> report.append("Fusionné")
                    .append(" : ").append(file.appendedRows()).append(" ligne(s) ajoutée(s)")
                    .append(", ").append(file.duplicates()).append(" doublon(s)")
                    .append(", ").append(file.errors()).append(" erreur(s)\n");
            case FAILED -> report.append("Échec")
                    .append(" : ").append(file.appendedRows()).append(" ligne(s) ajoutée(s) avant l'erreur")
                    .append('\n').append("      Motif : ").append(file.message()).append('\n');
            case SKIPPED -> report.append("Ignoré")
                    .append('\n').append("      Motif : ").append(file.message()).append('\n');
        }
    }

    private static void appendErrors(StringBuilder report, BatchFileResult file) {
        report.append("      Erreurs de validation :\n");
        for (ValidationError error : file.validationErrors()) {
            report.append("        Ligne ").append(error.rowIndex())
                    .append(" | Colonne : ").append(error.column())
                    .append(" | Valeur : \"").append(safe(error.value()))
                    .append("\" | ").append(error.description()).append('\n');
        }
        if (file.validationErrors().size() < file.errors()) {
            report.append("        … ").append(file.errors() - file.validationErrors().size())
                    .append(" erreur(s) supplémentaire(s) non détaillée(s) (protection mémoire).\n");
        }
    }

    private static String safe(String value) {
        return value.replace('\r', ' ').replace('\n', ' ');
    }
}
