
package com.etl.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class AppendResultWriter {

    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.FRANCE);

    private AppendResultWriter() {
    }

    public static void append(Path target, String content) throws IOException {
        if (target == null || content == null || content.isBlank()) {
            return;
        }
        Path normalized = target.toAbsolutePath().normalize();
        Path parent = normalized.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
        String block = "========================================\n" + TIMESTAMP_FORMATTER.format(LocalDateTime.now()) + "\n" + "========================================\n" + content + "\n\n";
        Files.writeString(normalized, block, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND, StandardOpenOption.WRITE);
    }
}
