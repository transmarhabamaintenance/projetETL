package com.etl.service;

import com.etl.EtlException;
import com.etl.model.DuplicateRecord;
import com.etl.model.EtlResult;
import com.etl.model.ValidationError;

import java.nio.file.Path;
import java.util.Locale;

/**
 * Produit un rapport texte UTF-8 detailing l'intégralité du traitement.
 */
public final class EtlReportFormatter {

    private EtlReportFormatter() {
    }

    public static String format(Path source, EtlResult result) {
        StringBuilder report = new StringBuilder();
        report.append("RAPPORT ETL - DONNÉES DE FLOTTE\n")
                .append("================================\n\n")
                .append("Fichier source : ").append(source.toAbsolutePath().normalize()).append('\n')
                .append("Fichier de sortie : ").append(result.outputPath()).append('\n')
                .append("Rapport : ").append(result.reportPath()).append("\n\n")
                .append("STATISTIQUES\n")
                .append("-------------\n")
                .append("Lignes extraites : ").append(result.extractedRows()).append('\n')
                .append("Lignes transformées : ").append(result.transformedRows()).append('\n')
                .append("Doublons détectés : ").append(result.duplicates()).append('\n')
                .append("Erreurs de validation : ").append(result.errors()).append('\n')
                .append("Lignes chargées : ").append(result.loadedRows()).append('\n')
                .append(String.format(Locale.FRANCE, "Durée : %,d ms (%.3f s)%n",
                        result.durationMillis(), result.durationMillis() / 1000.0))
                .append('\n')
                .append("DOUBLONS\n")
                .append("--------\n");

        if (result.duplicateRecords().isEmpty()) {
            report.append("Aucun doublon détecté.\n");
        } else {
            report.append("Politique appliquée : la première occurrence valide est conservée.\n");
            for (DuplicateRecord duplicate : result.duplicateRecords()) {
                report.append("Ligne ").append(duplicate.rowIndex())
                        .append(" | Numéro de flotte : ").append(duplicate.chauffeur().getNumeroFlotte())
                        .append(" | Chauffeur : ").append(duplicate.chauffeur().getChauffeurNom())
                        .append(" | Occurrence dupliquée exclue\n");
            }
            if (result.duplicateRecords().size() < result.duplicates()) {
                report.append("… ").append(result.duplicates() - result.duplicateRecords().size())
                        .append(" doublon(s) supplémentaire(s) non détaillé(s) (protection mémoire).\n");
            }
        }

        report.append("\nERREURS DE VALIDATION\n")
                .append("---------------------\n");
        if (result.validationErrors().isEmpty()) {
            report.append("Aucune erreur de validation.\n");
        } else {
            for (ValidationError error : result.validationErrors()) {
                report.append("Ligne ").append(error.rowIndex())
                        .append(" | Colonne : ").append(error.column())
                        .append(" | Valeur : \"").append(safe(error.value()))
                        .append("\" | ").append(error.description()).append('\n');
            }
            if (result.validationErrors().size() < result.errors()) {
                report.append("… ").append(result.errors() - result.validationErrors().size())
                        .append(" erreur(s) supplémentaire(s) non détaillée(s) (protection mémoire).\n");
            }
        }

        return report.toString();
    }

    private static String safe(String value) {
        return value.replace('\r', ' ').replace('\n', ' ');
    }
}
