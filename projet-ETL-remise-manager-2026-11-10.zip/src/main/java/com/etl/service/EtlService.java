package com.etl.service;

import com.etl.EtlException;
import com.etl.extract.ExcelExtractor;
import com.etl.load.ExcelLoader;
import com.etl.load.OutputProfile;
import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;
import com.etl.model.DuplicateRecord;
import com.etl.model.EtlProgress;
import com.etl.model.EtlResult;
import com.etl.model.ValidationError;
import com.etl.transform.ChauffeurTransformer;
import com.etl.validation.ChauffeurValidator;
import com.etl.validation.DuplicatePolicy;
import com.etl.validation.ValidationResult;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Orchestre le flux EXTRACT, TRANSFORM, VALIDATE et LOAD.
 */
public class EtlService {

    /**
     * Nombre maximal d'erreurs et de doublons conserves pour le rapport. Les compteurs
     * restent exacts au-dela de cette limite afin de ne pas saturer la memoire.
     */
    private static final int MAX_REPORTED_DETAILS = 5_000;

    private final ExcelExtractor extractor;
    private final ChauffeurTransformer transformer;
    private final ChauffeurValidator validator;
    private final ExcelLoader loader;
    private final EtlReportWriter reportWriter;

    public EtlService() {
        this(new ExcelExtractor(), new ChauffeurTransformer(), new ChauffeurValidator(),
                new ExcelLoader(), new EtlReportWriter());
    }

    public EtlService(ExcelExtractor extractor, ChauffeurTransformer transformer,
                     ChauffeurValidator validator, ExcelLoader loader,
                     EtlReportWriter reportWriter) {
        this.extractor = Objects.requireNonNull(extractor, "L'extracteur est obligatoire");
        this.transformer = Objects.requireNonNull(transformer, "Le transformateur est obligatoire");
        this.validator = Objects.requireNonNull(validator, "Le validateur est obligatoire");
        this.loader = Objects.requireNonNull(loader, "Le chargeur est obligatoire");
        this.reportWriter = Objects.requireNonNull(reportWriter, "Le générateur de rapport est obligatoire");
    }

    public EtlResult execute(Path source, Path output) throws IOException {
        return execute(source, output, DuplicatePolicy.KEEP_FIRST, progress -> { });
    }

    public EtlResult execute(Path source, Path output,
                             Consumer<EtlProgress> progressListener) throws IOException {
        return execute(source, output, DuplicatePolicy.KEEP_FIRST, progressListener);
    }

    public EtlResult execute(Path source, Path output, DuplicatePolicy duplicatePolicy) throws IOException {
        return execute(source, output, duplicatePolicy, progress -> { });
    }

    public EtlResult execute(Path source, Path output, DuplicatePolicy duplicatePolicy,
                             Consumer<EtlProgress> progressListener) throws IOException {
        return execute(source, output, duplicatePolicy, null, progressListener);
    }

    public EtlResult execute(Path source, Path output, DuplicatePolicy duplicatePolicy,
                             String sheetName, Consumer<EtlProgress> progressListener) throws IOException {
        return execute(source, output, duplicatePolicy, OutputProfile.NETTOYAGE, sheetName, progressListener);
    }

    public EtlResult execute(Path source, Path output, DuplicatePolicy duplicatePolicy,
                             OutputProfile profile) throws IOException {
        return execute(source, output, duplicatePolicy, profile, null, progress -> { });
    }

    public EtlResult execute(Path source, Path output, DuplicatePolicy duplicatePolicy,
                             OutputProfile profile, String sheetName,
                             Consumer<EtlProgress> progressListener) throws IOException {
        return execute(source, output, duplicatePolicy, profile, sheetName, progressListener, false);
    }

    public EtlResult execute(Path source, Path output, DuplicatePolicy duplicatePolicy,
                             OutputProfile profile, String sheetName,
                             Consumer<EtlProgress> progressListener, boolean append) throws IOException {
        Objects.requireNonNull(source, "Le fichier source est obligatoire");
        Objects.requireNonNull(output, "Le fichier de sortie est obligatoire");
        Consumer<EtlProgress> listener = progressListener == null ? progress -> { } : progressListener;
        OutputProfile effectiveProfile = OutputProfile.orDefault(profile);
        Path normalizedSource = source.toAbsolutePath().normalize();
        Path normalizedOutput = output.toAbsolutePath().normalize();
        if (normalizedSource.equals(normalizedOutput)) {
            throw new EtlException("Le fichier de sortie doit être différent du fichier source.");
        }

        long start = System.nanoTime();
        Path reportPath = buildReportPath(normalizedOutput);

        if (requiresStreaming(normalizedSource) && !append && effectiveProfile != OutputProfile.TOTAL) {
            return executeStreaming(normalizedSource, normalizedOutput, duplicatePolicy, effectiveProfile,
                    sheetName, listener, reportPath, start);
        }

        listener.accept(new EtlProgress(
                EtlProgress.Stage.EXTRACTION, 0, 1, 0.02,
                "Lecture du classeur Excel..."
        ));
        List<ChauffeurRecord> extracted = extractor.extract(normalizedSource, sheetName);
        List<String> outputFields = extractor.presentFields(normalizedSource, sheetName);
        listener.accept(new EtlProgress(
                EtlProgress.Stage.EXTRACTION, extracted.size(), extracted.size(), 0.15,
                "Extraction terminée : " + extracted.size() + " ligne(s)."
        ));

        List<ChauffeurRecord> transformed = new ArrayList<>(extracted.size());
        for (int index = 0; index < extracted.size(); index++) {
            ChauffeurRecord sourceRecord = extracted.get(index);
            transformed.add(new ChauffeurRecord(
                    sourceRecord.rowIndex(),
                    transformer.transform(sourceRecord.chauffeur()),
                    sourceRecord.extractionErrors(),
                    sourceRecord.extraColumns()
            ));
            publishRowProgress(listener, EtlProgress.Stage.TRANSFORMATION,
                    index + 1, extracted.size(), 0.15, 0.45,
                    "Nettoyage et normalisation des données...");
        }

        listener.accept(new EtlProgress(
                EtlProgress.Stage.VALIDATION, 0, transformed.size(), 0.48,
                "Validation des champs et détection des doublons..."
        ));
        ValidationResult validation = validator.validate(transformed, duplicatePolicy);
        listener.accept(new EtlProgress(
                EtlProgress.Stage.VALIDATION, transformed.size(), transformed.size(), 0.70,
                "Validation terminée."
        ));

        listener.accept(new EtlProgress(
                EtlProgress.Stage.LOADING, 0, validation.validRecords().size(), 0.74,
                "Création du classeur de sortie..."
        ));
        Path writtenOutput = loader.load(
                normalizedSource,
                normalizedOutput,
                validation.validRecords(),
                outputFields,
                effectiveProfile,
                append
        );
        listener.accept(new EtlProgress(
                EtlProgress.Stage.LOADING,
                validation.validRecords().size(),
                validation.validRecords().size(),
                0.90,
                "Classeur de sortie créé."
        ));

        long coreDuration = elapsedMillis(start);
        EtlResult reportData = new EtlResult(
                extracted.size(),
                transformed.size(),
                validation.duplicates().size(),
                validation.errors().size(),
                validation.validRecords().size(),
                normalizedSource,
                writtenOutput,
                reportPath,
                coreDuration,
                validation.errors(),
                validation.duplicates()
        );

        listener.accept(new EtlProgress(
                EtlProgress.Stage.REPORTING, 0, 1, 0.94,
                "Génération du rapport..."
        ));
        reportWriter.write(reportPath, normalizedSource, reportData);
        long totalDuration = elapsedMillis(start);
        EtlResult result = new EtlResult(
                reportData.extractedRows(),
                reportData.transformedRows(),
                reportData.duplicates(),
                reportData.errors(),
                reportData.loadedRows(),
                reportData.sourcePath(),
                reportData.outputPath(),
                reportData.reportPath(),
                totalDuration,
                reportData.validationErrors(),
                reportData.duplicateRecords()
        );
        listener.accept(new EtlProgress(
                EtlProgress.Stage.COMPLETED, result.extractedRows(), result.extractedRows(), 1.0,
                "Traitement terminé."
        ));
        return result;
    }

    private boolean requiresStreaming(Path source) {
        try {
            return Files.size(source) > ExcelExtractor.STREAMING_THRESHOLD_BYTES;
        } catch (IOException exception) {
            return false;
        }
    }

    /**
     * Pipeline fusionne pour les classeurs volumineux : lecture SAX, transformation,
     * validation et ecriture SXSSF ligne par ligne, sans liste intermediaire en memoire.
     */
    private EtlResult executeStreaming(Path source, Path output, DuplicatePolicy duplicatePolicy,
                                       OutputProfile profile, String sheetName,
                                       Consumer<EtlProgress> listener,
                                       Path reportPath, long start) throws IOException {
        DuplicatePolicy effectivePolicy = duplicatePolicy == null
                ? DuplicatePolicy.KEEP_FIRST : duplicatePolicy;
        StreamingCounters counters = new StreamingCounters();
        Set<String> knownDrivers = effectivePolicy == DuplicatePolicy.KEEP_ALL
                ? null : new HashSet<>();

        listener.accept(new EtlProgress(
                EtlProgress.Stage.EXTRACTION, 0, 1, 0.02,
                "Lecture du classeur Excel (traitement en flux)..."
        ));

        try (ExcelLoader.StreamingWriter writer = loader.openStream(source, output, profile)) {
            extractor.stream(
                    source,
                    sheetName,
                    new ExcelExtractor.StreamListener() {
                        @Override
                        public void onHeader(List<String> presentFields, List<String> extraLabels) {
                            writer.onHeader(presentFields, extraLabels);
                        }

                        @Override
                        public void onProgress(long dataRows, long bytesRead, long totalBytes) {
                            listener.accept(new EtlProgress(
                                    EtlProgress.Stage.EXTRACTION,
                                    (int) Math.min(Integer.MAX_VALUE, dataRows),
                                    (int) Math.min(Integer.MAX_VALUE, Math.max(dataRows, 1L)),
                                    0.02 + 0.80 * fraction(bytesRead, totalBytes),
                                    "Lecture, nettoyage et validation : " + dataRows + " ligne(s) traitée(s)."
                            ));
                        }
                    },
                    (rowIndex, chauffeur, extractionErrors, extraColumns) -> {
                        counters.extracted++;
                        Chauffeur transformed = transformer.transform(chauffeur);
                        counters.transformed++;

                        List<ValidationError> rowErrors =
                                validator.validateRow(rowIndex, transformed, extractionErrors);
                        if (!rowErrors.isEmpty()) {
                            counters.addErrors(rowErrors);
                            return;
                        }
                        if (knownDrivers != null
                                && validator.hasCompleteIdentity(transformed)
                                && !knownDrivers.add(validator.duplicateKey(transformed))) {
                            counters.addDuplicate(new DuplicateRecord(rowIndex, transformed));
                            return;
                        }
                        try {
                            writer.append(transformed, extraColumns);
                            counters.loaded++;
                        } catch (IOException exception) {
                            throw new UncheckedIOException(exception);
                        }
                    }
            );

            listener.accept(new EtlProgress(
                    EtlProgress.Stage.LOADING, counters.loaded, Math.max(counters.loaded, 1), 0.88,
                    "Finalisation du classeur de sortie..."
            ));
            writer.commit();
        }

        EtlResult reportData = new EtlResult(
                counters.extracted,
                counters.transformed,
                counters.duplicateCount,
                counters.errorCount,
                counters.loaded,
                source,
                output,
                reportPath,
                elapsedMillis(start),
                counters.errors,
                counters.duplicates
        );

        listener.accept(new EtlProgress(
                EtlProgress.Stage.REPORTING, 0, 1, 0.94,
                "Génération du rapport..."
        ));
        reportWriter.write(reportPath, source, reportData);
        EtlResult result = new EtlResult(
                reportData.extractedRows(),
                reportData.transformedRows(),
                reportData.duplicates(),
                reportData.errors(),
                reportData.loadedRows(),
                reportData.sourcePath(),
                reportData.outputPath(),
                reportData.reportPath(),
                elapsedMillis(start),
                reportData.validationErrors(),
                reportData.duplicateRecords()
        );
        listener.accept(new EtlProgress(
                EtlProgress.Stage.COMPLETED, result.extractedRows(), result.extractedRows(), 1.0,
                "Traitement terminé."
        ));
        return result;
    }

    private double fraction(long bytesRead, long totalBytes) {
        if (totalBytes <= 0) {
            return 1.0;
        }
        return Math.max(0.0, Math.min(1.0, bytesRead / (double) totalBytes));
    }

    private static final class StreamingCounters {

        private int extracted;
        private int transformed;
        private int loaded;
        private int errorCount;
        private int duplicateCount;
        private final List<ValidationError> errors = new ArrayList<>();
        private final List<DuplicateRecord> duplicates = new ArrayList<>();

        void addErrors(List<ValidationError> rowErrors) {
            errorCount += rowErrors.size();
            if (errors.size() < MAX_REPORTED_DETAILS) {
                errors.addAll(rowErrors);
            }
        }

        void addDuplicate(DuplicateRecord duplicate) {
            duplicateCount++;
            if (duplicates.size() < MAX_REPORTED_DETAILS) {
                duplicates.add(duplicate);
            }
        }
    }

    private void publishRowProgress(Consumer<EtlProgress> listener, EtlProgress.Stage stage,
                                    int processed, int total, double startProgress,
                                    double endProgress, String message) {
        double fraction = total == 0 ? 1.0 : processed / (double) total;
        double progress = startProgress + (endProgress - startProgress) * fraction;
        listener.accept(new EtlProgress(stage, processed, total, progress, message));
    }

    private long elapsedMillis(long startNanos) {
        return TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNanos);
    }

    private Path buildReportPath(Path output) {
        String fileName = output.getFileName().toString();
        int extensionIndex = fileName.toLowerCase(Locale.FRANCE).lastIndexOf(".xlsx");
        String baseName = extensionIndex > 0 ? fileName.substring(0, extensionIndex) : fileName;
        return output.resolveSibling(baseName + "_rapport.txt");
    }
}
