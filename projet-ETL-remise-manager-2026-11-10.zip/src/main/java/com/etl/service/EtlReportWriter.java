package com.etl.service;

import com.etl.EtlException;
import com.etl.model.EtlResult;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Écrit le rapport d'exécution à côté du fichier de sortie.
 */
public class EtlReportWriter {

    public Path write(Path reportPath, Path source, EtlResult result) throws IOException {
        if (reportPath == null || result == null || source == null) {
            throw new EtlException("Les informations du rapport sont incomplètes.");
        }

        Path normalized = reportPath.toAbsolutePath().normalize();
        Path parent = normalized.getParent();
        if (parent == null || !Files.isDirectory(parent)) {
            throw new EtlException("Le dossier du rapport n'existe pas : " + parent);
        }
        if (!Files.isWritable(parent)) {
            throw new EtlException("Le dossier du rapport n'est pas accessible en écriture : " + parent);
        }

        String report = "========================================\n"
                + "Exécution : " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                + "\n========================================\n"
                + EtlReportFormatter.format(source, result) + "\n\n";
        try {
            Files.writeString(
                    normalized,
                    report,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND,
                    StandardOpenOption.WRITE
            );
            return normalized;
        } catch (IOException exception) {
            throw new EtlException("Impossible d'écrire le rapport du traitement.", exception);
        }
    }
}
