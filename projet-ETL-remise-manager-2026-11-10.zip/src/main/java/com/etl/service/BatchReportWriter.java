package com.etl.service;

import com.etl.EtlException;
import com.etl.batch.BatchResult;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Ecrit le rapport de lot a cote du classeur fusionne.
 */
public class BatchReportWriter {

    public Path write(BatchResult result) throws IOException {
        if (result == null) {
            throw new EtlException("Les informations du rapport sont incomplètes.");
        }

        Path normalized = result.reportPath();
        Path parent = normalized.getParent();
        if (parent == null || !Files.isDirectory(parent)) {
            throw new EtlException("Le dossier du rapport n'existe pas : " + parent);
        }
        if (!Files.isWritable(parent)) {
            throw new EtlException("Le dossier du rapport n'est pas accessible en écriture : " + parent);
        }

        String report = BatchReportFormatter.format(result);
        try {
            Files.writeString(
                    normalized,
                    report,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE
            );
            return normalized;
        } catch (IOException exception) {
            throw new EtlException("Impossible d'écrire le rapport du traitement.", exception);
        }
    }
}
