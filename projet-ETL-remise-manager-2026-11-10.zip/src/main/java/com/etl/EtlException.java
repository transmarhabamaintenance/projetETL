package com.etl;

import java.io.IOException;

/**
 * Erreur métier destinée à être affichée telle quelle à l'utilisateur.
 */
public class EtlException extends IOException {

    public EtlException(String message) {
        super(message);
    }

    public EtlException(String message, Throwable cause) {
        super(message, cause);
    }
}
