package com.etl.load;

/**
 * Gabarit du classeur produit par l'application.
 */
public enum OutputProfile {

    /** Colonnes metier reconnues dans la source, dans l'ordre canonique. */
    NETTOYAGE("Nettoyage (colonnes de la source)", "Chauffeurs nettoyés", "_clean.xlsx"),

    /**
     * Gabarit de suivi demande par le manager : quatorze colonnes, independantes des libelles
     * et de l'ordre de la source. Les colonnes que l'export ne permet pas de remplir sont
     * renseignees avec la valeur neutre {@code RAS}, et une vitesse mesuree au-dela du seuil
     * accepte par la societe est ramenee au plafond du gabarit, la mesure d'origine restant
     * consultable dans l'onglet d'audit du meme classeur.
     */
    RAPPORT_MANAGER("Rapport manager (14 colonnes)", "Rapport manager", "_rapport_manager.xlsx"),
    VIVO("Suivi VIVO", "VIVO", "_VIVO.xlsx"),
    TOTAL("Suivi TOTAL (tableau horaire)", "TOTAL", "_TOTAL.xlsx");

    private final String label;
    private final String sheetName;
    private final String fileSuffix;

    OutputProfile(String label, String sheetName, String fileSuffix) {
        this.label = label;
        this.sheetName = sheetName;
        this.fileSuffix = fileSuffix;
    }

    public String label() {
        return label;
    }

    public String sheetName() {
        return sheetName;
    }

    /**
     * Suffixe propose pour le nom du fichier de sortie.
     */
    public String fileSuffix() {
        return fileSuffix;
    }

    public static OutputProfile orDefault(OutputProfile profile) {
        return profile == null ? NETTOYAGE : profile;
    }

    @Override
    public String toString() {
        return label;
    }
}
