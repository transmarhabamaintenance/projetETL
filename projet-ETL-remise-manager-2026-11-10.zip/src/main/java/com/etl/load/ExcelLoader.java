package com.etl.load;

import com.etl.EtlException;
import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;
import com.etl.model.ExtraColumn;
import com.etl.transform.ManagerReportFormatter;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.Normalizer;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Génère un nouveau classeur propre par écriture temporaire puis remplacement atomique.
 */
public class ExcelLoader {

    private static final Map<String, String> LABELS = Map.ofEntries(
            Map.entry("statutMobile", "Statut mobile"),
            Map.entry("description", "Description"),
            Map.entry("inscription", "Inscription"),
            Map.entry("numeroFlotte", "Numéro de flotte"),
            Map.entry("site", "Site"),
            Map.entry("chauffeurNom", "Chauffeur"),
            Map.entry("emplacement", "Emplacement"),
            Map.entry("dernierEvenement", "Dernier événement"),
            Map.entry("valeurDernierEvenement", "Valeur dernier événement"),
            Map.entry("vitesse", "Vitesse (km/h)")
    );

    private static final String[] FIELD_ORDER = {
            "statutMobile", "description", "inscription", "numeroFlotte", "site",
            "chauffeurNom", "emplacement", "dernierEvenement", "valeurDernierEvenement", "vitesse"
    };

    /** Onglet listant les vitesses mesurees qui ont ete ramenees au plafond du gabarit. */
    private static final String SPEED_AUDIT_SHEET = "Vitesses normalisées";

    private final ManagerReportFormatter managerReport = new ManagerReportFormatter();

    public Path load(Path source, Path output, List<ChauffeurRecord> records,
                     List<String> fields) throws IOException {
        return load(source, output, records, fields, OutputProfile.NETTOYAGE);
    }

    public Path load(Path source, Path output, List<ChauffeurRecord> records,
                     List<String> fields, OutputProfile profile) throws IOException {
        return load(source, output, records, fields, profile, false);
    }

    public Path load(Path source, Path output, List<ChauffeurRecord> records,
                     List<String> fields, OutputProfile profile, boolean append) throws IOException {
        Path normalizedSource = validatePath(source, "source");
        Path normalizedOutput = validateOutput(output);
        ensureDifferentFiles(normalizedSource, normalizedOutput);
        validateRecords(records);
        OutputProfile effectiveProfile = OutputProfile.orDefault(profile);

        Path parent = normalizedOutput.getParent();
        Path temporaryFile = null;
        boolean preservingExistingWorkbook = append && Files.isRegularFile(normalizedOutput);
        try {
            temporaryFile = Files.createTempFile(parent, "etl-", ".xlsx.tmp");
            try (XSSFWorkbook workbook = preservingExistingWorkbook
                    ? openWorkbook(normalizedOutput) : new XSSFWorkbook()) {
                Sheet sheet = workbook.getSheet(effectiveProfile.sheetName());
                if (sheet == null) sheet = workbook.createSheet(effectiveProfile.sheetName());
                Styles styles = createStyles(workbook);
                int startRow = append && sheet.getPhysicalNumberOfRows() > 0 ? sheet.getLastRowNum() + 1 : 0;
                int columnCount = writeBody(sheet, records, fields, styles, effectiveProfile, startRow);

                if (!preservingExistingWorkbook) {
                    sheet.createFreezePane(0, 1);
                    sheet.setAutoFilter(new CellRangeAddress(
                            0, Math.max(0, sheet.getLastRowNum()), 0, Math.max(0, columnCount - 1)
                    ));
                    for (int column = 0; column < columnCount; column++) {
                        sheet.setColumnWidth(column, 30 * 256);
                    }
                }

                try (OutputStream outputStream = Files.newOutputStream(
                        temporaryFile,
                        StandardOpenOption.TRUNCATE_EXISTING,
                        StandardOpenOption.WRITE
                )) {
                    workbook.write(outputStream);
                }
            }

            moveIntoPlace(temporaryFile, normalizedOutput);
            temporaryFile = null;
            return normalizedOutput;
        } catch (EtlException exception) {
            throw exception;
        } catch (IOException exception) {
            throw new EtlException(
                    "Impossible de créer le fichier de sortie. Vérifiez les permissions et l'espace disque disponible.",
                    exception
            );
        } finally {
            deleteTemporaryFile(temporaryFile);
        }
    }

    private static XSSFWorkbook openWorkbook(Path path) throws IOException {
        try (InputStream input = Files.newInputStream(path)) { return new XSSFWorkbook(input); }
    }

    /**
     * Ecrit l'en-tete puis les lignes selon le gabarit demande et retourne le nombre de
     * colonnes produites.
     */
    private int writeBody(Sheet sheet, List<ChauffeurRecord> records, List<String> fields,
                          Styles styles, OutputProfile profile, int startRow) {
        if (profile == OutputProfile.TOTAL) {
            return writeTotalBody(sheet, records, styles, startRow);
        }
        if (profile == OutputProfile.RAPPORT_MANAGER || profile == OutputProfile.VIVO) {
            return writeManagerBody(sheet, records, styles, startRow);
        }

        List<String> outputFields = resolveFields(fields);
        Map<String, Integer> outputIndex = outputIndexOf(outputFields);
        if (startRow == 0) writeHeaderRow(sheet, outputFields, outputIndex, styles.headerStyle());

        List<ExtraColumn> labels = records.isEmpty() ? List.of() : records.get(0).extraColumns();
        for (int index = 0; index < records.size(); index++) {
            ChauffeurRecord record = records.get(index);
            writeRecord(
                    sheet.createRow(startRow + index + (startRow == 0 ? 1 : 0)), record.chauffeur(),
                    outputIndex, styles.dataStyle(), record.extraColumns()
            );
        }
        if (startRow == 0) appendExtraHeaders(sheet, labels, outputFields.size(), styles.headerStyle());
        return outputFields.size() + labels.size();
    }

    /**
     * Gabarit manager : les quatorze colonnes sont fixes et independantes des libelles de la
     * source. L'instant du releve est fige une seule fois pour que toutes les lignes portent
     * la meme date et la meme heure.
     */
    private int writeManagerBody(Sheet sheet, List<ChauffeurRecord> records, Styles styles, int startRow) {
        List<String> headers = managerReport.headers();
        if (startRow == 0) {
            Row header = sheet.createRow(0);
            for (int index = 0; index < headers.size(); index++) {
                Cell cell = header.createCell(index);
                cell.setCellValue(headers.get(index));
                cell.setCellStyle(styles.headerStyle());
            }
        }

        LocalDateTime instant = LocalDateTime.now();
        SpeedAudit audit = new SpeedAudit(sheet.getWorkbook(), styles);
        for (int index = 0; index < records.size(); index++) {
            Chauffeur chauffeur = records.get(index).chauffeur();
            ManagerReportFormatter.Line line = managerReport.line(chauffeur, instant);
            int rowNumber = startRow + index + (startRow == 0 ? 1 : 0);
            writeManagerRow(sheet.createRow(rowNumber), line.values(), styles.dataStyle());
            audit.append(rowNumber + 1, chauffeur, line.speedCap());
        }
        return headers.size();
    }

    /**
     * Ajoute les relevés au tableau horaire TOTAL. Les colonnes horaires viennent du
     * classeur déjà présent ; les champs que LiveTracking ne fournit pas restent vides.
     */
    private int writeTotalBody(Sheet sheet, List<ChauffeurRecord> records, Styles styles, int startRow) {
        Row header = sheet.getRow(0);
        if (header == null) {
            header = sheet.createRow(0);
            String[] defaults = {"DATE", "Code camion", "N°tracteur", "N°de remorque", "Nom chauffeur",
                    "Disponibilité camion", "Motif de non disponibilité du camion", "09:00", "10:00",
                    "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"};
            for (int column = 0; column < defaults.length; column++) {
                Cell cell = header.createCell(column);
                cell.setCellValue(defaults[column]);
                cell.setCellStyle(styles.headerStyle());
            }
        }

        Map<String, Integer> columns = new LinkedHashMap<>();
        Map<Integer, LocalTime> timeColumns = new LinkedHashMap<>();
        for (Cell cell : header) {
            String label = Normalizer.normalize(cell.toString().trim().toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "");
            if (label.startsWith("date")) columns.put("date", cell.getColumnIndex());
            else if (label.contains("code camion")) columns.put("code", cell.getColumnIndex());
            else if (label.contains("tracteur") && !label.contains("remorque")) columns.put("tractor", cell.getColumnIndex());
            else if (label.contains("remorque")) columns.put("trailer", cell.getColumnIndex());
            else if (label.contains("chauffeur")) columns.put("driver", cell.getColumnIndex());
            else if (label.contains("disponibilite") && !label.contains("motif")) columns.put("availability", cell.getColumnIndex());
            else if (label.contains("motif")) columns.put("reason", cell.getColumnIndex());
            else if (parseTime(cell) != null) timeColumns.put(cell.getColumnIndex(), parseTime(cell));
        }
        int maxColumn = Math.max(header.getLastCellNum(), 0);
        if (timeColumns.isEmpty()) {
            throw new IllegalArgumentException("L'onglet TOTAL ne contient aucune colonne horaire reconnue.");
        }

        LocalDateTime now = LocalDateTime.now();
        LocalTime targetTime = now.toLocalTime();
        int locationColumn = timeColumns.keySet().stream()
                .min((left, right) -> Long.compare(
                        Math.abs(java.time.Duration.between(timeColumns.get(left), targetTime).toMinutes()),
                        Math.abs(java.time.Duration.between(timeColumns.get(right), targetTime).toMinutes())))
                .orElseThrow();
        int rowNumber = Math.max(1, startRow);
        for (ChauffeurRecord record : records) {
            Chauffeur chauffeur = record.chauffeur();
            Row row = sheet.createRow(rowNumber++);
            writeTotalCell(row, columns.get("date"), now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")), styles.dataStyle());
            writeTotalCell(row, columns.get("code"), chauffeur.getDescription(), styles.dataStyle());
            writeTotalCell(row, columns.get("tractor"), chauffeur.getInscription(), styles.dataStyle());
            writeTotalCell(row, columns.get("trailer"), "", styles.dataStyle());
            writeTotalCell(row, columns.get("driver"), chauffeur.getChauffeurNom(), styles.dataStyle());
            writeTotalCell(row, columns.get("availability"), "", styles.dataStyle());
            writeTotalCell(row, columns.get("reason"), "", styles.dataStyle());
            writeTotalCell(row, locationColumn, chauffeur.getEmplacement(), styles.dataStyle());
        }
        return maxColumn;
    }

    private static void writeTotalCell(Row row, Integer column, String value, CellStyle style) {
        if (column == null || value == null || value.isBlank()) return;
        Cell cell = row.createCell(column);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }

    private static LocalTime parseTime(String label) {
        if (label == null) return null;
        String value = label.trim().replace('.', ':');
        try {
            return LocalTime.parse(value, DateTimeFormatter.ofPattern("H:mm"));
        } catch (java.time.format.DateTimeParseException ignored) {
            try { return LocalTime.parse(value, DateTimeFormatter.ofPattern("HH:mm")); }
            catch (java.time.format.DateTimeParseException ignoredAgain) { return null; }
        }
    }

    private static LocalTime parseTime(Cell cell) {
        if (cell == null) return null;
        if (cell.getCellType() == org.apache.poi.ss.usermodel.CellType.NUMERIC) {
            double fraction = cell.getNumericCellValue() % 1.0;
            int minutes = (int) Math.round(fraction * 24 * 60);
            return LocalTime.MIDNIGHT.plusMinutes(minutes % (24 * 60));
        }
        return parseTime(cell.toString());
    }

    private void writeManagerRow(Row row, List<String> values, CellStyle dataStyle) {
        for (int column = 0; column < values.size(); column++) {
            if (column == ManagerReportFormatter.SPEED_COLUMN_INDEX) {
                writeSpeed(row, column, values.get(column), dataStyle);
            } else {
                writeText(row, column, values.get(column), dataStyle);
            }
        }
    }

    /**
     * Onglet d'audit des vitesses ramenées au plafond accepté par la société. Le rapport reste
     * conforme au gabarit, mais chaque valeur normalisée reste consultable avec la ligne du
     * rapport concernée : la transformation n'est donc jamais silencieuse.
     */
    private final class SpeedAudit {

        private static final String[] AUDIT_HEADERS = {
                "Ligne du rapport", "Matricule camion", "Nom du Chauffeur",
                "Vitesse mesurée", "Vitesse appliquée", "Seuil"
        };

        private final Workbook workbook;
        private final CellStyle dataStyle;
        private final CellStyle headerStyle;
        private Sheet sheet;
        private int nextRow;

        SpeedAudit(Workbook workbook, Styles styles) {
            this.workbook = workbook;
            this.dataStyle = styles.dataStyle();
            this.headerStyle = styles.headerStyle();
            this.sheet = workbook.getSheet(SPEED_AUDIT_SHEET);
            if (this.sheet != null) this.nextRow = Math.max(1, this.sheet.getLastRowNum() + 1);
        }

        void append(int reportRow, Chauffeur chauffeur, ManagerReportFormatter.SpeedCap cap) {
            if (cap == null) {
                return;
            }
            if (sheet == null) {
                sheet = createSheet();
            }
            Row row = sheet.createRow(nextRow++);
            writeText(row, 0, String.valueOf(reportRow), dataStyle);
            writeText(row, 1, chauffeur.getNumeroFlotte(), dataStyle);
            writeText(row, 2, chauffeur.getChauffeurNom(), dataStyle);
            writeText(row, 3, cap.original(), dataStyle);
            writeText(row, 4, cap.applied(), dataStyle);
            writeText(row, 5, String.valueOf((long) ManagerReportFormatter.SEUIL_VITESSE), dataStyle);
        }

        private Sheet createSheet() {
            Sheet created = workbook.getSheet(SPEED_AUDIT_SHEET);
            if (created != null) return created;
            created = workbook.createSheet(SPEED_AUDIT_SHEET);
            Row header = created.createRow(0);
            for (int index = 0; index < AUDIT_HEADERS.length; index++) {
                Cell cell = header.createCell(index);
                cell.setCellValue(AUDIT_HEADERS[index]);
                cell.setCellStyle(headerStyle);
            }
            for (int column = 0; column < AUDIT_HEADERS.length; column++) {
                created.setColumnWidth(column, 22 * 256);
            }
            created.createFreezePane(0, 1);
            nextRow = 1;
            return created;
        }
    }

    /**
     * Ne conserve que les champs reconnus dans la source, dans l'ordre canonique.
     */
    private List<String> resolveFields(List<String> fields) {
        if (fields == null || fields.isEmpty()) {
            return List.of(FIELD_ORDER);
        }
        List<String> resolved = new ArrayList<>();
        for (String field : FIELD_ORDER) {
            if (fields.contains(field)) {
                resolved.add(field);
            }
        }
        return resolved.isEmpty() ? List.of(FIELD_ORDER) : List.copyOf(resolved);
    }

    private Map<String, Integer> outputIndexOf(List<String> fields) {
        Map<String, Integer> outputIndex = new LinkedHashMap<>();
        for (int index = 0; index < fields.size(); index++) {
            outputIndex.put(fields.get(index), index);
        }
        return outputIndex;
    }

    private Path validatePath(Path source, String label) throws EtlException {
        if (source == null) {
            throw new EtlException("Le chemin " + label + " est obligatoire.");
        }
        return source.toAbsolutePath().normalize();
    }

    private Path validateOutput(Path output) throws EtlException {
        Path normalized = validatePath(output, "de sortie");
        String fileName = normalized.getFileName() == null ? "" : normalized.getFileName().toString();
        if (!fileName.toLowerCase(Locale.FRANCE).endsWith(".xlsx")) {
            throw new EtlException("Le fichier de sortie doit être au format .xlsx.");
        }
        if (Files.exists(normalized) && Files.isDirectory(normalized)) {
            throw new EtlException("Le chemin de sortie désigne un dossier : " + normalized);
        }
        if (Files.exists(normalized)) {
            try {
                if (!Files.isWritable(normalized)) {
                    throw new EtlException("Le fichier de sortie n'est pas modifiable : " + normalized);
                }
            } catch (SecurityException exception) {
                throw new EtlException("Les permissions du fichier de sortie sont insuffisantes.", exception);
            }
        }

        Path parent = normalized.getParent();
        if (parent == null || !Files.exists(parent)) {
            throw new EtlException("Le dossier de destination n'existe pas : " + parent);
        }
        if (!Files.isDirectory(parent)) {
            throw new EtlException("Le chemin de destination n'est pas un dossier : " + parent);
        }
        if (!Files.isWritable(parent)) {
            throw new EtlException("Le dossier de destination n'est pas accessible en écriture : " + parent);
        }
        return normalized;
    }

    private void ensureDifferentFiles(Path source, Path output) throws EtlException {
        if (source.equals(output)) {
            throw new EtlException("Le fichier de sortie doit être différent du fichier source.");
        }
        if (Files.exists(source) && Files.exists(output)) {
            try {
                if (Files.isSameFile(source, output)) {
                    throw new EtlException("Le fichier de sortie désigne le même fichier que le fichier source.");
                }
            } catch (IOException exception) {
                throw new EtlException("Impossible de comparer les fichiers source et destination.", exception);
            }
        }
    }

    private void validateRecords(List<ChauffeurRecord> records) throws EtlException {
        if (records == null) {
            throw new EtlException("La liste des données à charger est obligatoire.");
        }
        for (ChauffeurRecord record : records) {
            if (record == null) {
                throw new EtlException("La liste des données à charger contient une ligne invalide.");
            }
        }
    }

    private Styles createStyles(Workbook workbook) {
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);

        CellStyle dataStyle = workbook.createCellStyle();
        dataStyle.setWrapText(true);
        dataStyle.setVerticalAlignment(VerticalAlignment.TOP);
        return new Styles(headerStyle, dataStyle);
    }

    private void writeHeaderRow(Sheet sheet, List<String> fields, Map<String, Integer> outputIndex,
                               CellStyle headerStyle) {
        Row header = sheet.createRow(0);
        for (Map.Entry<String, Integer> entry : outputIndex.entrySet()) {
            Cell cell = header.createCell(entry.getValue());
            cell.setCellValue(LABELS.getOrDefault(entry.getKey(), entry.getKey()));
            cell.setCellStyle(headerStyle);
        }
    }

    private List<ExtraColumn> extraLabelColumns(List<String> labels) {
        List<ExtraColumn> columns = new ArrayList<>(labels.size());
        for (String label : labels) {
            columns.add(new ExtraColumn(label, ""));
        }
        return columns;
    }

    private void appendExtraHeaders(Sheet sheet, List<ExtraColumn> labels, int firstColumn,
                                    CellStyle headerStyle) {
        if (labels.isEmpty()) {
            return;
        }
        Row header = sheet.getRow(0);
        if (header == null) {
            return;
        }
        for (int index = 0; index < labels.size(); index++) {
            Cell cell = header.createCell(firstColumn + index);
            cell.setCellValue(labels.get(index).label());
            cell.setCellStyle(headerStyle);
        }
    }

    private void writeRecord(Row row, Chauffeur chauffeur, Map<String, Integer> outputIndex,
                             CellStyle dataStyle) {
        writeRecord(row, chauffeur, outputIndex, dataStyle, List.of());
    }

    private void writeRecord(Row row, Chauffeur chauffeur, Map<String, Integer> outputIndex,
                             CellStyle dataStyle, List<ExtraColumn> extraColumns) {
        for (Map.Entry<String, Integer> entry : outputIndex.entrySet()) {
            String field = entry.getKey();
            int column = entry.getValue();
            if ("vitesse".equals(field)) {
                writeSpeed(row, column, chauffeur.getVitesse(), dataStyle);
            } else {
                writeText(row, column, valueOf(chauffeur, field), dataStyle);
            }
        }
        int next = outputIndex.size();
        for (ExtraColumn extra : extraColumns) {
            writeText(row, next++, extra.value(), dataStyle);
        }
    }

    private String valueOf(Chauffeur chauffeur, String field) {
        return switch (field) {
            case "statutMobile" -> chauffeur.getStatutMobile();
            case "description" -> chauffeur.getDescription();
            case "inscription" -> chauffeur.getInscription();
            case "numeroFlotte" -> chauffeur.getNumeroFlotte();
            case "site" -> chauffeur.getSite();
            case "chauffeurNom" -> chauffeur.getChauffeurNom();
            case "emplacement" -> chauffeur.getEmplacement();
            case "dernierEvenement" -> chauffeur.getDernierEvenement();
            case "valeurDernierEvenement" -> chauffeur.getValeurDernierEvenement();
            case "vitesse" -> chauffeur.getVitesse();
            default -> "";
        };
    }

    private void writeSpeed(Row row, int column, String speed, CellStyle dataStyle) {
        Cell speedCell = row.createCell(column);
        speedCell.setCellStyle(dataStyle);
        String value = speed == null ? "" : speed;
        try {
            speedCell.setCellValue(new BigDecimal(value).doubleValue());
        } catch (NumberFormatException exception) {
            speedCell.setCellValue(value);
        }
    }

    private void writeText(Row row, int column, String value, CellStyle dataStyle) {
        Cell cell = row.createCell(column);
        cell.setCellValue(value == null ? "" : value);
        cell.setCellStyle(dataStyle);
    }

    private record Styles(CellStyle headerStyle, CellStyle dataStyle) {
    }

    private void moveIntoPlace(Path temporaryFile, Path output) throws IOException {
        try {
            Files.move(
                    temporaryFile,
                    output,
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING
            );
            return;
        } catch (AtomicMoveNotSupportedException exception) {
            // Le systeme de fichiers ne sait pas remplacer atomiquement : repli ci-dessous.
        } catch (IOException exception) {
            // Windows refuse le remplacement atomique lorsque la destination est ouverte
            // (classeur verrouille par Excel) : un remplacement simple peut encore aboutir.
        }

        try {
            Files.move(temporaryFile, output, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException exception) {
            throw new EtlException(
                    "Impossible de remplacer le fichier de sortie : " + output
                            + System.lineSeparator()
                            + "Fermez ce classeur s'il est ouvert dans Excel, puis relancez le traitement.",
                    exception
            );
        }
    }

    private void deleteTemporaryFile(Path temporaryFile) {
        if (temporaryFile == null) {
            return;
        }
        try {
            Files.deleteIfExists(temporaryFile);
        } catch (IOException ignored) {
            // Le fichier temporaire sera nettoyé par le système si nécessaire.
        }
    }

    /**
     * Ouvre un écrivain streaming (SXSSF) : seules quelques lignes sont conservées en
     * mémoire, ce qui permet d'exporter des classeurs source volumineux.
     */
    public StreamingWriter openStream(Path source, Path output) throws IOException {
        return openStream(source, output, OutputProfile.NETTOYAGE);
    }

    public StreamingWriter openStream(Path source, Path output, OutputProfile profile) throws IOException {
        Path normalizedSource = validatePath(source, "source");
        Path normalizedOutput = validateOutput(output);
        ensureDifferentFiles(normalizedSource, normalizedOutput);
        return new StreamingWriter(normalizedOutput, OutputProfile.orDefault(profile));
    }

    public final class StreamingWriter implements Closeable {

        private static final int ROW_WINDOW = 200;
        private static final int COLUMN_WIDTH = 30 * 256;

        private final Path output;
        private final SXSSFWorkbook workbook;
        private final Sheet sheet;
        private final Styles styles;
        private final OutputProfile profile;
        private LocalDateTime instant = LocalDateTime.now();
        private final SpeedAudit speedAudit;
        private Path temporaryFile;
        private int rowCount;
        private int columnCount;
        private boolean headerWritten;
        private List<String> outputFields = List.of();
        private Map<String, Integer> outputIndex = Map.of();

        private StreamingWriter(Path output, OutputProfile profile) throws IOException {
            this.output = output;
            this.profile = profile;
            this.temporaryFile = Files.createTempFile(output.getParent(), "etl-", ".xlsx.tmp");
            this.workbook = new SXSSFWorkbook(ROW_WINDOW);
            this.workbook.setCompressTempFiles(true);
            this.sheet = workbook.createSheet(profile.sheetName());
            this.styles = createStyles(workbook);
            this.speedAudit = new SpeedAudit(workbook, styles);
        }

        /**
         * Fige l'instant du releve inscrit dans les lignes suivantes. Un meme classeur de
         * sortie peut ainsi accumuler les resultats de plusieurs fichiers sources : chaque
         * fichier garde alors sa propre date et sa propre heure de traitement, sans que
         * l'en-tete ne soit reecrit.
         */
        public void startFile(LocalDateTime releveInstant) {
            if (releveInstant != null) {
                this.instant = releveInstant;
            }
        }

        /**
         * Ecrit la ligne d'en-tetes des que les champs reconnus dans la source sont connus,
         * ce qui permet de ne produire que les colonnes reellement presentes. Le gabarit
         * manager impose au contraire un en-tete fixe, independant de la source.
         */
        public void onHeader(List<String> fields, List<String> extraLabels) {
            if (headerWritten) {
                return;
            }
            if (profile == OutputProfile.RAPPORT_MANAGER || profile == OutputProfile.VIVO) {
                List<String> headers = managerReport.headers();
                Row header = sheet.createRow(0);
                for (int index = 0; index < headers.size(); index++) {
                    Cell cell = header.createCell(index);
                    cell.setCellValue(headers.get(index));
                    cell.setCellStyle(styles.headerStyle());
                }
                columnCount = headers.size();
            } else {
                outputFields = resolveFields(fields);
                List<String> labels = extraLabels == null ? List.of() : extraLabels;
                outputIndex = outputIndexOf(outputFields);
                writeHeaderRow(sheet, outputFields, outputIndex, styles.headerStyle());
                appendExtraHeaders(sheet, extraLabelColumns(labels), outputFields.size(),
                        styles.headerStyle());
                columnCount = outputFields.size() + labels.size();
            }
            for (int column = 0; column < columnCount; column++) {
                sheet.setColumnWidth(column, COLUMN_WIDTH);
            }
            headerWritten = true;
        }

        public void append(Chauffeur chauffeur) throws IOException {
            append(chauffeur, List.of());
        }

        public void append(Chauffeur chauffeur, List<ExtraColumn> extraColumns) throws IOException {
            if (chauffeur == null) {
                throw new EtlException("Une ligne à écrire ne peut pas être null.");
            }
            if (!headerWritten) {
                throw new EtlException("L'en-tête du classeur de sortie n'a pas été initialisé.");
            }
            try {
                Row row = sheet.createRow(rowCount + 1);
                if (profile == OutputProfile.RAPPORT_MANAGER || profile == OutputProfile.VIVO) {
                    ManagerReportFormatter.Line line = managerReport.line(chauffeur, instant);
                    writeManagerRow(row, line.values(), styles.dataStyle());
                    speedAudit.append(rowCount + 2, chauffeur, line.speedCap());
                } else {
                    writeRecord(row, chauffeur, outputIndex, styles.dataStyle(), extraColumns);
                }
                rowCount++;
            } catch (RuntimeException exception) {
                throw new IOException("Erreur lors de l'écriture d'une ligne du classeur de sortie.", exception);
            }
        }

        public int rowCount() {
            return rowCount;
        }

        public Path commit() throws IOException {
            if (rowCount == 0) {
                throw new EtlException("Aucune ligne valide n'a été écrite dans le fichier de sortie.");
            }
            sheet.createFreezePane(0, 1);
            sheet.setAutoFilter(new CellRangeAddress(0, rowCount, 0, Math.max(0, columnCount - 1)));

            try {
                try (OutputStream outputStream = Files.newOutputStream(
                        temporaryFile,
                        StandardOpenOption.TRUNCATE_EXISTING,
                        StandardOpenOption.WRITE
                )) {
                    workbook.write(outputStream);
                }
            } catch (IOException exception) {
                throw new EtlException(
                        "Impossible d'écrire le classeur de sortie. Vérifiez l'espace disque disponible.",
                        exception
                );
            } finally {
                workbook.dispose();
            }

            moveIntoPlace(temporaryFile, output);
            temporaryFile = null;
            return output;
        }

        @Override
        public void close() {
            try {
                workbook.dispose();
            } catch (RuntimeException ignored) {
                // Le fichier temporaire est de toute façon supprimé ci-dessous.
            }
            deleteTemporaryFile(temporaryFile);
            temporaryFile = null;
        }
    }
}
