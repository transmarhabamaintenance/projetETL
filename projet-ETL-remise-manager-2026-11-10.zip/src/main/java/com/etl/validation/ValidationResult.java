package com.etl.validation;

import com.etl.model.ChauffeurRecord;
import com.etl.model.DuplicateRecord;
import com.etl.model.ValidationError;

import java.util.List;
import java.util.Objects;

/**
 * Regroupe les lignes valides, les erreurs et les doublons détectés.
 */
public record ValidationResult(
        List<ChauffeurRecord> validRecords,
        List<ValidationError> errors,
        List<DuplicateRecord> duplicates
) {

    public ValidationResult {
        validRecords = List.copyOf(Objects.requireNonNull(validRecords, "La liste des lignes valides est obligatoire"));
        errors = List.copyOf(Objects.requireNonNull(errors, "La liste des erreurs est obligatoire"));
        duplicates = List.copyOf(Objects.requireNonNull(duplicates, "La liste des doublons est obligatoire"));
    }
}
