package com.etl.validation;

import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;
import com.etl.model.DuplicateRecord;
import com.etl.model.ValidationError;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Valide les champs métier et isole chaque erreur pour le rapport final.
 */
public class ChauffeurValidator {

    private static final String VITESSE = "vitesse";
    private static final Pattern SPEED_UNIT = Pattern.compile("(?i)\\s*(?:km\\s*/?h|kmh|kph)\\s*$");

    public ValidationResult validate(List<ChauffeurRecord> records) {
        return validate(records, DuplicatePolicy.KEEP_FIRST);
    }

    public ValidationResult validate(List<ChauffeurRecord> records, DuplicatePolicy policy) {
        if (records == null) {
            throw new IllegalArgumentException("La liste des enregistrements ne peut pas être null");
        }
        DuplicatePolicy effectivePolicy = policy == null ? DuplicatePolicy.KEEP_FIRST : policy;

        List<ChauffeurRecord> validRecords = new ArrayList<>();
        List<ValidationError> errors = new ArrayList<>();
        List<DuplicateRecord> duplicates = new ArrayList<>();
        Set<DriverIdentity> knownDrivers = new HashSet<>();

        for (ChauffeurRecord record : records) {
            if (record == null) {
                throw new IllegalArgumentException("Un enregistrement ne peut pas être null");
            }

            Chauffeur chauffeur = record.chauffeur();
            int rowIndex = record.rowIndex();
            List<ValidationError> rowErrors = new ArrayList<>(record.extractionErrors());
            rowErrors.addAll(validateFields(rowIndex, chauffeur));

            if (!rowErrors.isEmpty()) {
                errors.addAll(rowErrors);
                continue;
            }

            if (effectivePolicy == DuplicatePolicy.KEEP_ALL) {
                validRecords.add(record);
                continue;
            }

            if (!hasCompleteIdentity(chauffeur)) {
                validRecords.add(record);
                continue;
            }
            DriverIdentity identity = new DriverIdentity(
                    normalizeIdentity(chauffeur.getNumeroFlotte()),
                    normalizeIdentity(chauffeur.getChauffeurNom())
            );
            if (!knownDrivers.add(identity)) {
                duplicates.add(new DuplicateRecord(rowIndex, chauffeur));
            } else {
                validRecords.add(record);
            }
        }

        return new ValidationResult(validRecords, errors, duplicates);
    }

    /**
     * Valide une ligne unique et renvoie la liste de ses erreurs, ce qui permet un
     * traitement streaming sans conserver l'integralite des enregistrements.
     */
    public List<ValidationError> validateRow(int rowIndex, Chauffeur chauffeur,
                                             List<ValidationError> extractionErrors) {
        List<ValidationError> errors = new ArrayList<>();
        if (extractionErrors != null) {
            errors.addAll(extractionErrors);
        }
        errors.addAll(validateFields(rowIndex, chauffeur));
        return errors;
    }

    /**
     * Une ligne sans numero de flotte ou sans nom de chauffeur (valeur inconnue ou
     * absente) ne peut pas etre identifiee comme doublon : elle est toujours traitee.
     */
    public boolean hasCompleteIdentity(Chauffeur chauffeur) {
        if (chauffeur == null) {
            throw new IllegalArgumentException("Un chauffeur ne peut pas être null");
        }
        return !normalizeIdentity(chauffeur.getNumeroFlotte()).isEmpty()
                && !normalizeIdentity(chauffeur.getChauffeurNom()).isEmpty();
    }

    /**
     * Cle de detection des doublons : numero de flotte + nom du chauffeur normalises.
     */
    public String duplicateKey(Chauffeur chauffeur) {
        if (chauffeur == null) {
            throw new IllegalArgumentException("Un chauffeur ne peut pas être null");
        }
        return normalizeIdentity(chauffeur.getNumeroFlotte())
                + "\u0000"
                + normalizeIdentity(chauffeur.getChauffeurNom());
    }

    private List<ValidationError> validateFields(int rowIndex, Chauffeur chauffeur) {
        List<ValidationError> errors = new ArrayList<>();
        validateSpeed(rowIndex, chauffeur.getVitesse(), errors);
        return errors;
    }

    private void validateSpeed(int rowIndex, String value, List<ValidationError> errors) {
        if (value == null || value.isBlank()) {
            return;
        }

        String normalized = SPEED_UNIT.matcher(value).replaceFirst("").replace(',', '.').trim();
        try {
            BigDecimal speed = new BigDecimal(normalized);
            if (speed.signum() < 0) {
                errors.add(new ValidationError(
                        rowIndex, VITESSE, value, "La vitesse ne peut pas être négative"
                ));
            }
        } catch (NumberFormatException exception) {
            errors.add(new ValidationError(
                    rowIndex, VITESSE, value, "La vitesse doit être un nombre positif ou nul"
            ));
        }
    }

    private String normalizeIdentity(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.FRANCE);
    }

    private record DriverIdentity(String numeroFlotte, String chauffeurNom) {
    }
}
