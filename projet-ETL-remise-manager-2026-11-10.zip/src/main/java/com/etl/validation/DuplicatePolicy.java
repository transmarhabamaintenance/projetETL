package com.etl.validation;

/**
 * Définit comment traiter les lignes partageant la même identité (flotte + chauffeur).
 */
public enum DuplicatePolicy {

    /**
     * Conserve uniquement la première occurrence valide (comportement historique).
     */
    KEEP_FIRST,

    /**
     * Conserve toutes les occurrences, afin de ne pas écraser un suivi temporel (relevés périodiques).
     */
    KEEP_ALL
}
