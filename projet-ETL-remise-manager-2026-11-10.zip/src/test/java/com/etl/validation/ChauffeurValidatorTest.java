package com.etl.validation;

import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;
import com.etl.model.DuplicateRecord;
import com.etl.model.ValidationError;
import com.etl.transform.ChauffeurTransformer;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ChauffeurValidatorTest {

    private final ChauffeurValidator validator = new ChauffeurValidator();
    private final ChauffeurTransformer transformer = new ChauffeurTransformer();

    @Test
    void accepteLesChampsObligatoiresEtLaVitessePositif() {
        ValidationResult result = validator.validate(List.of(record(2, "F-100", "Alice Martin", "Paris", "12,5 km/h")));

        assertEquals(1, result.validRecords().size());
        assertEquals(0, result.errors().size());
        assertEquals(0, result.duplicates().size());
    }

    @Test
    void accepteUneLigneDontLesChampsSontVidesSansErreur() {
        Chauffeur chauffeur = new Chauffeur(
                "actif", "description", "date", "", "", "", "position", "événement", "valeur", ""
        );

        ValidationResult result = validator.validate(List.of(new ChauffeurRecord(3, chauffeur)));

        assertEquals(1, result.validRecords().size());
        assertEquals(0, result.errors().size());
        assertEquals(0, result.duplicates().size());
    }

    @Test
    void accepteLesValeursInconnuesSansErreurDeChampObligatoire() {
        Chauffeur chauffeur = transformer.transform(new Chauffeur(
                "actif", "description", "date", "Unknown", "Inconnu", "N/A",
                "position", "événement", "valeur", ""
        ));

        ValidationResult result = validator.validate(List.of(new ChauffeurRecord(4, chauffeur)));

        assertEquals("", chauffeur.getNumeroFlotte());
        assertEquals("", chauffeur.getSite());
        assertEquals("", chauffeur.getChauffeurNom());
        assertEquals(1, result.validRecords().size());
        assertEquals(0, result.errors().size());
    }

    @Test
    void neSignaleQueLaVitesseLorsqueLesAutresChampsSontVides() {
        Chauffeur chauffeur = new Chauffeur(
                "actif", "description", "date", "", "", "", "position", "événement", "valeur", "invalide"
        );

        ValidationResult result = validator.validate(List.of(new ChauffeurRecord(3, chauffeur)));

        assertEquals(0, result.validRecords().size());
        assertEquals(1, result.errors().size());
        assertTrue(result.errors().stream().allMatch(error -> error.column().equals("vitesse")));
    }

    @Test
    void neSignalePasDeDoublonSansIdentiteComplete() {
        Chauffeur first = record(2, "", "", "Paris", "10").chauffeur();
        Chauffeur second = record(3, "", "", "Lyon", "12").chauffeur();
        Chauffeur third = record(4, "F-100", "", "Lyon", "12").chauffeur();

        ValidationResult result = validator.validate(List.of(
                new ChauffeurRecord(2, first),
                new ChauffeurRecord(3, second),
                new ChauffeurRecord(4, third)
        ));

        assertEquals(3, result.validRecords().size());
        assertEquals(0, result.duplicates().size());
        assertEquals(0, result.errors().size());
    }

    @Test
    void detecteUnDoublonSansPerdreLaPremiereOccurrence() {
        Chauffeur first = record(2, "F-100", "Alice Martin", "Paris", "10").chauffeur();
        Chauffeur second = record(3, "f-100", "alice martin", "Lyon", "12").chauffeur();

        ValidationResult result = validator.validate(List.of(
                new ChauffeurRecord(2, first),
                new ChauffeurRecord(3, second)
        ));

        assertEquals(1, result.validRecords().size());
        assertEquals(first, result.validRecords().get(0).chauffeur());
        assertEquals(0, result.errors().size());
        assertEquals(1, result.duplicates().size());
        DuplicateRecord duplicate = result.duplicates().get(0);
        assertEquals(3, duplicate.rowIndex());
        assertEquals(second, duplicate.chauffeur());
    }

    @Test
    void valideUneLigneIsoleeEtAjouteLesErreursDExtraction() {
        Chauffeur chauffeur = record(9, "F-900", "Ali Bennani", "Casablanca", "").chauffeur();
        List<ValidationError> extractionErrors = List.of(new ValidationError(9, "vitesse", "#N/A", "cellule"));

        assertTrue(validator.validateRow(9, chauffeur, List.of()).isEmpty());

        List<ValidationError> errors = validator.validateRow(9, chauffeur, extractionErrors);

        assertEquals(1, errors.size());
        assertEquals(9, errors.get(0).rowIndex());
    }

    @Test
    void construitUneCleDeDoublonInsensibleALaCasseEtAuxEspacesDeBord() {
        Chauffeur first = new Chauffeur("", "", "", "  F-101 ", "Site", "Bob Durand", "", "", "", "");
        Chauffeur second = new Chauffeur("", "", "", "F-101", "Autre", "bob durand", "", "", "", "");
        Chauffeur other = new Chauffeur("", "", "", "F-102", "Site", "Bob Durand", "", "", "", "");

        assertEquals(validator.duplicateKey(first), validator.duplicateKey(second));
        assertNotEquals(validator.duplicateKey(first), validator.duplicateKey(other));
    }

    @Test
    void refuseUneVitesseContenantDesEspacesInternes() {        ValidationResult result = validator.validate(List.of(record(5, "F-102", "Claire Durand", "Nice", "1 2")));

        assertEquals(0, result.validRecords().size());
        assertEquals(1, result.errors().size());
        assertEquals("vitesse", result.errors().get(0).column());
    }

    @Test
    void refuseUneVitesseNegative() {
        ValidationResult result = validator.validate(List.of(record(4, "F-101", "Bob Durand", "Lille", "-1")));

        assertEquals(0, result.validRecords().size());
        assertEquals(1, result.errors().size());
        ValidationError error = result.errors().get(0);
        assertEquals("vitesse", error.column());
        assertTrue(error.description().contains("négative"));
    }

    private ChauffeurRecord record(int rowIndex, String fleet, String name,
                                   String site, String speed) {
        return new ChauffeurRecord(rowIndex, new Chauffeur(
                "actif", "description", "date", fleet, site, name,
                "position", "événement", "valeur", speed
        ));
    }
}
