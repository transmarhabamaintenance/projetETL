package com.etl.batch;

import com.etl.EtlException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BatchServiceTest {

    @Test
    void fusionnePlusieursClasseursDansUneSeuleFeuilleDansLOrdreDuDossier(@TempDir Path directory)
            throws IOException {
        createTelemetryWorkbook(directory.resolve("a.xlsx"),
                new String[]{"Moving", "111-D-40", "111-D-40", "DRIVER A", "Loc A1", "", "", "40"},
                new String[]{"Stationary", "222-D-40", "222-D-40", "DRIVER B", "Loc A2", "", "", "0"});
        createTelemetryWorkbook(directory.resolve("b.xlsx"),
                new String[]{"Moving", "111-D-40", "111-D-40", "DRIVER A", "Loc B1", "", "", "55"},
                new String[]{"Moving", "333-D-40", "333-D-40", "DRIVER C", "Loc B2", "", "", "70"});
        Path output = directory.resolve("resultat_rapport_manager.xlsx");

        BatchResult result = new BatchService().execute(directory, output);

        assertEquals(2, result.filesFound());
        assertEquals(2, result.mergedFiles());
        assertEquals(0, result.failedFiles());
        assertEquals(0, result.skippedFiles());
        assertEquals(4, result.appendedRows());
        assertEquals(output.toAbsolutePath().normalize(), result.outputPath());
        assertTrue(Files.isRegularFile(result.reportPath()));

        try (XSSFWorkbook workbook = new XSSFWorkbook(Files.newInputStream(output))) {
            assertEquals(1, workbook.getNumberOfSheets());
            Sheet sheet = workbook.getSheet("Rapport manager");
            assertNotNull(sheet);
            assertEquals(14, sheet.getRow(0).getLastCellNum());
            assertEquals(5, sheet.getPhysicalNumberOfRows());

            assertEquals("111-D-40", sheet.getRow(1).getCell(2).getStringCellValue());
            assertEquals("Loc A1", sheet.getRow(1).getCell(7).getStringCellValue());
            assertEquals("222-D-40", sheet.getRow(2).getCell(2).getStringCellValue());
            assertEquals("Loc A2", sheet.getRow(2).getCell(7).getStringCellValue());
            assertEquals("111-D-40", sheet.getRow(3).getCell(2).getStringCellValue());
            assertEquals("Loc B1", sheet.getRow(3).getCell(7).getStringCellValue());
            assertEquals("333-D-40", sheet.getRow(4).getCell(2).getStringCellValue());
            assertEquals("Loc B2", sheet.getRow(4).getCell(7).getStringCellValue());

            for (int index = 1; index <= 4; index++) {
                assertTrue(sheet.getRow(index).getCell(0).getStringCellValue()
                        .matches("\\d{2}/\\d{2}/\\d{4}"));
                assertTrue(sheet.getRow(index).getCell(1).getStringCellValue()
                        .matches("\\d{2}:\\d{2}"));
            }
        }

        String report = Files.readString(result.reportPath());
        assertTrue(report.contains("RAPPORT DE TRAITEMENT PAR LOT"));
        assertTrue(report.contains("Classeurs trouvés  : 2"));
        assertTrue(report.contains("a.xlsx"));
        assertTrue(report.contains("b.xlsx"));
    }

    @Test
    void unClasseurEnEchecNEmpêchePasLaFusionDesSuivants(@TempDir Path directory) throws IOException {
        createTelemetryWorkbook(directory.resolve("a.xlsx"),
                new String[]{"Moving", "111-D-40", "111-D-40", "DRIVER A", "Loc A1", "", "", "40"});
        Files.writeString(directory.resolve("b.xlsx"), "ceci n'est pas un classeur Excel");
        createTelemetryWorkbook(directory.resolve("c.xlsx"),
                new String[]{"Moving", "333-D-40", "333-D-40", "DRIVER C", "Loc C1", "", "", "30"});
        Path output = directory.resolve("resultat_rapport_manager.xlsx");

        BatchResult result = new BatchService().execute(directory, output);

        assertEquals(3, result.filesFound());
        assertEquals(2, result.mergedFiles());
        assertEquals(1, result.failedFiles());
        assertEquals(2, result.appendedRows());
        assertEquals(BatchFileResult.Status.FAILED, result.files().get(1).status());
        assertTrue(Files.readString(result.reportPath()).contains("Échec"));

        try (XSSFWorkbook workbook = new XSSFWorkbook(Files.newInputStream(output))) {
            Sheet sheet = workbook.getSheet("Rapport manager");
            assertEquals("111-D-40", sheet.getRow(1).getCell(2).getStringCellValue());
            assertEquals("333-D-40", sheet.getRow(2).getCell(2).getStringCellValue());
        }
    }

    @Test
    void ignoreLesClasseursProduitsParApplication(@TempDir Path directory) throws IOException {
        createTelemetryWorkbook(directory.resolve("a.xlsx"),
                new String[]{"Moving", "111-D-40", "111-D-40", "DRIVER A", "Loc A1", "", "", "40"});
        createTelemetryWorkbook(directory.resolve("ancien_rapport_manager.xlsx"),
                new String[]{"Moving", "999-D-40", "999-D-40", "DRIVER Z", "Loc Z", "", "", "20"});
        Files.writeString(directory.resolve("resultat_rapport_manager.xlsx"), "");
        Path output = directory.resolve("resultat_rapport_manager.xlsx");

        BatchResult result = new BatchService().execute(directory, output);

        assertEquals(3, result.filesFound());
        assertEquals(1, result.mergedFiles());
        assertEquals(2, result.skippedFiles());
        assertEquals(1, result.appendedRows());
        String report = Files.readString(result.reportPath());
        assertTrue(report.contains("ancien_rapport_manager.xlsx"));
        assertTrue(report.contains("Ignoré"));
    }

    @Test
    void rejetteUnDossierSansClasseurATraiter(@TempDir Path directory) throws IOException {
        Files.writeString(directory.resolve("note.txt"), "rien à traiter");
        Path output = directory.resolve("resultat_rapport_manager.xlsx");

        EtlException exception = assertThrows(EtlException.class,
                () -> new BatchService().execute(directory, output));

        assertTrue(exception.getMessage().contains("aucun classeur"));
    }

    @Test
    void rejetteUnCheminSourceQuiNestPasUnDossier(@TempDir Path directory) throws IOException {
        Path source = directory.resolve("a.xlsx");
        createTelemetryWorkbook(source,
                new String[]{"Moving", "111-D-40", "111-D-40", "DRIVER A", "Loc A1", "", "", "40"});
        Path output = directory.resolve("resultat_rapport_manager.xlsx");

        EtlException exception = assertThrows(EtlException.class,
                () -> new BatchService().execute(source, output));

        assertTrue(exception.getMessage().contains("ne désigne pas un dossier"));
    }

    private void createTelemetryWorkbook(Path source, String[]... rows) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Vehicules");
            String[] headers = {
                    "Movement status", "Asset description", "Registration", "Driver", "Location",
                    "Last active event", "Last active event value", "Speed (km/h)"
            };
            Row header = sheet.createRow(0);
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
            }
            for (String[] values : rows) {
                Row row = sheet.createRow(sheet.getLastRowNum() + 1);
                for (int index = 0; index < values.length; index++) {
                    row.createCell(index).setCellValue(values[index]);
                }
            }
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }
    }
}
