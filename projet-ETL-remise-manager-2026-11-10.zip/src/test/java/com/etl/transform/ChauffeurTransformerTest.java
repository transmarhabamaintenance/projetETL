package com.etl.transform;

import com.etl.model.Chauffeur;
import com.etl.model.ChauffeurRecord;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;

class ChauffeurTransformerTest {

    private final ChauffeurTransformer transformer = new ChauffeurTransformer();

    @Test
    void nettoieEtNormaliseLesChampsSuivis() {
        Chauffeur source = new Chauffeur(
                "  en ligne  ", "  départ   normalisé ", "\u00a02024-01-01 08:00:00\u00a0",
                " f-001 ", " paris ", "  jean-luc  martin ", "  LYON  ",
                "  début  ", "  valeur 1 ", " 12,5 km/h "
        );

        Chauffeur result = transformer.transform(source);

        assertEquals("EN LIGNE", result.getStatutMobile());
        assertEquals("Départ Normalisé", result.getDescription());
        assertEquals("2024-01-01 08:00:00", result.getInscription());
        assertEquals("F-001", result.getNumeroFlotte());
        assertEquals("PARIS", result.getSite());
        assertEquals("Jean-Luc Martin", result.getChauffeurNom());
        assertEquals("Lyon", result.getEmplacement());
        assertEquals("Début", result.getDernierEvenement());
        assertEquals("valeur 1", result.getValeurDernierEvenement());
        assertEquals("12.5", result.getVitesse());
        assertNotSame(source, result);
    }

    @Test
    void extraitLeChauffeurDeLaDescriptionQuandLeChauffeurEstUnknown() {
        Chauffeur source = new Chauffeur(
                "Stationnaire", "1725-D-40 // Ichraf Boughi ", "1725-D-40", "1725-D-40",
                "Marrakech", "Unknown", "", "En route", "OK", "60"
        );

        Chauffeur result = transformer.transform(source);

        assertEquals("Ichraf Boughi", result.getChauffeurNom());
    }

    @Test
    void extraitLeChauffeurAvecUnSimpleSeparateurSlash() {
        Chauffeur source = new Chauffeur(
                "Stationnaire", "24942-D-40 /Erramah Abdelhadi", "24942-D-40", "24942-D-40",
                "Mohammedia", "  ", "", "", "", "0"
        );

        Chauffeur result = transformer.transform(source);

        assertEquals("Erramah Abdelhadi", result.getChauffeurNom());
    }

    @Test
    void neConservePasUnChauffeurNumeriqueNiUneDescriptionSansSeparateur() {
        Chauffeur dateLike = new Chauffeur(
                "actif", "28/04/2025", "", "F-1", "Paris", "", "", "", "", "0"
        );
        Chauffeur noSeparator = new Chauffeur(
                "actif", "MA11134 HCL", "", "F-1", "Paris", "Unknown", "", "", "", "0"
        );

        assertEquals("", transformer.transform(dateLike).getChauffeurNom());
        assertEquals("", transformer.transform(noSeparator).getChauffeurNom());
    }

    @Test
    void conserveLesEspacesInternesDUneVitesseInvalide() {
        Chauffeur source = new Chauffeur(
                "actif", "description", "date", "F-1", "Paris", "Alice", "position", "event", "valeur", "1 2"
        );

        Chauffeur result = transformer.transform(source);

        assertEquals("1 2", result.getVitesse());
    }

    @Test
    void transformeLesValeursUnknownEtVidesEnChampsVides() {
        Chauffeur source = new Chauffeur(
                " unknown ", null, "N/A", "UNKNOWN", " nd ", "  ", "inconnu", " ", "Unknown", "N/A"
        );

        Chauffeur result = transformer.transform(source);

        assertEquals("", result.getStatutMobile());
        assertEquals("", result.getInscription());
        assertEquals("", result.getNumeroFlotte());
        assertEquals("", result.getSite());
        assertEquals("", result.getChauffeurNom());
        assertEquals("", result.getEmplacement());
        assertEquals("", result.getDernierEvenement());
        assertEquals("", result.getValeurDernierEvenement());
        assertEquals("", result.getVitesse());
    }

    @Test
    void conserveLeNumeroDeLigneLorsDeLaTransformationGlobale() {
        ChauffeurRecord record = new ChauffeurRecord(7, new Chauffeur(
                "actif", "description", "date", "F-7", "Lyon", "Jean Martin",
                "poste", "evenement", "valeur", "0"
        ));

        List<ChauffeurRecord> result = transformer.transformAll(List.of(record));

        assertEquals(1, result.size());
        assertEquals(7, result.get(0).rowIndex());
        assertEquals("Jean Martin", result.get(0).chauffeur().getChauffeurNom());
    }
}
