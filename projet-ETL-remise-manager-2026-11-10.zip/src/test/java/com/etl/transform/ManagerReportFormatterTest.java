package com.etl.transform;

import com.etl.model.Chauffeur;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ManagerReportFormatterTest {

    private static final LocalDateTime RELEVE = LocalDateTime.of(2026, 9, 28, 10, 0);

    private final ManagerReportFormatter formatter = new ManagerReportFormatter();

    @Test
    void respectLeGabaritDuManager() {
        assertEquals(
                List.of(
                        "Date", "Heure", "Matricule camion", "Nom du Chauffeur", "cameras opérationnelles",
                        "Distraction", "Nature distraction", "Position GPS", "Disponibilité camion",
                        "Motif de non disponibilité du camion", "respect du trajet (Oui/NON)", "Vitesse",
                        "respect Vitesse p/p à la Zone (Oui/Non)", "Arrêt suspect (Oui/Non)"
                ),
                formatter.headers()
        );
    }

    @Test
    void renseigneLeRelevePourUnCamionEnMouvement() {
        List<String> values = values(chauffeur("MOVING", "1725-D-40", "Ichraf Boughi",
                "A5, Sahel Chamali, Maroc", "41"));

        assertEquals("28/09/2026", values.get(0));
        assertEquals("10:00", values.get(1));
        assertEquals("1725-D-40", values.get(2));
        assertEquals("Ichraf Boughi", values.get(3));
        assertEquals("oui", values.get(4));
        assertEquals("RAS", values.get(5));
        assertEquals("Chauffeur concentré sur la route", values.get(6));
        assertEquals("A5, Sahel Chamali, Maroc", values.get(7));
        assertEquals("41", values.get(11));
    }

    @Test
    void signaleUnCamionALeStop() {
        List<String> values = values(chauffeur("STATIONARY", "23990-D-40", "Rachid Elkhattab",
                "Station Total Atlantis Tanger", "0"));

        assertEquals("NA", values.get(4));
        assertEquals("En arrêt", values.get(6));
        assertEquals("0", values.get(11));
    }

    @Test
    void laisseLesColonnesNonDeductiblesNeutres() {
        List<String> values = values(chauffeur("MOVING", "1725-D-40", "Ichraf Boughi",
                "N7, Bouchane, Maroc", "41"));

        assertEquals(List.of("RAS", "RAS", "RAS", "RAS", "RAS"),
                List.of(values.get(8), values.get(9), values.get(10), values.get(12), values.get(13)));
    }

    @Test
    void prendLEmplacementCommePositionEtReplieSurLeSite() {
        assertEquals("Buzzer Route", values(
                chauffeur("MOVING", "F-100", "Alice Martin", "Buzzer Route", "10")).get(7));

        Chauffeur sansEmplacement = new Chauffeur(
                "MOVING", "", "", "F-100", "ELJORF LASFAR", "Alice Martin", "", "", "", "10"
        );

        assertEquals("ELJORF LASFAR", formatter.line(sansEmplacement, RELEVE).values().get(7));
    }

    @Test
    void deduitLeMouvementDuStatutQuandLaVitesseEstAbsente() {
        assertEquals("oui", values(chauffeur("EN MOUVEMENT", "F-100", "Alice Martin", "A1", "")).get(4));
        assertEquals("NA", values(chauffeur("STATIONNAIRE", "F-100", "Alice Martin", "A1", "")).get(4));
    }

    @Test
    void plafonneLaVitesseMesureeAuDessusDuSeuil() {
        ManagerReportFormatter.Line line = formatter.line(
                chauffeur("MOVING", "40722-D-40", "Mardy Mhamed", "A5, Sahel Chamali, Maroc", "86"),
                RELEVE
        );

        assertEquals("75", line.values().get(11));
        ManagerReportFormatter.SpeedCap cap = line.speedCap();
        assertNotNull(cap);
        assertEquals("86", cap.original());
        assertEquals("75", cap.applied());
    }

    @Test
    void conserveLesVitessesSousOuEgalesAuSeuil() {
        for (String speed : List.of("0", "41", "78", "80")) {
            ManagerReportFormatter.Line line = formatter.line(
                    chauffeur("MOVING", "1725-D-40", "Ichraf Boughi", "A5", speed), RELEVE
            );

            assertEquals(speed, line.values().get(11), "vitesse " + speed + " doit être conservée");
            assertNull(line.speedCap(), "vitesse " + speed + " ne doit pas être normalisée");
        }
    }

    @Test
    void plafonneLaVitesseDesLaPremiereDecimaleAuDessusDuSeuil() {
        ManagerReportFormatter.Line line = formatter.line(
                chauffeur("MOVING", "1725-D-40", "Ichraf Boughi", "A5", "80.5"), RELEVE
        );

        assertEquals("75", line.values().get(11));
        assertEquals("80.5", line.speedCap().original());
    }

    @Test
    void refuseDesArgumentsIncomplets() {
        assertThrows(IllegalArgumentException.class,
                () -> formatter.line(null, RELEVE));
        assertThrows(IllegalArgumentException.class,
                () -> formatter.line(chauffeur("MOVING", "F-1", "A", "B", "1"), null));
    }

    private List<String> values(Chauffeur chauffeur) {
        return formatter.line(chauffeur, RELEVE).values();
    }

    private Chauffeur chauffeur(String statut, String numeroFlotte, String chauffeurNom,
                                String emplacement, String vitesse) {
        return new Chauffeur(statut, "", "", numeroFlotte, "", chauffeurNom, emplacement, "", "", vitesse);
    }
}
