package com.etl.heures.service;

import com.etl.heures.EtlException;
import com.etl.heures.model.EtlProgress;
import com.etl.heures.model.EtlResult;
import com.etl.heures.model.FleetFilter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EtlServiceTest {

    private static final List<Object> EN_TETES = List.of(
            "Date", "Description du vehicule",
            "Première heure de début du trajet", "Heure de fin du dernier trajet",
            "Temps de conduite (hh:mm:ss)", "Temps d'attente (hh:mm:ss)",
            "durée (hh:mm:ss)", "Durée de ralenti (hh:mm:ss)", "Distance (km)");

    private static void ecrireClasseur(Path target, String titre, List<List<Object>> lignes) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.createSheet("Daily Trip Report");
            sheet.createRow(0).createCell(0).setCellValue(titre);
            int r = 1;
            for (List<Object> ligne : lignes) {
                XSSFRow row = sheet.createRow(r++);
                int c = 0;
                for (Object value : ligne) {
                    if (value instanceof Number number) {
                        row.createCell(c).setCellValue(number.doubleValue());
                    } else {
                        row.createCell(c).setCellValue(String.valueOf(value));
                    }
                    c++;
                }
            }
            try (OutputStream out = Files.newOutputStream(target)) {
                workbook.write(out);
            }
        }
    }

    @Test
    void traiteUnFichierDeBoutEnBout(@TempDir Path dir) throws Exception {
        Path input = dir.resolve("rapport.xlsx");
        ecrireClasseur(input, "Rapport journalier des trajets\nMorocco VIVO ENERGY MAROC", List.of(
                List.of(),
                List.of(),
                List.of(),
                EN_TETES,
                List.of(46023, "1725-D-40 // ichraf boughi", 0.3, 0.65625,
                        0.19479, "00:35:31", "", "", 299.195),
                List.of(46023, "1725-D-40 // ICHRAF BOUGHI", 0.25, 0.5,
                        0.125, "", "", "", 100.805),
                List.of(46024, "1725-D-99 // autre chauffeur", 0.3, 0.6,
                        0.2, "00:10:00", "", "", 50.0)));
        Path output = dir.resolve("heures_de_travail.xlsx");

        List<EtlProgress> events = new ArrayList<>();
        EtlResult result = new EtlService().execute(input, output, null, FleetFilter.VIVO,
                null, null, events::add);

        assertEquals(3, result.getExtractedRows());
        assertEquals(3, result.getTransformedRows());
        assertEquals(0, result.getFilteredRows());
        assertEquals(1, result.getMergedDuplicates());
        assertEquals(0, result.getErrors());
        assertEquals(2, result.getLoadedRows());
        assertTrue(Files.exists(output));
        assertTrue(Files.exists(EtlService.buildReportPath(output)));
        assertEquals(EtlProgress.Stage.COMPLETED, events.get(events.size() - 1).getStage());

        try (XSSFWorkbook workbook = new XSSFWorkbook(output.toFile())) {
            XSSFSheet sheet = workbook.getSheet("DATA BASE");
            XSSFRow dataRow = sheet.getRow(1);
            assertEquals("vivo", dataRow.getCell(1).getStringCellValue());
            assertEquals("1725-D-40", dataRow.getCell(2).getStringCellValue());
            assertEquals("Ichraf Boughi", dataRow.getCell(3).getStringCellValue());
            assertEquals("07:40:30", dataRow.getCell(10).getStringCellValue());
        }
    }

    @Test
    void refuseUneSortieIdentiqueALaSource(@TempDir Path dir) {
        Path meme = dir.resolve("meme.xlsx");

        assertThrows(EtlException.class, () -> new EtlService().execute(meme, meme, null));
    }

    @Test
    void echoueQuandLeFiltreNeRetientRien(@TempDir Path dir) throws Exception {
        Path input = dir.resolve("total-seul.xlsx");
        ecrireClasseur(input, "Rapport journalier des trajets\nMorocco TOTAL MAROC", List.of(
                List.of(),
                List.of(),
                List.of(),
                EN_TETES,
                List.of(46023, "1725-D-99 // autre chauffeur", 0.3, 0.6,
                        0.2, "00:10:00", "", "", 50.0)));

        EtlException exception = assertThrows(EtlException.class, () -> new EtlService()
                .execute(input, dir.resolve("out.xlsx"), null, FleetFilter.VIVO, null, null, null));

        assertTrue(exception.getMessage().contains("Aucune donnée"));
    }
}
