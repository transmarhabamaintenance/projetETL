package com.etl.heures.aggregate;

import com.etl.heures.model.FleetFilter;
import com.etl.heures.model.Journee;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TrajetAggregatorFilterTest {

    private static final LocalDate DATE = LocalDate.of(2026, 1, 1);

    @Test
    void ecarteLesFlottesFiltrees() {
        TrajetAggregator aggregator = new TrajetAggregator(FleetFilter.VIVO, null, null);
        assertTrue(aggregator.add(TrajetAggregatorTest.record(1, "vivo", "1725-D-40", "Ichraf", DATE,
                LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofHours(4), Duration.ZERO, 100.0, null, null)));
        assertFalse(aggregator.add(TrajetAggregatorTest.record(2, "TOTAL", "1725-D-99", "Autre", DATE,
                LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofHours(4), Duration.ZERO, 100.0, null, null)));

        assertEquals(1, aggregator.getFilteredOut());
        assertEquals(1, aggregator.result().getJournees().size());
    }

    @Test
    void ecarteLesDatesHorsPeriode() {
        TrajetAggregator aggregator = new TrajetAggregator(FleetFilter.TOUTES,
                LocalDate.of(2026, 1, 2), null);

        assertFalse(aggregator.add(TrajetAggregatorTest.record(1, "vivo", "1725-D-40", "Ichraf",
                LocalDate.of(2026, 1, 1), LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofHours(4), Duration.ZERO, 100.0, null, null)));

        assertEquals(1, aggregator.getFilteredOut());
        assertTrue(aggregator.result().getJournees().isEmpty());
    }

    @Test
    void trieParDatePuisVehicule() {
        TrajetAggregator aggregator = new TrajetAggregator(FleetFilter.TOUTES, null, null);
        aggregator.add(TrajetAggregatorTest.record(1, "vivo", "B", "x", LocalDate.of(2026, 1, 1),
                LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofHours(1), Duration.ZERO, null, null, null));
        aggregator.add(TrajetAggregatorTest.record(2, "vivo", "Z", "x", LocalDate.of(2026, 1, 1),
                LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofHours(1), Duration.ZERO, null, null, null));
        aggregator.add(TrajetAggregatorTest.record(3, "vivo", "A", "x", LocalDate.of(2026, 1, 2),
                LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofHours(1), Duration.ZERO, null, null, null));

        List<Journee> journees = aggregator.result().getJournees();

        assertEquals(3, journees.size());
        assertEquals("B", journees.get(0).getVehicule());
        assertEquals("Z", journees.get(1).getVehicule());
        assertEquals("A", journees.get(2).getVehicule());
    }
}
