package com.etl.heures.aggregate;

import com.etl.heures.model.FleetFilter;
import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TrajetAggregatorTest {

    private static final LocalDate DATE = LocalDate.of(2026, 1, 1);

    static JourneeRecord record(int rowIndex, String flotte, String vehicule, String chauffeur,
                                LocalDate date, LocalTime debut, LocalTime fin,
                                Duration conduite, Duration attente, Double distance,
                                Double vitesseMoy, Double vitesseMax) {
        Journee journee = new Journee();
        journee.setFlotte(flotte);
        journee.setVehicule(vehicule);
        journee.setChauffeur(chauffeur);
        journee.setDate(date);
        journee.setHeureDebut(debut);
        journee.setHeureFin(fin);
        journee.setTempsConduite(conduite);
        journee.setTempsAttente(attente);
        journee.setDuree(conduite.plus(attente));
        journee.setDistance(distance);
        journee.setVitesseMoy(vitesseMoy);
        journee.setVitesseMax(vitesseMax);
        return new JourneeRecord(rowIndex, journee);
    }

    @Test
    void fusionneLesLignesDeMemeCle() {
        TrajetAggregator aggregator = new TrajetAggregator(FleetFilter.TOUTES, null, null);
        aggregator.add(record(1, "vivo", "1725-D-40", "Ichraf Boughi", DATE,
                LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofSeconds(16830), Duration.ofSeconds(2131), 299.195, 50.0, 87.4));
        boolean added = aggregator.add(record(2, "VIVO", "1725-d-40", "ichraf boughi", DATE,
                LocalTime.of(6, 0), LocalTime.of(11, 0),
                Duration.ofSeconds(10800), Duration.ZERO, 100.805, 40.0, 95.5));

        assertTrue(added);
        AggregationResult result = aggregator.result();
        assertEquals(1, result.getJournees().size());
        assertEquals(1, aggregator.getMergedDuplicates());

        Journee merged = result.getJournees().get(0);
        assertEquals(Duration.ofSeconds(27630), merged.getTempsConduite());
        assertEquals(Duration.ofSeconds(2131), merged.getTempsAttente());
        assertEquals(Duration.ofSeconds(29761), merged.getDuree());
        assertEquals(LocalTime.of(6, 0), merged.getHeureDebut());
        assertEquals(LocalTime.of(12, 0), merged.getHeureFin());
        assertEquals(400.0, merged.getDistance(), 1e-6);
        assertEquals(95.5, merged.getVitesseMax());
        assertEquals(52.11726, merged.getVitesseMoy(), 1e-5);
    }

    @Test
    void recalculeLaVitesseMoyenneDUneSeuleLigne() {
        TrajetAggregator aggregator = new TrajetAggregator(FleetFilter.TOUTES, null, null);
        aggregator.add(record(1, "vivo", "1725-D-40", "Ichraf Boughi", DATE,
                LocalTime.of(7, 0), LocalTime.of(12, 0),
                Duration.ofSeconds(16830), Duration.ZERO, 299.195, 999.0, 80.0));

        Journee journee = aggregator.result().getJournees().get(0);

        assertEquals(0, aggregator.getMergedDuplicates());
        assertEquals(63.99893, journee.getVitesseMoy(), 1e-5);
    }
}
