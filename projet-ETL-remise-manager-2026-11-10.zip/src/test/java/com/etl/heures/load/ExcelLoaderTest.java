package com.etl.heures.load;

import com.etl.heures.EtlException;
import com.etl.heures.model.Journee;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ExcelLoaderTest {

    private static Journee journee(LocalDate date, String flotte, String vehicule, String chauffeur,
                                   LocalTime debut, LocalTime fin, Duration conduite, Duration attente) {
        Journee journee = new Journee();
        journee.setDate(date);
        journee.setFlotte(flotte);
        journee.setVehicule(vehicule);
        journee.setChauffeur(chauffeur);
        journee.setHeureDebut(debut);
        journee.setHeureFin(fin);
        journee.setTempsConduite(conduite);
        journee.setTempsAttente(attente);
        journee.setDuree(conduite.plus(attente));
        return journee;
    }

    @Test
    void ecritLeClasseurHeuresDeTravailEtLeRelit(@TempDir Path dir) throws Exception {
        Journee premiere = journee(LocalDate.of(2026, 1, 1), "vivo", "1725-D-40", "Ichraf Boughi",
                LocalTime.of(7, 12), LocalTime.of(15, 45),
                Duration.ofSeconds(16830), Duration.ofSeconds(2131));
        Journee incomplete = journee(LocalDate.of(2026, 1, 2), "TOTAL", "1725-D-41", "",
                null, null, Duration.ofSeconds(10800), Duration.ZERO);
        Path output = dir.resolve("heures.xlsx");

        new ExcelLoader().write(output, List.of(premiere, incomplete));

        try (XSSFWorkbook workbook = new XSSFWorkbook(output.toFile())) {
            assertEquals("DATA BASE", workbook.getSheetAt(0).getSheetName());
            assertEquals("INDEX", workbook.getSheetAt(1).getSheetName());
            XSSFSheet sheet = workbook.getSheet("DATA BASE");

            XSSFRow header = sheet.getRow(0);
            assertEquals(17, header.getLastCellNum());
            assertEquals("Date", header.getCell(0).getStringCellValue());
            assertEquals("total / vivo", header.getCell(1).getStringCellValue());
            assertEquals("Description du bien", header.getCell(2).getStringCellValue());
            assertEquals("CHAUFFEUR", header.getCell(3).getStringCellValue());
            assertEquals("Heure de fin du dernier trajet2", header.getCell(6).getStringCellValue());
            assertEquals("Durée de conduite (hh:mm:ss)2", header.getCell(11).getStringCellValue());
            assertEquals("REPOS quotidien", header.getCell(13).getStringCellValue());
            assertEquals("emplacement de depart", header.getCell(16).getStringCellValue());

            XSSFRow ligne1 = sheet.getRow(1);
            assertEquals(LocalDate.of(2026, 1, 1), ligne1.getCell(0).getLocalDateTimeCellValue().toLocalDate());
            assertEquals("vivo", ligne1.getCell(1).getStringCellValue());
            assertEquals("1725-D-40", ligne1.getCell(2).getStringCellValue());
            assertEquals("Ichraf Boughi", ligne1.getCell(3).getStringCellValue());
            assertEquals(LocalDateTime.of(2026, 1, 1, 7, 12),
                    ligne1.getCell(4).getLocalDateTimeCellValue());
            assertEquals("+E2-INT(E2)", ligne1.getCell(5).getCellFormula());
            assertEquals(LocalDateTime.of(2026, 1, 1, 15, 45),
                    ligne1.getCell(6).getLocalDateTimeCellValue());
            assertEquals("+G2-INT(G2)", ligne1.getCell(7).getCellFormula());
            assertEquals("+G2-E2", ligne1.getCell(8).getCellFormula());
            assertEquals("+I2-INT(I2)", ligne1.getCell(9).getCellFormula());
            assertEquals("04:40:30", ligne1.getCell(10).getStringCellValue());
            assertEquals("+K2-INT(K2)", ligne1.getCell(11).getCellFormula());
            assertEquals("00:35:31", ligne1.getCell(12).getStringCellValue());
            assertEquals(0.5, ligne1.getCell(13).getNumericCellValue(), 1e-9);

            XSSFRow ligne2 = sheet.getRow(2);
            assertEquals("TOTAL", ligne2.getCell(1).getStringCellValue());
            assertEquals("1725-D-41", ligne2.getCell(2).getStringCellValue());
            assertNull(ligne2.getCell(4));
            assertNull(ligne2.getCell(13));
            assertEquals("03:00:00", ligne2.getCell(10).getStringCellValue());
        }
    }

    @Test
    void refuseUneListeVide(@TempDir Path dir) {
        Path output = dir.resolve("vide.xlsx");

        assertThrows(EtlException.class, () -> new ExcelLoader().write(output, List.of()));
    }
}
