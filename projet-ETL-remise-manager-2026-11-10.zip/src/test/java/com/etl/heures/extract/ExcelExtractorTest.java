package com.etl.heures.extract;

import com.etl.heures.EtlException;
import com.etl.heures.model.ExtraColumn;
import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import com.etl.heures.transform.TrajetTransformer;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ExcelExtractorTest {

    private static final List<Object> EN_TETES = List.of(
            "Date", "Description du vehicule",
            "Première heure de début du trajet", "Heure de fin du dernier trajet",
            "Temps de conduite (hh:mm:ss)", "Temps d'attente (hh:mm:ss)",
            "durée (hh:mm:ss)", "Durée de ralenti (hh:mm:ss)", "Distance (km)", "trajet2");

    private static void ecrireClasseur(Path target, List<List<Object>> lignes) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.createSheet("Daily Trip Report");
            int r = 0;
            for (List<Object> ligne : lignes) {
                XSSFRow row = sheet.createRow(r++);
                int c = 0;
                for (Object value : ligne) {
                    XSSFCell cell = row.createCell(c++);
                    if (value instanceof Number number) {
                        cell.setCellValue(number.doubleValue());
                    } else {
                        cell.setCellValue(String.valueOf(value));
                    }
                }
            }
            try (OutputStream out = Files.newOutputStream(target)) {
                workbook.write(out);
            }
        }
    }

    @Test
    void normaliseLesEnTetes() {
        assertEquals("duree de conduite hh mm ss",
                ExcelExtractor.normalizeHeader("Durée de conduite (hh:mm:ss)"));
        assertEquals("description du vehicule",
                ExcelExtractor.normalizeHeader("Description du vehicule"));
    }

    @Test
    void extraitLaFeuilleEtLesColonnes(@TempDir Path dir) throws Exception {
        Path source = dir.resolve("rapport.xlsx");
        ecrireClasseur(source, List.of(
                List.of("Rapport journalier des trajets\nMorocco VIVO ENERGY MAROC\n\nDe 02/10/2026 à 02/10/2026"),
                List.of(),
                List.of(),
                List.of(),
                EN_TETES,
                List.of(46023, "1725-D-40 // ichraf boughi", 0.3, 0.65625,
                        0.19479, "00:35:31", "08:35:00", "03:18:59", 299.195, "détail X"),
                List.of("Totaux", "", "", "", "25:30:00"),
                List.of(46024, "1725-D-41 // autre chauffeur", 0.3, 0.6,
                        0.1, "00:10:00", "", "", 50.0, "")));

        ExcelExtractor extractor = new ExcelExtractor();
        assertEquals(List.of("Daily Trip Report"), extractor.listSheetNames(source));

        ExtractionResult result = extractor.extract(source, null);
        assertEquals(1, result.getRows().size());
        assertEquals("Daily Trip Report", result.getSheetName());
        assertTrue(result.getPresentFields().contains(TrajetField.DATE));
        assertTrue(result.getPresentFields().contains(TrajetField.TEMPS_CONDUITE));
        assertTrue(result.getPresentFields().contains(TrajetField.DUREE_RALENTI));
        assertTrue(result.getPresentFields().contains(TrajetField.DISTANCE));
        assertEquals(List.of("trajet2"), result.getExtraLabels());

        RawRow raw = result.getRows().get(0);
        assertEquals(6, raw.rowIndex());
        assertEquals("vivo", raw.flotte());
        assertEquals(46023.0, raw.get(TrajetField.DATE).numeric());
        assertEquals("1725-D-40 // ichraf boughi", raw.get(TrajetField.VEHICULE).text());
        assertEquals(0.19479, raw.get(TrajetField.TEMPS_CONDUITE).numeric(), 1e-9);
        assertEquals("00:35:31", raw.get(TrajetField.TEMPS_ATTENTE).text());
        assertEquals("08:35:00", raw.get(TrajetField.DUREE).text());
        assertEquals(299.195, raw.get(TrajetField.DISTANCE).numeric(), 1e-9);
        assertEquals(1, raw.extras().size());
        ExtraColumn extra = raw.extras().get(0);
        assertEquals("trajet2", extra.label());
        assertEquals("détail X", extra.value());

        JourneeRecord record = new TrajetTransformer().transform(raw);
        assertTrue(record.errors().isEmpty());
        Journee journee = record.journee();
        assertEquals(LocalDate.of(2026, 1, 1), journee.getDate());
        assertEquals("vivo", journee.getFlotte());
        assertEquals("1725-D-40", journee.getVehicule());
        assertEquals("Ichraf Boughi", journee.getChauffeur());
        assertEquals(Duration.ofSeconds(16830), journee.getTempsConduite());
        assertEquals(Duration.ofSeconds(2131), journee.getTempsAttente());
        assertEquals(Duration.ofSeconds(30900), journee.getDuree());
        assertEquals(Duration.ofSeconds(11939), journee.getDureeRalenti());
    }

    @Test
    void ignoreLesLignesApresTotaux(@TempDir Path dir) throws Exception {
        Path source = dir.resolve("totaux.xlsx");
        ecrireClasseur(source, List.of(
                List.of("Rapport journalier des trajets\nMorocco TOTAL MAROC"),
                List.of(),
                List.of(),
                List.of(),
                EN_TETES,
                List.of(46023, "1725-D-40", 0.3, 0.65625, 0.19479, "00:35:31", "", "", 10.0, ""),
                List.of("Totaux", "", "", "", "04:40:30"),
                List.of("Moyennes", "", "", "", "04:40:30"),
                List.of(46024, "1725-D-41", 0.3, 0.6, 0.1, "00:10:00", "", "", 20.0, "")));

        ExtractionResult result = new ExcelExtractor().extract(source, null);

        assertEquals(1, result.getRows().size());
        assertEquals("TOTAL", result.getRows().get(0).flotte());
    }

    @Test
    void signaleLesEnTetesIntrouvables(@TempDir Path dir) throws Exception {
        Path source = dir.resolve("autre.xlsx");
        ecrireClasseur(source, List.of(
                List.of("A", "B", "C"),
                List.of("x", "y", "z")));

        EtlException exception = assertThrows(EtlException.class,
                () -> new ExcelExtractor().extract(source, null));

        assertTrue(exception.getMessage().contains("En-têtes introuvables"));
    }

    @Test
    void refuseLesFichiersInvalides(@TempDir Path dir) {
        ExcelExtractor extractor = new ExcelExtractor();

        assertThrows(EtlException.class, () -> extractor.validateSource(dir.resolve("data.csv")));
        assertThrows(EtlException.class, () -> extractor.validateSource(dir.resolve("~$f.xlsx")));
        assertThrows(EtlException.class, () -> extractor.validateSource(dir.resolve("absent.xlsx")));
    }
}
