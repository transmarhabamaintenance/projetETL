package com.etl.heures.validation;

import com.etl.heures.model.Journee;
import com.etl.heures.model.JourneeRecord;
import com.etl.heures.model.ValidationError;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TrajetValidatorTest {

    private static JourneeRecord record(Journee journee, ValidationError... errors) {
        return new JourneeRecord(3, journee, List.of(errors), List.of());
    }

    private static Journee journeeValide() {
        Journee journee = new Journee();
        journee.setDate(LocalDate.of(2026, 1, 1));
        journee.setVehicule("1725-D-40");
        return journee;
    }

    @Test
    void accepteUneLigneComplete() {
        TrajetValidator validator = new TrajetValidator();

        assertTrue(validator.validateRow(record(journeeValide())).isEmpty());

        ValidationOutcome outcome = validator.validate(List.of(record(journeeValide())));
        assertEquals(1, outcome.getValid().size());
        assertTrue(outcome.getErrors().isEmpty());
    }

    @Test
    void refuseUneLigneSansDate() {
        Journee journee = new Journee();
        journee.setVehicule("1725-D-40");

        List<ValidationError> errors = new TrajetValidator().validateRow(record(journee));

        assertEquals(1, errors.size());
        assertEquals("Date", errors.get(0).getColumn());
        assertEquals(3, errors.get(0).getRowIndex());
        assertTrue(errors.get(0).getDescription().contains("Date absente"));
    }

    @Test
    void refuseUneLigneSansVehicule() {
        Journee journee = new Journee();
        journee.setDate(LocalDate.of(2026, 1, 1));

        List<ValidationError> errors = new TrajetValidator().validateRow(record(journee));

        assertEquals(1, errors.size());
        assertEquals("Description du vehicule", errors.get(0).getColumn());
        assertTrue(errors.get(0).getDescription().contains("Véhicule absent"));
    }

    @Test
    void neDupliquePasLErreurDeDateDejaSignalee() {
        Journee journee = new Journee();
        journee.setVehicule("1725-D-40");
        JourneeRecord record = record(journee,
                new ValidationError(3, "Date", "xyz", "Date illisible : xyz"));

        List<ValidationError> errors = new TrajetValidator().validateRow(record);

        assertEquals(1, errors.size());
        assertEquals("Date illisible : xyz", errors.get(0).getDescription());
    }

    @Test
    void separeLesLignesValidesDesLignesEnErreur() {
        Journee sansDate = new Journee();
        sansDate.setVehicule("1725-D-40");

        ValidationOutcome outcome = new TrajetValidator()
                .validate(List.of(record(journeeValide()), record(sansDate)));

        assertEquals(1, outcome.getValid().size());
        assertEquals(1, outcome.getErrors().size());
    }
}
