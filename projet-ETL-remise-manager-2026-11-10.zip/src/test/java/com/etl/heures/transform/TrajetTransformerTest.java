package com.etl.heures.transform;

import com.etl.heures.extract.CellReading;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TrajetTransformerTest {

    private static CellReading text(String value) {
        return new CellReading(value, null);
    }

    private static CellReading numeric(double value) {
        return new CellReading(Double.toString(value), value);
    }

    @Test
    void nettoieLesTextes() {
        assertEquals("", TrajetTransformer.clean("unknown"));
        assertEquals("", TrajetTransformer.clean("N/A"));
        assertEquals("", TrajetTransformer.clean("non renseigné"));
        assertEquals("", TrajetTransformer.clean(null));
        assertEquals("Vivo Énergie", TrajetTransformer.clean(" Vivo   Énergie "));
    }

    @Test
    void capitaliseLesNoms() {
        assertEquals("Ichraf Boughi", TrajetTransformer.titleCase("ichraf boughi"));
        assertEquals("ARKHA", TrajetTransformer.titleCase("ARKHA"));
        assertEquals("Jean", TrajetTransformer.titleCase("jean"));
        assertEquals("", TrajetTransformer.titleCase("   "));
    }

    @Test
    void convertitLesSerialsExcelEnDates() {
        assertEquals(LocalDate.of(2026, 1, 1), TrajetTransformer.excelSerialToDate(46023));
        assertEquals(LocalDate.of(1899, 12, 30), TrajetTransformer.excelSerialToDate(0));
    }

    @Test
    void litLesDureesSousToutesLesFormes() {
        assertEquals(16830L, TrajetTransformer.parseDuration(numeric(0.19479)).toSeconds());
        assertEquals(109800L, TrajetTransformer.parseDuration(numeric(1.270833)).toSeconds());
        assertEquals(109800L, TrajetTransformer.parseDuration(text("30:30:00")).toSeconds());
        assertEquals(577721L, TrajetTransformer.parseDuration(text("160:28:41")).toSeconds());
        assertEquals(16830L, TrajetTransformer.parseDuration(text("4.675")).toSeconds());
        assertEquals(16830L, TrajetTransformer.parseDuration(text("4,675")).toSeconds());
        assertEquals(-5400L, TrajetTransformer.parseDuration(text("-1:30")).toSeconds());
        assertNull(TrajetTransformer.parseDuration(text("abc")));
        assertNull(TrajetTransformer.parseDuration(CellReading.EMPTY));
    }

    @Test
    void litLesDureesStockeesCommeDates1900() {
        assertEquals(109800L, TrajetTransformer.parseDuration(text("1900-01-02T06:30:00")).toSeconds());
        assertNull(TrajetTransformer.parseDuration(text("2026-01-01T10:00:00")));
    }

    @Test
    void litLesDates() {
        assertEquals(LocalDate.of(2026, 1, 1), TrajetTransformer.parseDate(numeric(46023)));
        assertEquals(LocalDate.of(2026, 1, 1), TrajetTransformer.parseDate(text("46023")));
        assertEquals(LocalDate.of(2026, 2, 1), TrajetTransformer.parseDate(text("01/02/2026")));
        assertEquals(LocalDate.of(2026, 1, 1), TrajetTransformer.parseDate(text("2026-01-01")));
        assertNull(TrajetTransformer.parseDate(text("pas une date")));
    }

    @Test
    void litLesHeures() {
        assertEquals(LocalTime.of(7, 12), TrajetTransformer.parseTime(numeric(0.3)));
        assertEquals(LocalTime.of(6, 0), TrajetTransformer.parseTime(numeric(1.25)));
        assertEquals(LocalTime.of(8, 15), TrajetTransformer.parseTime(text("08:15:00")));
        assertNull(TrajetTransformer.parseTime(text("abc")));
    }

    @Test
    void litLesNombres() {
        assertEquals(3.5, TrajetTransformer.parseNumber(numeric(3.5)));
        assertEquals(12.5, TrajetTransformer.parseNumber(text("12,5 km/h")));
        assertEquals(299.195, TrajetTransformer.parseNumber(text("299.195")));
        assertNull(TrajetTransformer.parseNumber(text("abc")));
    }

    @Test
    void arronditACinqDecimales() {
        assertEquals(63.99893, TrajetTransformer.round5(299.195 / 4.675));
    }
}
