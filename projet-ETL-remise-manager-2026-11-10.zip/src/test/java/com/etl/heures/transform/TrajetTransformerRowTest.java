package com.etl.heures.transform;

import com.etl.heures.extract.RawRow;
import com.etl.heures.extract.TrajetField;
import com.etl.heures.extract.CellReading;
import com.etl.heures.model.ExtraColumn;
import com.etl.heures.model.ValidationError;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TrajetTransformerRowTest {

    private static CellReading text(String value) {
        return new CellReading(value, null);
    }

    @Test
    void transformeUneLigneComplete() {
        Map<TrajetField, CellReading> cells = new EnumMap<>(TrajetField.class);
        cells.put(TrajetField.DATE, text("01/01/2026"));
        cells.put(TrajetField.VEHICULE, text("1725-D-40 // ichraf boughi"));
        cells.put(TrajetField.HEURE_DEBUT, text("07:00"));
        cells.put(TrajetField.HEURE_FIN, text("12:00"));
        cells.put(TrajetField.TEMPS_CONDUITE, text("04:40:30"));
        cells.put(TrajetField.TEMPS_ATTENTE, text("00:35:31"));
        cells.put(TrajetField.DUREE, text("08:35:00"));
        cells.put(TrajetField.DUREE_RALENTI, text("03:18:59"));
        cells.put(TrajetField.DISTANCE, text("299.195"));
        cells.put(TrajetField.VITESSE_MAX, text("87.4"));

        var record = new TrajetTransformer().transform(new RawRow(7, cells,
                List.of(new ExtraColumn("trajet2", "détail X")), "vivo"));

        assertTrue(record.errors().isEmpty());
        assertEquals(1, record.extras().size());
        var journee = record.journee();
        assertEquals(LocalDate.of(2026, 1, 1), journee.getDate());
        assertEquals("vivo", journee.getFlotte());
        assertEquals("1725-D-40", journee.getVehicule());
        assertEquals("Ichraf Boughi", journee.getChauffeur());
        assertEquals(LocalTime.of(7, 0), journee.getHeureDebut());
        assertEquals(LocalTime.of(12, 0), journee.getHeureFin());
        assertEquals(16830L, journee.getTempsConduite().toSeconds());
        assertEquals(2131L, journee.getTempsAttente().toSeconds());
        assertEquals(30900L, journee.getDuree().toSeconds());
        assertEquals(11939L, journee.getDureeRalenti().toSeconds());
        assertEquals(299.195, journee.getDistance());
        assertNull(journee.getVitesseMoy());
        assertEquals(87.4, journee.getVitesseMax());
    }

    @Test
    void calculeLaDureeParDefautQuandAbsente() {
        Map<TrajetField, CellReading> cells = new EnumMap<>(TrajetField.class);
        cells.put(TrajetField.DATE, text("01/01/2026"));
        cells.put(TrajetField.VEHICULE, text("1725-D-40"));
        cells.put(TrajetField.TEMPS_CONDUITE, text("04:40:30"));
        cells.put(TrajetField.TEMPS_ATTENTE, text("00:35:31"));

        var record = new TrajetTransformer().transform(new RawRow(5, cells, List.of()));

        assertTrue(record.errors().isEmpty());
        assertEquals(18961L, record.journee().getDuree().toSeconds());
        assertEquals(Duration.ZERO, record.journee().getDureeRalenti());
    }

    @Test
    void signaleUneDateIllisible() {
        Map<TrajetField, CellReading> cells = new EnumMap<>(TrajetField.class);
        cells.put(TrajetField.VEHICULE, text("1725-D-40"));
        cells.put(TrajetField.DATE, text("xyz"));

        var record = new TrajetTransformer().transform(new RawRow(4, cells, List.of()));

        assertNull(record.journee().getDate());
        assertEquals(1, record.errors().size());
        ValidationError error = record.errors().get(0);
        assertEquals(4, error.getRowIndex());
        assertEquals("Date", error.getColumn());
        assertEquals("Date illisible : xyz", error.getDescription());
    }

    @Test
    void signaleUneDureeNegative() {
        Map<TrajetField, CellReading> cells = new EnumMap<>(TrajetField.class);
        cells.put(TrajetField.DATE, text("01/01/2026"));
        cells.put(TrajetField.VEHICULE, text("1725-D-40"));
        cells.put(TrajetField.TEMPS_CONDUITE, text("-1:00"));

        var record = new TrajetTransformer().transform(new RawRow(2, cells, List.of()));

        assertEquals(Duration.ZERO, record.journee().getTempsConduite());
        assertEquals(1, record.errors().size());
        assertEquals("Durée de conduite négative", record.errors().get(0).getDescription());
    }

    @Test
    void videLesValeursInconnues() {
        Map<TrajetField, CellReading> cells = new EnumMap<>(TrajetField.class);
        cells.put(TrajetField.DATE, text("01/01/2026"));
        cells.put(TrajetField.VEHICULE, text("inconnu"));

        var record = new TrajetTransformer().transform(new RawRow(9, cells, List.of()));

        assertEquals("", record.journee().getVehicule());
    }
}
