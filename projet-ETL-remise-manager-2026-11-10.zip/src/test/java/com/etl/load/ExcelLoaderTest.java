package com.etl.load;

import com.etl.model.Chauffeur;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ExcelLoaderTest {

    @TempDir
    Path temporaryDirectory;

    @Test
    void ecritLeGabaritManagerEnFluxSansColonneDeLaSource() throws IOException {
        Path source = temporaryDirectory.resolve("source.xlsx");
        Path output = temporaryDirectory.resolve("rapport.xlsx");
        Files.createFile(source);

        try (ExcelLoader.StreamingWriter writer = new ExcelLoader().openStream(
                source, output, OutputProfile.RAPPORT_MANAGER)) {
            writer.onHeader(List.of("numeroFlotte", "site", "chauffeurNom"), List.of("DATE"));
            writer.append(chauffeur("1725-D-40", "Ichraf Boughi", "N7, Bouchane, Maroc", "41"));
            writer.append(chauffeur("23990-D-40", "Rachid Elkhattab", "Station Total Atlantis Tanger", "0"));
            writer.append(chauffeur("40722-D-40", "Mardy Mhamed", "A5, Sahel Chamali, Maroc", "86"));
            writer.commit();
        }

        try (XSSFWorkbook workbook = new XSSFWorkbook(Files.newInputStream(output))) {
            Sheet sheet = workbook.getSheet("Rapport manager");
            assertNotNull(sheet);
            assertEquals(14, sheet.getRow(0).getLastCellNum());
            assertEquals(4, sheet.getPhysicalNumberOfRows());

            Row moving = sheet.getRow(1);
            assertEquals("1725-D-40", moving.getCell(2).getStringCellValue());
            assertEquals("Ichraf Boughi", moving.getCell(3).getStringCellValue());
            assertEquals("oui", moving.getCell(4).getStringCellValue());
            assertEquals("Chauffeur concentré sur la route", moving.getCell(6).getStringCellValue());
            assertEquals("N7, Bouchane, Maroc", moving.getCell(7).getStringCellValue());
            assertEquals(41.0, moving.getCell(11).getNumericCellValue());

            Row stopped = sheet.getRow(2);
            assertEquals("NA", stopped.getCell(4).getStringCellValue());
            assertEquals("En arrêt", stopped.getCell(6).getStringCellValue());
            assertEquals(0.0, stopped.getCell(11).getNumericCellValue());

            Row tropVite = sheet.getRow(3);
            assertEquals(75.0, tropVite.getCell(11).getNumericCellValue());

            Sheet audit = workbook.getSheet("Vitesses normalisées");
            assertNotNull(audit);
            assertEquals(2, audit.getPhysicalNumberOfRows());
            assertEquals("4", audit.getRow(1).getCell(0).getStringCellValue());
            assertEquals("86", audit.getRow(1).getCell(3).getStringCellValue());
        }
    }

    @Test
    void conserveLeGabaritNettoyageParDefaut() throws IOException {
        Path source = temporaryDirectory.resolve("source.xlsx");
        Path output = temporaryDirectory.resolve("clean.xlsx");
        Files.createFile(source);

        try (ExcelLoader.StreamingWriter writer = new ExcelLoader().openStream(source, output)) {
            writer.onHeader(List.of("numeroFlotte", "site", "chauffeurNom"), List.of("DATE"));
            writer.append(chauffeur("1725-D-40", "Ichraf Boughi", "N7, Bouchane, Maroc", "41"));
            writer.commit();
        }

        try (XSSFWorkbook workbook = new XSSFWorkbook(Files.newInputStream(output))) {
            Sheet sheet = workbook.getSheet("Chauffeurs nettoyés");
            assertNotNull(sheet);
            Row header = sheet.getRow(0);
            assertEquals(4, header.getLastCellNum());
            assertEquals("Numéro de flotte", header.getCell(0).getStringCellValue());
            assertEquals("Site", header.getCell(1).getStringCellValue());
            assertEquals("Chauffeur", header.getCell(2).getStringCellValue());
            assertEquals("DATE", header.getCell(3).getStringCellValue());
        }
    }

    private Chauffeur chauffeur(String numeroFlotte, String chauffeurNom, String site, String vitesse) {
        return new Chauffeur("MOVING", "", "", numeroFlotte, site, chauffeurNom, site, "", "", vitesse);
    }
}
