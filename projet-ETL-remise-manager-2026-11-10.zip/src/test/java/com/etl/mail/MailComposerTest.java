package com.etl.mail;

import com.etl.model.EtlResult;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MailComposerTest {

    private static final EtlResult RESULT = new EtlResult(
            131, 130, 1, 2, 128,
            Path.of("input/source.xlsx"),
            Path.of("output/sortie.xlsx"),
            Path.of("output/sortie_rapport.txt"),
            42,
            List.of(), List.of()
    );

    @Test
    void objetReprennentLesLignesChargees() {
        assertEquals("Traitement ETL terminé : 128 ligne(s)", MailComposer.defaultSubject(RESULT));
    }

    @Test
    void corpsReprendStatistiquesEtCheminDeSortie() {
        String body = MailComposer.defaultBody(RESULT);

        assertTrue(body.contains("128 ligne(s) chargée(s)"));
        assertTrue(body.contains("2 erreur(s)"));
        assertTrue(body.contains("1 doublon(s)"));
        assertTrue(body.contains("sortie.xlsx"));
    }

    @Test
    void composeLeMessageLibrePuisLeResume() {
        String composed = MailComposer.compose("Bonjour,", "Résumé du traitement.");

        assertEquals("Bonjour,\n\nRésumé du traitement.", composed);
    }

    @Test
    void messageVideSeReduitAuResume() {
        assertEquals("Résumé.", MailComposer.compose("   ", "Résumé."));
        assertEquals("Résumé.", MailComposer.compose(null, "Résumé."));
    }

    @Test
    void resumeDejaPresentNestPasRepete() {
        String summary = "Traitement ETL terminé : 5 ligne(s).";

        assertEquals(summary, MailComposer.compose(summary, summary));
        assertEquals("Message libre.", MailComposer.compose("Message libre.", ""));
    }

    @Test
    void corpsFacultatifDansLeMessage() {
        assertFalse(MailMessage.of("a@exemple.fr", "Objet", "").hasBody());
        assertTrue(MailMessage.of("a@exemple.fr", "Objet", "texte").hasBody());
    }

    @Test
    void destinatairesAcceptentPlusieursSeparateurs() {
        MailMessage message = MailMessage.of("a@exemple.fr, b@exemple.fr; c@exemple.fr",
                "Objet", "corps");

        assertEquals(3, message.recipients().size());
        assertEquals("a@exemple.fr, b@exemple.fr, c@exemple.fr", message.recipientsAsText());
    }

    @Test
    void objetObligatoireEtBorne() {
        MailException vide = assertThrows(MailException.class,
                () -> MailMessage.of("a@exemple.fr", "  ", "corps"));
        assertTrue(vide.getMessage().contains("objet"));

        MailException tropLong = assertThrows(MailException.class,
                () -> MailMessage.of("a@exemple.fr", "x".repeat(201), "corps"));
        assertTrue(tropLong.getMessage().contains("200"));
    }

    @Test
    void messageSansDestinataireRejete() {
        MailException exception = assertThrows(MailException.class,
                () -> MailMessage.of("", "Objet", "corps"));

        assertTrue(exception.getMessage().contains("destinataire"));
    }
}
