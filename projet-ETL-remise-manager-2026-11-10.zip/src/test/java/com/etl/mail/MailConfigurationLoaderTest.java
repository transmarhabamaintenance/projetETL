package com.etl.mail;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MailConfigurationLoaderTest {

    /**
     * Redirige les recherches de fichiers vers un repertoire temporaire : sans cela,
     * un mail.properties reel present sur la machine influencerait les assertions.
     */
    @TempDir
    Path tempDir;

    private String workingDir;
    private String userHome;

    @BeforeEach
    void isolerLesChemins() throws java.io.IOException {
        workingDir = System.getProperty("user.dir");
        userHome = System.getProperty("user.home");
        System.setProperty("user.dir", tempDir.toString());
        System.setProperty("user.home", tempDir.resolve("home").toString());
        Files.createDirectories(tempDir.resolve("home"));
    }

    @AfterEach
    void restaurerLesChemins() {
        System.setProperty("user.dir", workingDir);
        System.setProperty("user.home", userHome);
    }

    @Test
    void utiliseLesVariablesDEnvironnementMemeSansFichier() {
        MailConfiguration configuration = loader(env("SENDGRID", "SG.cle-secrete",
                "expedition@exemple.fr", "Service ETL")).load();

        assertEquals(MailProvider.SENDGRID, configuration.provider());
        assertEquals("SG.cle-secrete", configuration.apiKey());
        assertEquals("expedition@exemple.fr", configuration.senderEmail());
        assertEquals("Service ETL", configuration.senderName());
        assertEquals("", configuration.domain());
    }

    @Test
    void fournisseurParDefautEstBrevo() {
        MailConfiguration configuration = loader(env(null, "cle", "expedition@exemple.fr", null)).load();

        assertEquals(MailProvider.BREVO, configuration.provider());
    }

    @Test
    void nomExpeditionParDefautEstEtlFlotte() {
        MailConfiguration configuration = loader(env(null, "cle", "expedition@exemple.fr", null)).load();

        assertEquals("ETL Flotte", configuration.senderName());
    }

    @Test
    void litLesClesDuFichierLocalLorsqueLenvironnementEstVide() throws Exception {
        Files.writeString(tempDir.resolve("mail.properties"), """
                mail.provider=SENDGRID
                mail.api.key=cle-fichier
                mail.sender.email=fichier@exemple.fr
                mail.sender.name=Depuis le fichier
                """);

        MailConfiguration configuration = loader(Map.of()).load();

        assertEquals(MailProvider.SENDGRID, configuration.provider());
        assertEquals("cle-fichier", configuration.apiKey());
        assertEquals("fichier@exemple.fr", configuration.senderEmail());
        assertEquals("Depuis le fichier", configuration.senderName());
    }

    @Test
    void chercheLeFichierDansLeSousDossierConfig() throws Exception {
        Path configDir = Files.createDirectories(tempDir.resolve("config"));
        Files.writeString(configDir.resolve("mail.properties"), """
                mail.api.key=cle-config
                mail.sender.email=config@exemple.fr
                """);

        MailConfiguration configuration = loader(Map.of()).load();

        assertEquals("cle-config", configuration.apiKey());
    }

    @Test
    void chercheLeFichierDansLeDossierPersonnel() throws Exception {
        Files.writeString(tempDir.resolve("home").resolve("mail.properties"), """
                mail.api.key=cle-home
                mail.sender.email=home@exemple.fr
                """);

        MailConfiguration configuration = loader(Map.of()).load();

        assertEquals("cle-home", configuration.apiKey());
    }

    @Test
    void chercheLeFichierDansLeDossierEtlCache() throws Exception {
        Path etlDir = Files.createDirectories(tempDir.resolve("home").resolve(".etl"));
        Files.writeString(etlDir.resolve("mail.properties"), """
                mail.api.key=cle-etl
                mail.sender.email=etl@exemple.fr
                """);

        MailConfiguration configuration = loader(Map.of()).load();

        assertEquals("cle-etl", configuration.apiKey());
    }

    @Test
    void lenvironnementPrimeSurLeFichierLocal() throws Exception {
        Files.writeString(tempDir.resolve("mail.properties"), """
                mail.api.key=cle-fichier
                mail.sender.email=fichier@exemple.fr
                """);

        MailConfiguration configuration = loader(env(null, "cle-environnement",
                "env@exemple.fr", null)).load();

        assertEquals("cle-environnement", configuration.apiKey());
        assertEquals("env@exemple.fr", configuration.senderEmail());
    }

    @Test
    void cleManquanteProduitUnMessageDAide() {
        MailException exception = assertThrows(MailException.class,
                () -> loader(Map.of()).load());

        assertTrue(exception.getMessage().contains("ETL_MAIL_API_KEY"));
        assertTrue(exception.getMessage().contains("mail.properties"));
    }

    @Test
    void cleVideDeLenvironnementEstConsidereeCommeAbsente() {
        Map<String, String> env = new HashMap<>();
        env.put("ETL_MAIL_API_KEY", "   ");
        env.put("ETL_MAIL_SENDER_EMAIL", "expedition@exemple.fr");

        MailException exception = assertThrows(MailException.class,
                () -> loader(env).load());

        assertTrue(exception.getMessage().contains("ETL_MAIL_API_KEY"));
    }

    @Test
    void adresseExpeditionManquanteProduitUnMessageDAide() {
        MailException exception = assertThrows(MailException.class,
                () -> loader(Map.of("ETL_MAIL_API_KEY", "cle")).load());

        assertTrue(exception.getMessage().contains("ETL_MAIL_SENDER_EMAIL"));
    }

    @Test
    void fournisseurInconnuEstSignaleAvecLesValeursAcceptees() {
        MailException exception = assertThrows(MailException.class,
                () -> loader(env("SMTPGIGA", "cle", "expedition@exemple.fr", null)).load());

        assertTrue(exception.getMessage().contains("SMTPGIGA"));
        assertTrue(exception.getMessage().contains("BREVO"));
    }

    @Test
    void mailgunExigeUnDomaine() {
        MailException exception = assertThrows(MailException.class,
                () -> loader(env("MAILGUN", "cle", "expedition@exemple.fr", null)).load());

        assertTrue(exception.getMessage().contains("ETL_MAIL_DOMAIN"));
    }

    @Test
    void mailgunAccepteUnDomaineConfigure() {
        Map<String, String> environment = env("MAILGUN", "cle", "expedition@exemple.fr", null);
        environment.put("ETL_MAIL_DOMAIN", "mg.exemple.fr");

        MailConfiguration configuration = loader(environment).load();

        assertEquals("mg.exemple.fr", configuration.domain());
    }

    @Test
    void cleDApiNApparaitJamaisDansLeMessageDErreur() {
        MailException exception = assertThrows(MailException.class,
                () -> loader(env("SMTPGIGA", "super-cle-secrete-123",
                        "expedition@exemple.fr", null)).load());

        assertTrue(!exception.getMessage().contains("super-cle-secrete-123"));
    }

    @Test
    void adresseExpeditionInvalideEstRejetee() {
        MailException exception = assertThrows(MailException.class,
                () -> loader(env(null, "cle", "pas-une-adresse", null)).load());

        assertTrue(exception.getMessage().contains("pas-une-adresse"));
    }

    private MailConfigurationLoader loader(Map<String, String> environment) {
        return new MailConfigurationLoader(environment::get);
    }

    private static Map<String, String> env(String provider, String apiKey,
                                            String senderEmail, String senderName) {
        Map<String, String> environment = new HashMap<>();
        if (provider != null) {
            environment.put("ETL_MAIL_PROVIDER", provider);
        }
        if (apiKey != null) {
            environment.put("ETL_MAIL_API_KEY", apiKey);
        }
        if (senderEmail != null) {
            environment.put("ETL_MAIL_SENDER_EMAIL", senderEmail);
        }
        if (senderName != null) {
            environment.put("ETL_MAIL_SENDER_NAME", senderName);
        }
        return environment;
    }
}
