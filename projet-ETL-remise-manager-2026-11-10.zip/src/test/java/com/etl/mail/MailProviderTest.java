package com.etl.mail;

import org.junit.jupiter.api.Test;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MailProviderTest {

    private static final MailConfiguration BREVO = configuration(MailProvider.BREVO, "");
    private static final MailConfiguration SENDGRID = configuration(MailProvider.SENDGRID, "");
    private static final MailConfiguration MAILGUN = configuration(MailProvider.MAILGUN, "mg.exemple.fr");

    @Test
    void endpointBrevo() {
        assertEquals(URI.create("https://api.brevo.com/v3/smtp/email"),
                MailProvider.BREVO.endpoint(BREVO));
    }

    @Test
    void endpointSendgrid() {
        assertEquals(URI.create("https://api.sendgrid.com/v3/mail/send"),
                MailProvider.SENDGRID.endpoint(SENDGRID));
    }

    @Test
    void endpointMailgunIncorporeLeDomaine() {
        assertEquals(URI.create("https://api.mailgun.net/v3/mg.exemple.fr/messages"),
                MailProvider.MAILGUN.endpoint(MAILGUN));
    }

    @Test
    void mailgunSansDomaineEstRejeteALaConstruction() {
        MailException exception = assertThrows(MailException.class,
                () -> new MailConfiguration(MailProvider.MAILGUN, "cle-api", "ETL Flotte",
                        "expedition@exemple.fr", ""));

        assertTrue(exception.getMessage().contains("ETL_MAIL_DOMAIN"));
    }

    @Test
    void enTeteAuthentificationParFournisseur() {
        assertEquals("api-key: cle-api", MailProvider.BREVO.authorizationHeader(BREVO));
        assertEquals("Authorization: Bearer cle-api", MailProvider.SENDGRID.authorizationHeader(SENDGRID));
        assertEquals("Authorization: Basic YXBpOmNsZS1hcGk=",
                MailProvider.MAILGUN.authorizationHeader(MAILGUN));
    }

    @Test
    void seulMailgunUtiliseLeMultipart() {
        assertTrue(MailProvider.MAILGUN.usesMultipart());
        assertFalse(MailProvider.BREVO.usesMultipart());
        assertFalse(MailProvider.SENDGRID.usesMultipart());
    }

    @Test
    void formatExpediteurAvecNomEtNomParDefaut() {
        MailConfiguration sansNom = new MailConfiguration(MailProvider.BREVO, "cle-api",
                "", "expedition@exemple.fr", "");

        assertEquals("\"ETL Flotte\" <expedition@exemple.fr>", MailProvider.BREVO.formattedSender(BREVO));
        assertEquals("\"ETL Flotte\" <expedition@exemple.fr>", MailProvider.BREVO.formattedSender(sansNom));
        assertEquals("ETL Flotte <expedition@exemple.fr>", MailProvider.MAILGUN.formattedSender(MAILGUN));
    }

    @Test
    void nomExpediteurAvecGuillemetEstEchappe() {
        MailConfiguration avecGuillemet = new MailConfiguration(MailProvider.SENDGRID, "cle-api",
                "Le \"Service\"", "expedition@exemple.fr", "");

        assertEquals("\"Le \\\"Service\\\"\" <expedition@exemple.fr>",
                MailProvider.SENDGRID.formattedSender(avecGuillemet));
    }

    @Test
    void lectureDUneValeurSaisieParLUtilisateur() {
        assertEquals(MailProvider.BREVO, MailProvider.from("brevo"));
        assertEquals(MailProvider.SENDGRID, MailProvider.from(" SendGrid "));
        assertEquals(MailProvider.MAILGUN, MailProvider.from("MAILGUN"));
        assertNull(MailProvider.from("inconnu"));
        assertNull(MailProvider.from(null));
        assertNull(MailProvider.from("  "));
    }

    private static MailConfiguration configuration(MailProvider provider, String domain) {
        return new MailConfiguration(provider, "cle-api", "ETL Flotte",
                "expedition@exemple.fr", domain);
    }
}
