package com.etl.mail;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Envoi contre un fournisseur factice : le stub local remplace l'API reelle et
 * livre le corps recu ainsi que les en-tetes d'authentification.
 */
class HttpMailClientTest {

    @TempDir
    Path tempDir;

    private HttpServer server;
    private HttpMailClient client;
    private final Map<String, List<String>> receivedHeaders = new ConcurrentHashMap<>();
    private final StringBuilder receivedBody = new StringBuilder();
    private final AtomicInteger status = new AtomicInteger(201);
    private final AtomicInteger requestCount = new AtomicInteger();

    @BeforeEach
    void demarrerLeStub() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/v3/smtp/email", this::handle);
        server.createContext("/v3/mail/send", this::handle);
        server.start();
        client = new HttpMailClient(endpoint("/v3/smtp/email"));
    }

    @AfterEach
    void arreterLeStub() {
        server.stop(0);
    }

    private void handle(HttpExchange exchange) throws IOException {
        requestCount.incrementAndGet();
        receivedHeaders.clear();
        exchange.getRequestHeaders()
                .forEach((name, values) -> receivedHeaders.put(name.toLowerCase(Locale.ROOT), values));
        receivedBody.setLength(0);
        receivedBody.append(new String(exchange.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8));
        byte[] response = "{\"message\": \"stub\"}".getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(status.get(), response.length);
        exchange.getResponseBody().write(response);
        exchange.close();
    }

    private String header(String name) {
        List<String> values = receivedHeaders.get(name.toLowerCase(Locale.ROOT));
        return values == null || values.isEmpty() ? null : values.get(0);
    }

    // ------------------------------------------------------------- succes

    @Test
    void envoieLeMessageAuBonEndpointAvecLenTeteCle() throws Exception {
        Path classeur = ecrire("sortie.xlsx", "contenu du classeur");
        Path rapport = ecrire("_rapport.txt", "rapport");

        client.send(configuration(MailProvider.BREVO), message(), List.of(classeur, rapport));

        assertEquals(1, requestCount.get());
        assertEquals("cle-api-test", header("api-key"));
        assertEquals("application/json; charset=utf-8", header("Content-Type"));
    }

    @Test
    void leCorpsJsonContientDestinatairesObjetEtResume() throws Exception {
        Path classeur = ecrire("sortie.xlsx", "contenu");

        client.send(configuration(MailProvider.BREVO), message(), List.of(classeur));

        String body = receivedBody.toString();
        assertTrue(body.contains("\"email\":\"destinataire@exemple.fr\""));
        assertTrue(body.contains("\"subject\":\"Traitement ETL terminé : 128 ligne(s)\""));
        assertTrue(body.contains("\"sender\":{\"email\":\"expedition@exemple.fr\""));
        assertTrue(body.contains("128 ligne(s) chargée(s)"));
    }

    @Test
    void laPieceJointeEstEncodeeEnBase64() throws Exception {
        Path classeur = ecrire("sortie.xlsx", "contenu-classeur");

        client.send(configuration(MailProvider.BREVO), message(), List.of(classeur));

        String base64Attendu = java.util.Base64.getEncoder()
                .encodeToString("contenu-classeur".getBytes(StandardCharsets.UTF_8));
        String body = receivedBody.toString();
        assertTrue(body.contains("\"name\":\"sortie.xlsx\""));
        assertTrue(body.contains(base64Attendu));
    }

    @Test
    void sendgridUtiliseLeFormatPersonalizations() throws Exception {
        Path classeur = ecrire("sortie.xlsx", "contenu");
        URI endpoint = endpoint("/v3/mail/send");
        HttpMailClient sendgridClient = new HttpMailClient(endpoint);

        sendgridClient.send(configuration(MailProvider.SENDGRID), message(), List.of(classeur));

        String body = receivedBody.toString();
        assertTrue(body.contains("\"personalizations\":[{\"to\":["));
        assertTrue(body.contains("\"from\":\"\\\"ETL Flotte\\\" <expedition@exemple.fr>\""));
        assertTrue(body.contains("\"disposition\":\"attachment\""));
        assertEquals("Bearer cle-api-test", header("Authorization"));
    }

    // ------------------------------------------------------------- echecs

    @Test
    void cleRefuseeSignaleeCommeTelle() {
        status.set(401);
        Path classeur = ecrire("sortie.xlsx", "contenu");

        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(), List.of(classeur)));

        assertTrue(exception.getMessage().contains("Cle d'API refusée"));
        assertTrue(exception.getMessage().contains("HTTP 401"));
        assertTrue(exception.getMessage().contains("ETL_MAIL_API_KEY"));
    }

    @Test
    void quotaAtteintSignaleCommeTel() {
        status.set(429);
        Path classeur = ecrire("sortie.xlsx", "contenu");

        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(), List.of(classeur)));

        assertTrue(exception.getMessage().contains("Quota"));
        assertTrue(exception.getMessage().contains("HTTP 429"));
    }

    @Test
    void indisponibiliteDuServiceSignalee() {
        status.set(503);
        Path classeur = ecrire("sortie.xlsx", "contenu");

        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(), List.of(classeur)));

        assertTrue(exception.getMessage().contains("indisponible"));
        assertTrue(exception.getMessage().contains("HTTP 503"));
    }

    @Test
    void requeteMalFormeeSignaleeAvecLextraitDeReponse() {
        status.set(400);
        Path classeur = ecrire("sortie.xlsx", "contenu");

        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(), List.of(classeur)));

        assertTrue(exception.getMessage().contains("HTTP 400"));
        assertTrue(exception.getMessage().contains("stub"));
    }

    @Test
    void reseauInjoignableSignale() {
        HttpMailClient horsLigne = new HttpMailClient(
                URI.create("http://127.0.0.1:1/v3/smtp/email"));
        Path classeur = ecrire("sortie.xlsx", "contenu");

        MailException exception = assertThrows(MailException.class,
                () -> horsLigne.send(configuration(MailProvider.BREVO), message(), List.of(classeur)));

        assertTrue(exception.getMessage().contains("injoignable"));
    }

    // ---------------------------------------------------------- gardesfous

    @Test
    void pieceJointeAbsenteProduitUneErreurExplicite() {
        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(), List.of()));

        assertTrue(exception.getMessage().contains("Aucun fichier à joindre"));
        assertEquals(0, requestCount.get());
    }

    @Test
    void pieceJointeIntrouvableProduitUneErreurExplicite() {
        Path manquant = tempDir.resolve("absent.xlsx");

        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(), List.of(manquant)));

        assertTrue(exception.getMessage().contains("introuvable"));
        assertEquals(0, requestCount.get());
    }

    @Test
    void tailleDesPiecesJointesAuDelaDuPlafondProduitUneErreur() throws Exception {
        Files.write(tempDir.resolve("gros.xlsx"), new byte[(int) HttpMailClient.MAX_TOTAL_BYTES + 1]);

        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(),
                        List.of(tempDir.resolve("gros.xlsx"))));

        assertTrue(exception.getMessage().contains("18 Mo"));
        assertTrue(exception.getMessage().contains("messagerie"));
    }

    @Test
    void laCleDApiNApparaitJamaisDansLesMessagesDErreur() {
        status.set(401);
        Path classeur = ecrire("sortie.xlsx", "contenu");

        MailException exception = assertThrows(MailException.class,
                () -> client.send(configuration(MailProvider.BREVO), message(), List.of(classeur)));

        assertTrue(!exception.getMessage().contains("cle-api-test"));
    }

    // -------------------------------------------------------------- outils

    private MailConfiguration configuration(MailProvider provider) {
        return new MailConfiguration(provider, "cle-api-test", "ETL Flotte",
                "expedition@exemple.fr", "mg.exemple.fr");
    }

    private static MailMessage message() {
        return MailMessage.of("destinataire@exemple.fr", "Traitement ETL terminé : 128 ligne(s)",
                "Traitement ETL terminé : 128 ligne(s) chargée(s), 0 erreur(s).");
    }

    private Path ecrire(String nom, String contenu) {
        try {
            return Files.writeString(tempDir.resolve(nom), contenu);
        } catch (IOException exception) {
            throw new IllegalStateException(exception);
        }
    }

    private URI endpoint(String path) {
        return URI.create("http://127.0.0.1:" + server.getAddress().getPort() + path);
    }
}
