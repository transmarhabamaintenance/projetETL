package com.etl.mail;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MailAddressTest {

    @Test
    void accepteUneAdresseValideEtLaNormalise() {
        MailAddress address = new MailAddress("  PreNom.Nom@Exemple.FR ");

        assertEquals("prenom.nom@exemple.fr", address.value());
    }

    @Test
    void uneListeSepareeParVirgulesPointsVirgulesOuEspaces() {
        assertEquals(4, MailAddress.parse("a@exemple.fr, b@exemple.fr; c@exemple.fr\td@exemple.fr").size());
    }

    @Test
    void lesDoublonsSontEliminesApresNormalisation() {
        assertEquals(1, MailAddress.parse("Alice@Exemple.fr, alice@exemple.fr").size());
    }

    @Test
    void listeVideOuBlancheProduitUneErreur() {
        MailException virgules = assertThrows(MailException.class, () -> MailAddress.parse(" , ; "));
        assertTrue(virgules.getMessage().contains("destinataire"));

        MailException nul = assertThrows(MailException.class, () -> MailAddress.parse(null));
        assertTrue(nul.getMessage().contains("destinataire"));
    }

    @Test
    void adressesInvalidesRejetees() {
        for (String invalide : new String[]{
                "sans-at-domaine.fr", "deux@@exemple.fr", "point@.exemple.fr",
                "point@exemple.", "a..b@exemple.fr", "a@ex..ample.fr", "a b@exemple.fr"}) {
            MailException exception = assertThrows(MailException.class,
                    () -> new MailAddress(invalide), invalide);
            assertTrue(exception.getMessage().contains("invalide"), invalide);
        }
    }
}
