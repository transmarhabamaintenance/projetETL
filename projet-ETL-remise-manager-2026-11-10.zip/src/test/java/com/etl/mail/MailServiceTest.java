package com.etl.mail;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MailServiceTest {

    @TempDir
    Path tempDir;

    @Test
    void delegueAuClientAvecLaConfigurationChargee() throws Exception {
        Path classeur = Files.writeString(tempDir.resolve("sortie.xlsx"), "contenu");
        AtomicReference<MailConfiguration> captured = new AtomicReference<>();
        MailClient client = (configuration, message, attachments) -> captured.set(configuration);
        MailService service = new MailService(loaderEnvironnement(), client);

        service.send(message(), List.of(classeur));

        assertEquals(MailProvider.SENDGRID, captured.get().provider());
        assertEquals("cle-test", captured.get().apiKey());
    }

    @Test
    void echecDuClientSePropageEnMailException() {
        MailClient client = (configuration, message, attachments) -> {
            throw new MailException("Cle d'API refusée par le fournisseur (HTTP 401).");
        };
        MailService service = new MailService(loaderEnvironnement(), client);

        MailException exception = assertThrows(MailException.class,
                () -> service.send(message(), List.of()));

        assertTrue(exception.getMessage().contains("HTTP 401"));
    }

    @Test
    void configurEdProviderRenvoieLeFournisseurActif() {
        MailService service = new MailService(loaderEnvironnement(), (configuration, message, attachments) -> {
        });

        assertEquals(MailProvider.SENDGRID, service.configuredProvider());
    }

    @Test
    void configurEdProviderRenvoieNullSansConfiguration() {
        MailService service = new MailService(new MailConfigurationLoader(key -> null),
                (configuration, message, attachments) -> {
                });

        assertNull(service.configuredProvider());
    }

    private static MailConfigurationLoader loaderEnvironnement() {
        Map<String, String> environment = Map.of(
                "ETL_MAIL_PROVIDER", "SENDGRID",
                "ETL_MAIL_API_KEY", "cle-test",
                "ETL_MAIL_SENDER_EMAIL", "expedition@exemple.fr");
        return new MailConfigurationLoader(environment::get);
    }

    private static MailMessage message() {
        return MailMessage.of("destinataire@exemple.fr", "Objet", "corps");
    }
}
