package com.etl.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertTrue;

class AppendResultWriterTest {

    @TempDir
    Path tempDir;

    @Test
    void ajouteSansEcraserLHistoriqueExistant() throws Exception {
        Path target = tempDir.resolve("resultat_7.txt");
        Files.writeString(target, "ANCIEN HISTORIQUE\n");
        String content = "Rapport du traitement\nLignes chargées : 5";
        AppendResultWriter.append(target, content);
        AppendResultWriter.append(target, content);
        String result = Files.readString(target);
        assertTrue(result.contains("ANCIEN HISTORIQUE"));
        assertTrue(result.contains("Lignes chargées : 5"));
        int first = result.indexOf("Rapport du traitement");
        int second = result.lastIndexOf("Rapport du traitement");
        assertTrue(second > first);
    }

    @Test
    void creeLeFichierSilNExistePas() throws Exception {
        Path target = tempDir.resolve("nouveau").resolve("resultat_7.txt");
        AppendResultWriter.append(target, "Nouveau contenu");
        assertTrue(Files.exists(target));
        String result = Files.readString(target);
        assertTrue(result.contains("Nouveau contenu"));
    }
}
