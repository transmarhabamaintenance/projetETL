package com.etl.service;

import com.etl.load.OutputProfile;
import com.etl.model.EtlProgress;
import com.etl.model.EtlResult;
import com.etl.validation.DuplicatePolicy;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EtlServiceTest {

    @TempDir
    Path temporaryDirectory;

    @Test
    void executeLeFluxCompletEtConserveLeFichierSource() throws IOException {
        Path source = temporaryDirectory.resolve("donnees.xlsx");
        createWorkbook(source);
        byte[] sourceBefore = Files.readAllBytes(source);
        Path output = temporaryDirectory.resolve("chauffeurs_clean.xlsx");
        List<EtlProgress> progressEvents = new ArrayList<>();

        EtlResult result = new EtlService().execute(source, output, progressEvents::add);

        assertEquals(3, result.extractedRows());
        assertEquals(3, result.transformedRows());
        assertEquals(1, result.duplicates());
        assertEquals(1, result.errors());
        assertEquals(1, result.loadedRows());
        assertEquals(source.toAbsolutePath().normalize(), result.sourcePath());
        assertEquals(output.toAbsolutePath().normalize(), result.outputPath());
        assertTrue(Files.isRegularFile(result.reportPath()));
        assertArrayEquals(sourceBefore, Files.readAllBytes(source));
        assertTrue(Files.readString(result.reportPath()).contains("ERREURS DE VALIDATION"));
        assertEquals(EtlProgress.Stage.COMPLETED, progressEvents.get(progressEvents.size() - 1).stage());

        try (XSSFWorkbook workbook = new XSSFWorkbook(Files.newInputStream(output))) {
            assertEquals(2, workbook.getSheetAt(0).getPhysicalNumberOfRows());
            assertEquals(0, workbook.getSheetAt(0).getRow(0).getFirstCellNum());
            assertEquals(0, workbook.getSheetAt(0).getRow(1).getFirstCellNum());
        }
    }

    @Test
    void conserveToutesLesColonnesDeLaSource() throws IOException {
        Path source = temporaryDirectory.resolve("total.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("TOTAL");
            String[] headers = {
                    "DATE", "Code camion", "N°tracteur", "Nom chauffeur",
                    "Disponibilité camion", "9:00", "10:00"
            };
            Row header = sheet.createRow(0);
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
            }
            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("2025-11-18");
            row.createCell(1).setCellValue("MA11134 HCL");
            row.createCell(2).setCellValue("TR-98765");
            row.createCell(3).setCellValue("Elcadi");
            row.createCell(4).setCellValue("Disponible");
            row.createCell(5).setCellValue("DÉPÔT TANGER MED HTT");
            row.createCell(6).setCellValue("DÉPÔT RABAT");
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }
        Path output = temporaryDirectory.resolve("total_clean.xlsx");

        EtlResult result = new EtlService().execute(source, output);

        assertEquals(1, result.loadedRows());
        try (XSSFWorkbook workbook = new XSSFWorkbook(Files.newInputStream(output))) {
            Sheet sheet = workbook.getSheetAt(0);
            Row header = sheet.getRow(0);

            assertEquals(6, header.getLastCellNum());
            assertEquals("Numéro de flotte", header.getCell(0).getStringCellValue());
            assertEquals("Site", header.getCell(1).getStringCellValue());
            assertEquals("Chauffeur", header.getCell(2).getStringCellValue());
            assertEquals("DATE", header.getCell(3).getStringCellValue());
            assertEquals("N°tracteur", header.getCell(4).getStringCellValue());
            assertEquals("Disponibilité camion", header.getCell(5).getStringCellValue());

            Row data = sheet.getRow(1);
            assertEquals("MA11134 HCL", data.getCell(0).getStringCellValue());
            assertEquals("DÉPÔT TANGER MED HTT", data.getCell(1).getStringCellValue());
            assertEquals("Elcadi", data.getCell(2).getStringCellValue());
            assertEquals("2025-11-18", data.getCell(3).getStringCellValue());
            assertEquals("TR-98765", data.getCell(4).getStringCellValue());
            assertEquals("Disponible", data.getCell(5).getStringCellValue());
        }
    }

    @Test
    void genereLeRapportManagerAuGabaritDuManager() throws IOException {
        Path source = temporaryDirectory.resolve("live-tracking.xlsx");
        createLiveTrackingWorkbook(source);
        Path output = temporaryDirectory.resolve("live-tracking_rapport_manager.xlsx");

        EtlResult result = new EtlService().execute(
                source, output, DuplicatePolicy.KEEP_ALL, OutputProfile.RAPPORT_MANAGER
        );

        assertEquals(3, result.extractedRows());
        assertEquals(3, result.loadedRows());
        try (XSSFWorkbook workbook = new XSSFWorkbook(Files.newInputStream(output))) {
            Sheet sheet = workbook.getSheet("Rapport manager");
            assertNotNull(sheet);

            Row header = sheet.getRow(0);
            assertEquals(14, header.getLastCellNum());
            assertEquals("Date", header.getCell(0).getStringCellValue());
            assertEquals("Matricule camion", header.getCell(2).getStringCellValue());
            assertEquals("Nom du Chauffeur", header.getCell(3).getStringCellValue());
            assertEquals("Position GPS", header.getCell(7).getStringCellValue());
            assertEquals("Vitesse", header.getCell(11).getStringCellValue());

            Row moving = sheet.getRow(1);
            assertTrue(moving.getCell(0).getStringCellValue().matches("\\d{2}/\\d{2}/\\d{4}"));
            assertTrue(moving.getCell(1).getStringCellValue().matches("\\d{2}:\\d{2}"));
            assertEquals("1725-D-40", moving.getCell(2).getStringCellValue());
            assertEquals("Ichraf Boughi", moving.getCell(3).getStringCellValue());
            assertEquals("oui", moving.getCell(4).getStringCellValue());
            assertEquals("RAS", moving.getCell(5).getStringCellValue());
            assertEquals("Chauffeur concentré sur la route", moving.getCell(6).getStringCellValue());
            assertEquals("A5, Sahel Chamali, Maroc", moving.getCell(7).getStringCellValue());
            assertEquals("RAS", moving.getCell(8).getStringCellValue());
            assertEquals(41.0, moving.getCell(11).getNumericCellValue());

            Row stopped = sheet.getRow(2);
            assertEquals(moving.getCell(0).getStringCellValue(), stopped.getCell(0).getStringCellValue());
            assertEquals("23990-D-40", stopped.getCell(2).getStringCellValue());
            assertEquals("Rachid Elkhattab", stopped.getCell(3).getStringCellValue());
            assertEquals("NA", stopped.getCell(4).getStringCellValue());
            assertEquals("En arrêt", stopped.getCell(6).getStringCellValue());
            assertEquals("Station Total Atlantis Tanger", stopped.getCell(7).getStringCellValue());
            assertEquals(0.0, stopped.getCell(11).getNumericCellValue());

            Row tropVite = sheet.getRow(3);
            assertEquals("40722-D-40", tropVite.getCell(2).getStringCellValue());
            assertEquals(75.0, tropVite.getCell(11).getNumericCellValue());

            Sheet audit = workbook.getSheet("Vitesses normalisées");
            assertNotNull(audit);
            Row auditHeader = audit.getRow(0);
            assertEquals("Ligne du rapport", auditHeader.getCell(0).getStringCellValue());
            assertEquals("Vitesse mesurée", auditHeader.getCell(3).getStringCellValue());
            assertEquals(2, audit.getPhysicalNumberOfRows());
            Row auditRow = audit.getRow(1);
            assertEquals("4", auditRow.getCell(0).getStringCellValue());
            assertEquals("40722-D-40", auditRow.getCell(1).getStringCellValue());
            assertEquals("86", auditRow.getCell(3).getStringCellValue());
            assertEquals("75", auditRow.getCell(4).getStringCellValue());
            assertEquals("80", auditRow.getCell(5).getStringCellValue());
        }
    }

    private void createWorkbook(Path source) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Flotte");
            String[] headers = {
                    "Statut mobile", "Description", "Inscription", "Numéro de flotte", "Site",
                    "Chauffeur", "Emplacement", "Dernier événement", "Valeur dernier événement", "Vitesse"
            };
            Row header = sheet.createRow(0);
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
            }

            addRow(sheet, "actif", "donnee", "2024", "F-100", "Paris", "Alice Martin", "A", "depart", "valeur", "10");
            addRow(sheet, "actif", "doublon", "2024", "f-100", "Lyon", "alice martin", "B", "arrivee", "valeur", "12");
            addRow(sheet, "actif", "invalide", "2024", "", "", "", "C", "depart", "valeur", "invalide");

            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }
    }

    private void addRow(Sheet sheet, String... values) {
        Row row = sheet.createRow(sheet.getLastRowNum() + 1);
        for (int index = 0; index < values.length; index++) {
            row.createCell(index).setCellValue(values[index]);
        }
    }

    /**
     * Export de telemetrie anglais, seul format que le manager fournit pour le suivi.
     */
    private void createLiveTrackingWorkbook(Path source) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Vehicules");
            String[] headers = {
                    "Movement status", "Asset description", "Registration", "Driver", "Location",
                    "Last active event", "Last active event value", "Speed (km/h)"
            };
            Row header = sheet.createRow(0);
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
            }
            addRow(sheet, "Moving", "1725-D-40 // Ichraf Boughi", "1725-D-40", "ICHRAF BOUGHI",
                    "A5, Sahel Chamali, Maroc", "", "", "41");
            addRow(sheet, "Stationary", "23990-D-40// Rachid Elkhattab", "23990-D-40", "Unknown",
                    "Station Total Atlantis Tanger", "", "", "0");
            addRow(sheet, "Moving", "40722-D-40 // Mardy Mhamed", "40722-D-40", "MARDY MHAMED",
                    "A5, Sahel Chamali, Maroc", "", "", "86");
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }
    }
}
