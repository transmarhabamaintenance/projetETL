package com.etl.extract;

import com.etl.EtlException;
import com.etl.model.ChauffeurRecord;
import com.etl.model.ExtraColumn;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.FormulaError;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ExcelExtractorTest {

    @TempDir
    Path temporaryDirectory;

    @Test
    void extraitLaPremiereFeuilleEtConserveLesNumerosDeLigne() throws IOException {
        Path source = temporaryDirectory.resolve("source.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Données");
            createHeader(sheet);
            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("en ligne");
            row.createCell(2).setCellValue("2024-01-01");
            row.createCell(3).setCellValue("F-001");
            row.createCell(4).setCellValue("Paris");
            row.createCell(5).setCellValue("Jean Martin");
            row.createCell(9).setCellValue(12.5);
            sheet.createRow(2);
            workbook.createSheet("Feuille ignorée").createRow(0).createCell(0).setCellValue("Autre");
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        List<ChauffeurRecord> records = new ExcelExtractor().extract(source);

        assertEquals(1, records.size());
        assertEquals(2, records.get(0).rowIndex());
        assertEquals("en ligne", records.get(0).chauffeur().getStatutMobile());
        assertEquals("F-001", records.get(0).chauffeur().getNumeroFlotte());
        assertEquals("", records.get(0).chauffeur().getDescription());
        assertEquals("12,5", records.get(0).chauffeur().getVitesse());
    }

    @Test
    void litUneFormuleEtLesCellulesManquantes() throws IOException {
        Path source = temporaryDirectory.resolve("formules.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet();
            createHeader(sheet);
            Row row = sheet.createRow(1);
            row.createCell(3).setCellValue(42);
            row.createCell(5).setCellValue("Alice");
            row.createCell(4).setCellValue("Lyon");
            row.createCell(9).setCellFormula("10+2.5");
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        List<ChauffeurRecord> records = new ExcelExtractor().extract(source);

        assertEquals(1, records.size());
        assertEquals("42", records.get(0).chauffeur().getNumeroFlotte());
        assertEquals("12,5", records.get(0).chauffeur().getVitesse());
    }

    @Test
    void conserveUneErreurDeCellulePourLeRapport() throws IOException {
        Path source = temporaryDirectory.resolve("erreur-cellule.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet();
            createHeader(sheet);
            Row row = sheet.createRow(1);
            row.createCell(3).setCellValue("F-001");
            row.createCell(4).setCellValue("Paris");
            row.createCell(5).setCellValue("Alice");
            row.createCell(9).setCellErrorValue(FormulaError.VALUE.getCode());
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        ChauffeurRecord record = new ExcelExtractor().extract(source).get(0);

        assertEquals(1, record.extractionErrors().size());
        assertEquals("vitesse", record.extractionErrors().get(0).column());
        assertEquals(2, record.extractionErrors().get(0).rowIndex());
    }

    @Test
    void reconnaitLesEntetesDuFichierLiveTracking() throws IOException {
        Path source = temporaryDirectory.resolve("live-tracking.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Vehicules");
            String[] headers = {
                    "Statut du mouvement", "Description du vehicule", "Inscription", "Numéro de flotte", "Site",
                    "Chauffeur", "Emplacement", "Dernier événement actif", "Valeur du dernier événement actif", "Vitesse (km/h)"
            };
            Row header = sheet.createRow(0);
            Row row = sheet.createRow(1);
            String[] values = {
                    "Stationnaire", "MA11134 HCL", "43627-B-40", "MA11134", "TRANSMARHABA TEM",
                    "EL CADI NOURDIN", "Buzzer Route", "Actif", "OK", "25"
            };
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
                row.createCell(index).setCellValue(values[index]);
            }
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        ChauffeurRecord record = new ExcelExtractor().extract(source).get(0);

        assertEquals("Stationnaire", record.chauffeur().getStatutMobile());
        assertEquals("MA11134 HCL", record.chauffeur().getDescription());
        assertEquals("Actif", record.chauffeur().getDernierEvenement());
        assertEquals("OK", record.chauffeur().getValeurDernierEvenement());
    }

    @Test
    void reconnaitLeFormatLiveTrackingSansColonneFlotteNiSite() throws IOException {
        Path source = temporaryDirectory.resolve("live-tracking-vehicules.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Vehicules");
            String[] headers = {
                    "Statut du mouvement", "Description du vehicule", "Inscription", "Chauffeur",
                    "Emplacement", "Dernier événement actif", "Valeur du dernier événement actif", "Vitesse (km/h)"
            };
            Row header = sheet.createRow(0);
            Row row = sheet.createRow(1);
            String[] values = {
                    "En mouvement", "1725-D-40 // Ichraf Boughi", "1725-D-40", "Ichraf Boughi",
                    "MARRACKECH", "En route", "OK", "60"
            };
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
                row.createCell(index).setCellValue(values[index]);
            }
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        ChauffeurRecord record = new ExcelExtractor().extract(source).get(0);

        assertEquals("1725-D-40", record.chauffeur().getNumeroFlotte());
        assertEquals("MARRACKECH", record.chauffeur().getSite());
        assertEquals("Ichraf Boughi", record.chauffeur().getChauffeurNom());
        assertEquals("60", record.chauffeur().getVitesse());
    }

    @Test
    void reconnaitLesEntetesAnglaisesDuFichierLiveTracking() throws IOException {
        Path source = temporaryDirectory.resolve("live-tracking-en.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Vehicules");
            String[] headers = {
                    "Movement status", "Asset description", "Registration", "Driver", "Location",
                    "Last active event", "Last active event value", "Speed (km/h)"
            };
            Row header = sheet.createRow(0);
            Row row = sheet.createRow(1);
            String[] values = {
                    "Stationary", "1725-D-40 // Ichraf Boughi", "1725-D-40", "ICHRAF BOUGHI",
                    "A5, Sahel Chamali, Maroc", "", "", "41"
            };
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
                row.createCell(index).setCellValue(values[index]);
            }
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        ChauffeurRecord record = new ExcelExtractor().extract(source).get(0);

        assertEquals("Stationary", record.chauffeur().getStatutMobile());
        assertEquals("1725-D-40 // Ichraf Boughi", record.chauffeur().getDescription());
        assertEquals("1725-D-40", record.chauffeur().getNumeroFlotte());
        assertEquals("1725-D-40", record.chauffeur().getInscription());
        assertEquals("ICHRAF BOUGHI", record.chauffeur().getChauffeurNom());
        assertEquals("A5, Sahel Chamali, Maroc", record.chauffeur().getSite());
        assertEquals("41", record.chauffeur().getVitesse());
    }

    @Test
    void rejetteUnFichierVideAvecUnMessageComprehensible() throws IOException {
        Path source = temporaryDirectory.resolve("vide.xlsx");
        Files.createFile(source);

        EtlException exception = assertThrows(EtlException.class, () -> new ExcelExtractor().extract(source));

        assertTrue(exception.getMessage().toLowerCase().contains("vide"));
    }

    @Test
    void rejetteUnEnTeteInconnu() throws IOException {
        Path source = temporaryDirectory.resolve("mauvais-entete.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            workbook.createSheet().createRow(0).createCell(0).setCellValue("colonne inconnue");
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        EtlException exception = assertThrows(EtlException.class, () -> new ExcelExtractor().extract(source));

        assertTrue(exception.getMessage().contains("en-tête"));
    }

    @Test
    void traiteUnFichierSansColonneChauffeurNiSite() throws IOException {
        Path source = temporaryDirectory.resolve("entete-partiel.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet();
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Code camion");
            header.createCell(1).setCellValue("Statut");
            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("F-001");
            row.createCell(1).setCellValue("en ligne");
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        List<ChauffeurRecord> records = new ExcelExtractor().extract(source);

        assertEquals(1, records.size());
        assertEquals("F-001", records.get(0).chauffeur().getNumeroFlotte());
        assertEquals("", records.get(0).chauffeur().getChauffeurNom());
        assertEquals("", records.get(0).chauffeur().getSite());
        assertEquals(List.of("statutMobile", "numeroFlotte"),
                new ExcelExtractor().presentFields(source, null));
    }

    @Test
    void deriveLeSiteDeLaPremierePositionHoraireNonVide() throws IOException {
        Path source = temporaryDirectory.resolve("total.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("TOTAL");
            String[] headers = {
                    "DATE", "Code camion", "N°tracteur", "N°de remorque", "Nom chauffeur",
                    "Disponibilité camion", "Motif de non disponibilité du camion",
                    "9:00", "10:00", "11:00"
            };
            Row header = sheet.createRow(0);
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
            }

            Row first = sheet.createRow(1);
            first.createCell(1).setCellValue("MA11134  HCL");
            first.createCell(4).setCellValue("ELCADI");
            first.createCell(7).setCellValue("DÉPÔT TANGER MED HTT");
            first.createCell(8).setCellValue("A5, KSAR SGHIR");

            Row second = sheet.createRow(2);
            second.createCell(1).setCellValue("MA11135  HCL");
            second.createCell(4).setCellValue("BOUAMIRA");
            second.createCell(8).setCellValue("STATION RELAIS TANGER");

            Row third = sheet.createRow(3);
            third.createCell(1).setCellValue("MA11136  HCL");
            third.createCell(4).setCellValue("BOUNAKOUB");

            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        List<ChauffeurRecord> records = new ExcelExtractor().extract(source, "TOTAL");

        assertEquals(3, records.size());
        assertEquals("DÉPÔT TANGER MED HTT", records.get(0).chauffeur().getSite());
        assertEquals("MA11134  HCL", records.get(0).chauffeur().getNumeroFlotte());
        assertEquals("STATION RELAIS TANGER", records.get(1).chauffeur().getSite());
        assertEquals("", records.get(2).chauffeur().getSite());
    }

    @Test
    void conserveLesColonnesSourceSansChampMetier() throws IOException {
        Path source = temporaryDirectory.resolve("total.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("TOTAL");
            String[] headers = {
                    "DATE", "Code camion", "N°tracteur", "N°de remorque", "Nom chauffeur",
                    "Disponibilité camion", "Motif de non disponibilité du camion",
                    "9:00", "10:00", "11:00"
            };
            Row header = sheet.createRow(0);
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
            }

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("2025-11-18");
            row.createCell(1).setCellValue("MA11134  HCL");
            row.createCell(2).setCellValue("TR-98765");
            row.createCell(3).setCellValue("RM-54321");
            row.createCell(4).setCellValue("ELCADI");
            row.createCell(5).setCellValue("Disponible");
            row.createCell(6).setCellValue("");
            row.createCell(7).setCellValue("DÉPÔT TANGER MED HTT");
            row.createCell(8).setCellValue("A5, KSAR SGHIR");

            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        List<ChauffeurRecord> records = new ExcelExtractor().extract(source, "TOTAL");

        assertEquals(1, records.size());
        List<ExtraColumn> extras = records.get(0).extraColumns();
        assertEquals(
                List.of("DATE", "N°tracteur", "N°de remorque", "Disponibilité camion",
                        "Motif de non disponibilité du camion"),
                extras.stream().map(ExtraColumn::label).toList()
        );
        assertEquals(
                List.of("2025-11-18", "TR-98765", "RM-54321", "Disponible", ""),
                extras.stream().map(ExtraColumn::value).toList()
        );
    }

    @Test
    void conserveLesColonnesSourceEnFlux() throws IOException {
        Path source = temporaryDirectory.resolve("total.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("TOTAL");
            Row header = sheet.createRow(0);
            String[] headers = {"DATE", "Code camion", "Nom chauffeur", "9:00", "10:00"};
            for (int index = 0; index < headers.length; index++) {
                header.createCell(index).setCellValue(headers[index]);
            }
            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("2025-11-18");
            row.createCell(1).setCellValue("MA11134  HCL");
            row.createCell(2).setCellValue("ELCADI");
            row.createCell(3).setCellValue("DÉPÔT TANGER MED HTT");
            Row second = sheet.createRow(2);
            second.createCell(0).setCellValue("2025-11-19");
            second.createCell(1).setCellValue("MA11135  HCL");
            second.createCell(2).setCellValue("BOUAMIRA");
            second.createCell(4).setCellValue("A5, KSAR SGHIR");

            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        List<ChauffeurRecord> records = new ArrayList<>();
        List<String> headerFields = new ArrayList<>();
        List<String> headerExtras = new ArrayList<>();
        new ExcelExtractor().stream(
                source,
                "TOTAL",
                new ExcelExtractor.StreamListener() {
                    @Override
                    public void onHeader(List<String> presentFields, List<String> extraLabels) {
                        headerFields.addAll(presentFields);
                        headerExtras.addAll(extraLabels);
                    }
                },
                (rowIndex, chauffeur, extractionErrors, extraColumns) ->
                        records.add(new ChauffeurRecord(rowIndex, chauffeur, extractionErrors, extraColumns))
        );

        assertEquals(List.of("numeroFlotte", "site", "chauffeurNom"), headerFields);
        assertEquals(List.of("DATE"), headerExtras);
        assertEquals(2, records.size());
        assertEquals(List.of("DATE"), records.get(0).extraColumns().stream()
                .map(ExtraColumn::label).toList());
        assertEquals("2025-11-18", records.get(0).extraColumns().get(0).value());
        assertEquals("2025-11-19", records.get(1).extraColumns().get(0).value());
    }

    @Test
    void listeLesFeuillesEtSelectionneLaFeuilleDemandee() throws IOException {
        Path source = temporaryDirectory.resolve("multi-feuilles.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            for (String name : List.of("VIVO", "TOTAL", "WINXO")) {
                Sheet sheet = workbook.createSheet(name);
                createHeader(sheet);
                Row row = sheet.createRow(1);
                row.createCell(3).setCellValue("F-" + name);
                row.createCell(4).setCellValue("SITE-" + name);
                row.createCell(5).setCellValue("Chauffeur " + name);
            }
            try (OutputStream outputStream = Files.newOutputStream(source)) {
                workbook.write(outputStream);
            }
        }

        ExcelExtractor extractor = new ExcelExtractor();

        assertEquals(List.of("VIVO", "TOTAL", "WINXO"), extractor.listSheetNames(source));
        assertEquals("F-VIVO", extractor.extract(source).get(0).chauffeur().getNumeroFlotte());
        assertEquals("F-TOTAL", extractor.extract(source, "TOTAL").get(0).chauffeur().getNumeroFlotte());
        assertTrue(assertThrows(EtlException.class,
                () -> extractor.extract(source, "INCONNUE"))
                .getMessage().contains("INCONNUE"));
    }

    private void createHeader(Sheet sheet) {
        String[] headers = {
                "Statut mobile", "Description", "Inscription", "Numéro de flotte", "Site",
                "Chauffeur", "Emplacement", "Dernier événement", "Valeur dernier événement", "Vitesse"
        };
        Row row = sheet.createRow(0);
        for (int index = 0; index < headers.length; index++) {
            row.createCell(index).setCellValue(headers[index]);
        }
    }
}
