# Suite ETL

Deux applications desktop Java dans un même projet : **ETL liveTracking** extrait, nettoie, valide et charge un suivi de flotte depuis un classeur `.xlsx`, et **ETL heures de travail** transforme un *Daily Trip Report* en fichiers d’heures de travail. Un écran lanceur JavaFX ouvre l’une ou l’autre.

L’application ne nécessite ni Microsoft Excel, ni base de données, ni Spring Boot. Apache POI lit et écrit les fichiers, JavaFX fournit l’interface et JUnit 5 couvre la logique métier. Le processus est compatible avec Linux et n’utilise aucun chemin Windows codé en dur.

## Prérequis

- JDK 17 ou JDK 21 ;
- Maven 3.9 ou supérieur (ou le Maven Wrapper inclus dans le projet) ;
- un environnement de bureau JavaFX pour l’exécution graphique ;
- `jpackage`, inclus dans le JDK, pour l’empaquetage autonome (outils de packaging Linux pour le `.deb`, WiX Toolset pour un `.msi` Windows).

Sous Ubuntu ou Debian :

```bash
sudo apt update
sudo apt install openjdk-17-jdk maven
```

## Compilation et tests

Depuis la racine du projet, le Maven Wrapper inclus évite de modifier le `PATH` :

Windows PowerShell :

```powershell
.\mvnw.cmd clean verify
```

Linux ou macOS :

```bash
./mvnw clean verify
```

Cette commande compile les sources, exécute les tests JUnit 5 et produit :

- `target/etl-desktop-1.0.0.jar` ;
- `target/lib/`, qui contient les dépendances runtime nécessaires au lancement direct.

Les tests peuvent être lancés indépendamment :

```bash
./mvnw test
```

## Lancement sous Linux

Le lancement ouvre l’écran lanceur de la suite, qui propose deux entrées :

| Bouton | Application | Code |
| --- | --- | --- |
| **ETL liveTracking** | nettoyage, validation et export d’un suivi de flotte | `com.etl` |
| **ETL heures de travail** | conversion d’un *Daily Trip Report* en fichiers d’heures de travail | `com.etl.heures` |

Chaque bouton ouvre sa fenêtre ; les deux applications restent indépendantes et peuvent tourner en même temps. Une application seule peut aussi être lancée directement, sans passer par l’écran lanceur :

```bash
./mvnw javafx:run -Djavafx.mainClass=com.etl.ui.Main
./mvnw javafx:run -Djavafx.mainClass=com.etl.heures.ui.Launcher
```

Pour lancer l’application avec le plugin Maven :

```bash
./mvnw javafx:run
```

Après `./mvnw clean package`, le lancement direct est également possible :

```bash
java -jar target/etl-desktop-1.0.0.jar
```

Le bouton **Ouvrir le fichier de sortie** utilise le gestionnaire de fichiers ou l’application par défaut du système. Il ne dépend pas de Microsoft Excel. Si aucun gestionnaire n’est disponible, le chemin du fichier reste affiché dans le rapport.

## Diffusion sur le poste du manager

Le paquet livré embarque son propre runtime Java : le poste cible n’a besoin ni de Java, ni de Maven. Deux variantes sont fournies, à construire sur une machine du même système d’exploitation que le poste cible.

### Windows, dossier portable

```powershell
powershell -ExecutionPolicy Bypass -File scripts\build-windows-portable.ps1
```

Le script exécute `.\mvnw.cmd clean package`, rassemble le jar principal et ses dépendances dans `target/jpackage-input`, puis appelle `jpackage --type app-image`. Il produit :

- `target/dist/ETL Flotte/` : dossier portable contenant `ETL Flotte.exe` et la JVM embarquée ;
- `target/dist/ETL-Flotte-1.0.0-windows.zip` : archive prête à transmettre.

Le manager dézippe l’archive et double-clique `ETL Flotte.exe` ; aucune installation n’est requise. Un installateur `.msi` n’est pas généré par ce script, car `jpackage` exige pour cela le WiX Toolset. Fermez l’application avant de relancer le script, sinon le dossier de sortie reste verrouillé.

### Linux, installateur `.deb`

`jpackage` doit être exécuté sur Linux ; il ne produit pas un installateur Linux depuis Windows. Avec un JDK installé et le wrapper Maven disponible :

```bash
bash scripts/build-linux-installer.sh
```

Le script réalise un `./mvnw clean package`, rassemble le jar principal et toutes les dépendances runtime, puis appelle `jpackage --type deb`. L’installateur est produit dans `target/dist/`.

La commande manuelle équivalente est :

```bash
./mvnw clean package
rm -rf target/jpackage-input target/dist
mkdir -p target/jpackage-input/lib target/dist
cp target/etl-desktop-1.0.0.jar target/jpackage-input/
./mvnw dependency:copy-dependencies \
  -DincludeScope=runtime \
  -DoutputDirectory=target/jpackage-input/lib
jpackage \
  --type deb \
  --name etl-flotte \
  --vendor "ETL Flotte" \
  --app-version 1.0.0 \
  --input target/jpackage-input \
  --main-jar etl-desktop-1.0.0.jar \
  --main-class com.etl.ui.Launcher \
  --dest target/dist
```

L’application n’est pas modulaire : les artefacts JavaFX classifierés pour la plateforme Linux sont donc copiés avec les autres dépendances runtime. Il est important de ne pas ajouter `--add-modules javafx.controls,javafx.fxml` à cette commande : les modules JavaFX sont déjà fournis par les JAR runtime et le lancement par classpath est plus fiable pour `jpackage` avec Maven.

## Utilisation

Le champ **Traitement** propose deux modes.

### Un seul fichier

1. Laisser **Traitement** sur `Un seul fichier`.
2. Cliquer sur **Parcourir…** à côté du fichier source et sélectionner un `.xlsx`.
3. Choisir un fichier de sortie, par exemple `chauffeurs_clean.xlsx`.
4. Cliquer sur **Lancer le traitement**.
5. À la fin, consulter le rapport à l’écran. Un rapport UTF-8 est également écrit à côté du fichier de sortie, avec le suffixe `_rapport.txt`.

### Choisir le format de suivi

En traitement d’un fichier, le format de sortie peut être `Suivi VIVO`, `Suivi TOTAL` ou le rapport manager. `Suivi VIVO` écrit les 14 colonnes du rapport dans l’onglet VIVO. `Suivi TOTAL` ajoute la position LiveTracking dans la colonne horaire la plus proche et renseigne le code camion, le tracteur et le chauffeur ; les informations absentes de LiveTracking restent vides.

Pour conserver les autres onglets et l’historique du classeur joint, choisissez ce classeur existant comme fichier de sortie puis sélectionnez **Ajouter à l’historique**. L’onglet de suivi choisi est conservé avec ses autres onglets.

### Un dossier (fusion de N fichiers)

1. Choisir **Traitement** → `Un dossier (plusieurs fichiers)`.
2. Cliquer sur **Parcourir…** à côté du dossier source et sélectionner le dossier contenant les classeurs `.xlsx`.
3. Choisir le classeur de sortie unique, par exemple `resultat_rapport_manager.xlsx`.
4. Cliquer sur **Lancer le traitement**.

Tous les classeurs `.xlsx` du dossier sont alors fusionnés dans **un seul classeur, sur une
seule feuille**. L’en-tête du gabarit manager n’est écrit qu’une fois, puis les lignes de chaque
fichier sont ajoutées à la suite de celles du fichier précédent, dans l’ordre alphabétique des
noms de fichiers pour garantir un résultat reproductible. Chaque fichier conserve la date et
l’heure de son propre traitement dans les colonnes `Date` et `Heure`.

Un classeur illisible n’interrompt pas le lot : il est signalé dans le rapport et les fichiers
suivants sont traités. Les classeurs déjà produits par l’application (`*_rapport_manager.xlsx`,
`*_clean.xlsx`) et les fichiers temporaires d’Excel (`~$…`) présents dans le dossier sont
ignorés, afin qu’un résultat d’une exécution précédente ne soit jamais réinjecté comme source ;
l’interface indique alors pourquoi le fichier a été écarté.

La source n’est jamais modifiée. Le fichier de sortie est d’abord écrit dans un fichier temporaire puis remplacé de manière atomique lorsque le système de fichiers le permet.

## Envoi du résultat par email

Après chaque traitement réussi, la boîte de dialogue d'envoi s'ouvre automatiquement : il suffit de saisir les destinataires, l'objet et, si vous le souhaitez, un message. Le message est facultatif : lorsqu'il reste vide, le corps de l'email se réduit à une ligne récapitulative, par exemple `Traitement ETL terminé : 128 ligne(s) chargée(s), 0 erreur(s), 2 doublon(s). Fichier : …`. Le rapport détaillé n'est pas repris dans l'email ; il reste consultable à l'écran, dans le classeur produit et dans le fichier `_rapport.txt`.

La case **Proposer l'envoi par email après chaque traitement réussi**, sous le rapport, permet de ne plus déclencher l'ouverture automatiquement. Le bouton **Envoyer par email** de la barre du rapport reste disponible pour renvoyer le dernier résultat à tout moment.

L'envoi part en arrière-plan et n'affecte jamais le classeur ni le rapport déjà produits.

L'envoi utilise l'API HTTP du fournisseur configuré, par appel `POST` authentifié :

| `mail.provider` | Endpoint | Authentification |
| --- | --- | --- |
| `BREVO` | `https://api.brevo.com/v3/smtp/email` | en-tête `api-key` |
| `SENDGRID` | `https://api.sendgrid.com/v3/mail/send` | en-tête `Authorization: Bearer` |
| `MAILGUN` | `https://api.mailgun.net/v3/{domaine}/messages` | `Authorization: Basic` (`api:clé`) |

### Configuration de la clé d'API

La clé n'est jamais écrite dans le code. Elle est lue au moment de l'envoi, depuis l'environnement d'exécution ou depuis un fichier local. L'environnement est prioritaire.

Variables d'environnement :

| Variable | Clé de fichier | Rôle |
| --- | --- | --- |
| `ETL_MAIL_PROVIDER` | `mail.provider` | `BREVO`, `SENDGRID` ou `MAILGUN` (défaut `BREVO`) |
| `ETL_MAIL_API_KEY` | `mail.api.key` | clé d'API, obligatoire |
| `ETL_MAIL_SENDER_NAME` | `mail.sender.name` | nom d'expédition (défaut `ETL Flotte`) |
| `ETL_MAIL_SENDER_EMAIL` | `mail.sender.email` | adresse d'expédition, obligatoire |
| `ETL_MAIL_DOMAIN` | `mail.domain` | domaine du compte, requis pour Mailgun |

PowerShell :

```powershell
$env:ETL_MAIL_PROVIDER = "BREVO"
$env:ETL_MAIL_API_KEY = "xkeysib-votre-cle"
$env:ETL_MAIL_SENDER_EMAIL = "expedition@votre-domaine.fr"
.\mvnw.cmd javafx:run
```

Bash :

```bash
export ETL_MAIL_PROVIDER=BREVO
export ETL_MAIL_API_KEY=xkeysib-votre-cle
export ETL_MAIL_SENDER_EMAIL=expedition@votre-domaine.fr
./mvnw javafx:run
```

Avec un fichier local, copiez `mail.properties.example` vers `mail.properties` et renseignez vos valeurs. Le fichier est cherché dans cet ordre : répertoire de travail, sous-dossier `config/`, dossier personnel, puis `~/.etl/`. `mail.properties` est ignoré par Git.

```properties
mail.provider=BREVO
mail.api.key=xkeysib-votre-cle
mail.sender.name=ETL Flotte
mail.sender.email=expedition@votre-domaine.fr
```

### Erreurs d'envoi

Un échec d'envoi est signalé dans l'interface sans invalider le traitement ETL : le rapport affiché, le classeur de sortie et le bouton **Ouvrir le fichier de sortie** restent utilisables. Les messages distinguent une configuration absente, une clé refusée (HTTP 4xx), un quota atteint (HTTP 429), une indisponibilité du service (HTTP 5xx) et un réseau injoignable.

## Format et règles métier

- La feuille à traiter se choisit dans la liste déroulante **Feuille** ; la première feuille est retenue par défaut. Les classeurs ne comportant qu’une seule feuille n’affichent pas de sélecteur.
- Les en-têtes sont recherchés dans les 25 premières lignes. Les variantes françaises, anglaises et les variantes avec ou sans accents sont reconnues. Une seule colonne métier reconnue suffit à identifier la ligne d'en-tête : une colonne absente du fichier n'empêche pas le traitement.
- Si aucune colonne de site n’existe, le site est déduit de la première position horaire non vide (`9:00`, `10:00`…), ce qui permet de traiter les feuilles de type `TOTAL` et `WINXO`.
- Le classeur de sortie ne contient que les colonnes reconnues dans la feuille traitée, dans l’ordre canonique. Une colonne absente de la source n’est pas écrite : traiter la feuille `TOTAL` produit donc trois colonnes (Numéro de flotte, Site, Chauffeur) et non dix colonnes dont sept vides.
- Les cellules vides sont conservées comme données manquantes et écrites vides dans la sortie ; une ligne entièrement vide est ignorée.
- Les espaces multiples, caractères de contrôle, valeurs `Unknown`, `Inconnu`, `N/A`, `ND` et `null` sont nettoyés.
- Les noms sont normalisés avec une casse lisible, les statuts et sites en majuscules, et les vitesses avec un point décimal lorsque cela est possible.
- Aucun champ n'est obligatoire : le numéro de flotte, le chauffeur et le site peuvent être absents, vides ou renseignés `Unknown`/`Inconnu`/`N/A`/`ND`/`null`. La ligne est traitée normalement et la valeur reste vide dans le classeur de sortie.
- La vitesse est facultative, mais lorsqu’elle est renseignée elle doit être un nombre positif ou nul.
- Une ligne invalide n’est pas écrite dans le classeur de sortie et apparaît dans le rapport avec sa ligne Excel, sa colonne, sa valeur et le motif.
- Une identité `(numeroFlotte, chauffeurNom)` déjà rencontrée est signalée comme doublon. La première occurrence valide est conservée ; les occurrences suivantes sont exclues et listées explicitement dans le rapport. Une ligne dont l'identité est incomplète (numéro de flotte ou nom absent/inconnu) n'est jamais traitée comme doublon.

## Architecture

```text
src/main/java/com/etl/
├── EtlException.java                 Erreurs métier affichables
├── model/
│   ├── Chauffeur.java                Données métier et identité de doublon
│   ├── ChauffeurRecord.java          Ligne source + chauffeur
│   ├── DuplicateRecord.java          Doublon conservé pour le rapport
│   ├── EtlProgress.java              Progression de l’exécution
│   ├── EtlResult.java                Statistiques et chemins
│   └── ValidationError.java          Erreur cellule/réponse
├── extract/
│   └── ExcelExtractor.java           Lecture Apache POI, sélection de feuille et flux SAX
├── transform/
│   └── ChauffeurTransformer.java     Nettoyage et normalisation
├── validation/
│   ├── ChauffeurValidator.java       Vitesse, doublons, identité incomplète
│   └── ValidationResult.java         Résultat de validation
├── load/
│   └── ExcelLoader.java              Écriture .xlsx et remplacement atomique
├── service/
│   ├── EtlService.java               Orchestration EXTRACT → TRANSFORM → VALIDATE → LOAD
│   ├── EtlReportFormatter.java       Rapport lisible et rapport fichier
│   ├── EtlReportWriter.java          Écriture UTF-8
│   ├── BatchReportFormatter.java     Rapport de fusion d’un dossier
│   └── BatchReportWriter.java        Écriture UTF-8 du rapport de lot
├── mail/
│   ├── MailService.java              Envoi après un traitement réussi
│   ├── MailConfigurationLoader.java  Clé d’API : variable d’environnement ou fichier local
│   ├── MailConfiguration.java        Réglages validés, jamais codés en dur
│   ├── MailProvider.java             Brevo, SendGrid ou Mailgun
│   ├── MailClient.java              Transport d’envoi
│   ├── HttpMailClient.java           POST HTTP, en-têtes d’authentification
│   ├── MailMessage.java              Destinataires, objet, message facultatif
│   ├── MailAddress.java              Validation des adresses
│   ├── MailComposer.java             Objet proposé et ligne de résumé
│   └── MailException.java            Erreur d’envoi sans effet sur l’ETL
├── batch/
│   ├── BatchService.java             Fusionne N classeurs dans un classeur unique
│   ├── BatchResult.java              Statistiques agrégées du lot
│   └── BatchFileResult.java          Issue du traitement d’un fichier
└── ui/
    ├── Main.java                     Classe Application JavaFX
    ├── Launcher.java                 Point d’entrée portable classpath
    ├── MainView.java                 Interface, FileChooser et Task de fond
    ├── TreatmentMode.java            Choix « un fichier » ou « un dossier »
    ├── MailSendDialog.java           Saisie destinataires, objet et message
    └── application.css               Thème visuel
```

Le cœur ETL ne dépend pas de JavaFX. Il peut donc être testé dans un environnement headless, tandis que JavaFX reste isolé dans `com.etl.ui`. L’envoi d’emails est isolé dans `com.etl.mail` : il ne modifie pas le pipeline extract/transform/load et ne s’exécute qu’après son succès.

## Robustesse et erreurs

Les contrôles d’entrée couvrent notamment :

- fichier absent, dossier sélectionné à la place d’un fichier, extension différente de `.xlsx` ;
- fichier vide, classeur corrompu ou format `.xlsx` invalide ;
- en-tête absent ou non reconnu ;
- fichier verrouillé, permissions insuffisantes, destination inexistante ou disque plein ;
- chemin de sortie identique au chemin source ;
- cellule de formule, valeur numérique, booléenne ou cellule d’erreur.

Les messages affichés sont en français et ne dépendent pas du nom de la distribution Linux.

## Tests

La suite JUnit 5 couvre :

- le nettoyage des espaces, casse, valeurs inconnues et vitesses ;
- la conservation des numéros de ligne ;
- l'absence d'obligation de champ : une valeur vide ou inconnue reste vide en sortie et la ligne est traitée ;
- les vitesses invalides ;
- la détection des doublons et l'exclusion des lignes à identité incomplète ;
- l’extraction de la première feuille, des cellules vides, des formules et des erreurs de format ;
- la liste des feuilles, la sélection d’une feuille nommée et le rejet d’une feuille inconnue ;
- la déduction du site depuis les colonnes horaires lorsque aucune colonne de site n’existe ;
- l’exécution ETL complète et la conservation du fichier source ;
- la fusion de plusieurs classeurs dans une seule feuille, l’ordre alphabétique des fichiers, la
  date propre à chaque fichier, la poursuite du lot malgré un classeur illisible et l’exclusion
  des classeurs produits par l’application.

## Traitement des classeurs volumineux

Au-delà de 20 Mo, le pipeline bascule automatiquement en traitement en flux : la feuille est lue
par analyse XML (SAX) et chaque ligne est immédiatement nettoyée, validée puis écrite dans le classeur
de sortie (SXSSF) sans jamais conserver l’intégralité des données en mémoire. Les compteurs du
rapport restent exacts, mais le détail des erreurs et des doublons est limité aux 5 000 premiers afin
de protéger la mémoire ; le rapport indique le nombre d’occurrences non détaillées.

```bash
./mvnw test
```
