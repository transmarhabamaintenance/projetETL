#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
MAVEN_BIN="${MAVEN_BIN:-}"
if [ -n "${MAVEN_BIN}" ]; then
    run_maven() { "${MAVEN_BIN}" "$@"; }
elif [ -x "${PROJECT_DIR}/mvnw" ]; then
    run_maven() { "${PROJECT_DIR}/mvnw" "$@"; }
elif [ -f "${PROJECT_DIR}/mvnw" ]; then
    run_maven() { bash "${PROJECT_DIR}/mvnw" "$@"; }
elif command -v mvn >/dev/null 2>&1; then
    run_maven() { mvn "$@"; }
else
    printf 'Maven Wrapper introuvable ou Maven non installé.\n' >&2
    exit 1
fi
APP_VERSION="1.0.0"
MAIN_JAR="etl-desktop-${APP_VERSION}.jar"
STAGING_DIR="${PROJECT_DIR}/target/jpackage-input"
DIST_DIR="${PROJECT_DIR}/target/dist"

cd "${PROJECT_DIR}"
run_maven clean package

rm -rf "${STAGING_DIR}" "${DIST_DIR}"
mkdir -p "${STAGING_DIR}/lib" "${DIST_DIR}"
cp "target/${MAIN_JAR}" "${STAGING_DIR}/"
run_maven -q dependency:copy-dependencies \
    -DincludeScope=runtime \
    -DoutputDirectory="${STAGING_DIR}/lib"

jpackage \
    --type deb \
    --name etl-flotte \
    --vendor "ETL Flotte" \
    --app-version "${APP_VERSION}" \
    --description "Application ETL desktop pour les données de flotte" \
    --input "${STAGING_DIR}" \
    --main-jar "${MAIN_JAR}" \
    --main-class com.etl.ui.Launcher \
    --dest "${DIST_DIR}"

printf 'Installateur créé dans %s\n' "${DIST_DIR}"
