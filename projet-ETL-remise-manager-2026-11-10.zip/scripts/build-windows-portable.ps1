# Construit un paquet Windows portable de l'application.
#
# Le dossier produit contient son propre runtime Java : le poste du manager n'a besoin
# ni de Java, ni de Maven. Il suffit de dezipper l'archive et de lancer "ETL Flotte.exe".
#
# Utilisation, depuis la racine du projet :
#   powershell -ExecutionPolicy Bypass -File scripts\build-windows-portable.ps1
#
# Un installateur .msi n'est pas produit ici : jpackage exige le WiX Toolset pour cela.
# Le dossier portable couvre le meme besoin sans dependance supplementaire.

$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectDir = (Resolve-Path (Join-Path $scriptDir '..')).Path

$appVersion = '1.0.0'
$appName = 'ETL Flotte'
$mainJar = "etl-desktop-$appVersion.jar"
$stagingDir = Join-Path $projectDir 'target\jpackage-input'
$distDir = Join-Path $projectDir 'target\dist'
$imageDir = Join-Path $distDir $appName
$zipPath = Join-Path $distDir "ETL-Flotte-$appVersion-windows.zip"

$mvnw = Join-Path $projectDir 'mvnw.cmd'
if (-not (Test-Path $mvnw)) {
    $mvnw = Join-Path $projectDir 'mvnw'
}
if (-not (Test-Path $mvnw)) {
    throw "Maven Wrapper introuvable dans $projectDir."
}

$jpackage = $null
if ($env:JAVA_HOME) {
    $candidate = Join-Path $env:JAVA_HOME 'bin\jpackage.exe'
    if (Test-Path $candidate) {
        $jpackage = $candidate
    }
}
if (-not $jpackage) {
    $command = Get-Command jpackage -ErrorAction SilentlyContinue
    if ($command) {
        $jpackage = $command.Source
    }
}
if (-not $jpackage) {
    throw "jpackage est introuvable. Installez un JDK 17 ou superieur et definissez JAVA_HOME."
}

Push-Location $projectDir
try {
    if (Test-Path $distDir) {
        try {
            Remove-Item -Recurse -Force $distDir -ErrorAction Stop
        } catch {
            throw "Le dossier $distDir est verrouille. Fermez l'application 'ETL Flotte' si elle est ouverte, puis relancez le script."
        }
    }

    Write-Host 'Compilation et execution des tests...'
    & $mvnw clean package
    if ($LASTEXITCODE -ne 0) {
        throw "La compilation a echoue (code $LASTEXITCODE)."
    }

    New-Item -ItemType Directory -Force -Path (Join-Path $stagingDir 'lib'), $distDir | Out-Null
    Copy-Item (Join-Path $projectDir "target\$mainJar") $stagingDir

    Write-Host 'Copie des dependances runtime...'
    & $mvnw -q dependency:copy-dependencies `
        '-DincludeScope=runtime' `
        "-DoutputDirectory=$stagingDir\lib"
    if ($LASTEXITCODE -ne 0) {
        throw "La copie des dependances a echoue (code $LASTEXITCODE)."
    }

    Write-Host 'Creation de l''image de l''application (JVM incluse)...'
    & $jpackage `
        --type app-image `
        --name $appName `
        --vendor 'ETL Flotte' `
        --app-version $appVersion `
        --description 'Application ETL desktop pour les donnees de flotte' `
        --input $stagingDir `
        --main-jar $mainJar `
        --main-class com.etl.ui.Launcher `
        --dest $distDir
    if ($LASTEXITCODE -ne 0) {
        throw "jpackage a echoue (code $LASTEXITCODE)."
    }

    Write-Host 'Compression de l''archive a transmettre...'
    $tar = Get-Command tar -ErrorAction SilentlyContinue
    if ($tar) {
        if (Test-Path $zipPath) {
            Remove-Item -LiteralPath $zipPath -Force
        }
        & $tar.Source -a -c -f $zipPath -C $distDir $appName
        if ($LASTEXITCODE -ne 0) {
            throw "tar a echoue (code $LASTEXITCODE)."
        }
    } else {
        Compress-Archive -Path $imageDir -DestinationPath $zipPath -Force
    }
} finally {
    Pop-Location
}

Write-Host ''
Write-Host "Dossier portable    : $imageDir"
Write-Host "Archive a transmettre : $zipPath"
